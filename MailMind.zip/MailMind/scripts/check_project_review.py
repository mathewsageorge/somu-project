"""Reproduce the user-reported failure; this is a regression, not held-out data."""
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message
from mailmind.text import sentences

if __name__ == '__main__':
    os.environ['MODEL_PROVIDER'] = 'llamacpp'
    body = (ROOT / 'data/regression_project_review.txt').read_text(encoding='utf-8')
    report = {'timestamp': datetime.now(timezone.utc).isoformat(),
              'note': 'User-reported development regression; not held-out evaluation.',
              'source_sha256': {name: hashlib.sha256((ROOT/'mailmind'/name).read_bytes()).hexdigest()
                                for name in ['text.py','pipeline.py','dates.py','improved.py']},
              'sentences': sentences(body), 'results': {}}
    for approach in ['baseline', 'improved']:
        result = analyse(AnalysisRequest(messages=[Message(id='pasted-1', body=body)], approach=approach))
        report['results'][approach] = result.model_dump(mode='json')
        print(json.dumps({'approach': approach, 'tasks': [t.action for t in result.tasks],
                          'events': [e.description for e in result.events]}, indent=2), flush=True)
    (ROOT/'results'/sys.argv[1]).write_text(json.dumps(report, indent=2), encoding='utf-8')
