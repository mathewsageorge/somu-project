param([Parameter(Mandatory=$true)][string]$ModelDirectory)
$ErrorActionPreference = 'Stop'
$TaskModelDir = (Resolve-Path -LiteralPath $ModelDirectory).Path
$TaskModelPath = Join-Path $TaskModelDir 'Qwen3.5-4B-Q4_K_M.gguf'
$TaskServerPath = Join-Path $TaskModelDir 'runtime\llama-server.exe'
if (!(Test-Path -LiteralPath $TaskModelPath) -or !(Test-Path -LiteralPath $TaskServerPath)) {
    throw 'Run fetch_candidate_model.py successfully before starting the model.'
}
$TaskModelHash = (Get-FileHash -LiteralPath $TaskModelPath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($TaskModelHash -ne '00fe7986ff5f6b463e62455821146049db6f9313603938a70800d1fb69ef11a4') {
    throw 'Model checksum mismatch; refusing to load.'
}
$TaskArguments = @('-m', ('"' + $TaskModelPath + '"'), '--alias', 'Qwen3.5-4B-Q4_K_M',
    '--host', '127.0.0.1', '--port', '8082', '-c', '8192', '-np', '1', '-ngl', '24',
    '-b', '256', '-ub', '128', '--reasoning', 'off', '--log-disable')
$TaskProcess = Start-Process -FilePath $TaskServerPath -ArgumentList $TaskArguments -WindowStyle Hidden -PassThru `
    -WorkingDirectory (Split-Path $TaskServerPath) `
    -RedirectStandardOutput (Join-Path $TaskModelDir 'server.stdout.log') `
    -RedirectStandardError (Join-Path $TaskModelDir 'server.stderr.log')
$TaskStart = @{pid=$TaskProcess.Id; model='Qwen3.5-4B-Q4_K_M'; endpoint='http://127.0.0.1:8082';
    context_tokens=8192; parallel_slots=1; gpu_layers=24; batch=256; micro_batch=128; reasoning='off';
    model_sha256=$TaskModelHash; started_utc=[DateTime]::UtcNow.ToString('o')}
$TaskStart | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $TaskModelDir 'start-info.json') -Encoding utf8
$TaskStart | ConvertTo-Json
