"""UI truthfulness using explicit mocked inference; not model evaluation."""
from pathlib import Path
from streamlit.testing.v1 import AppTest
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message
from mailmind.improved import ModelUnavailable

DEMO=str(Path(__file__).parents[1]/'demo.py')


def test_baseline_never_claims_model_execution():
    app=AppTest.from_file(DEMO).run(timeout=15)
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert any('NO AI MODEL USED' in m.value for m in app.markdown)
    assert not any('AI INFERENCE COMPLETED' in m.value for m in app.markdown)
    assert any(m.label=='Processing time' for m in app.metric)


def test_completed_run_uses_actual_result_identifier_not_config(monkeypatch):
    result=analyse(AnalysisRequest(messages=[Message(id='m',body='The file is attached.')]))
    result.approach='improved'
    result.model='test-result-model'
    result.latency_ms=2345
    result.input_tokens=100
    result.output_tokens=20
    monkeypatch.setattr('mailmind.pipeline.analyse',lambda request, **kwargs:result)
    app=AppTest.from_file(DEMO).run(timeout=15)
    app.selectbox[1].set_value('improved').run()
    assert not any('AI INFERENCE COMPLETED' in m.value for m in app.markdown)
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert any(h.value=='test-result-model' for h in app.subheader)
    assert any(m.label=='Processing time' and m.value=='2.35 s' for m in app.metric)
    assert any('Input tokens: 100' in c.value for c in app.caption)


def test_failed_inference_never_shows_completed_model_banner(monkeypatch):
    def fail(request, **kwargs):
        raise ModelUnavailable('test failure')
    monkeypatch.setattr('mailmind.pipeline.analyse',fail)
    app=AppTest.from_file(DEMO).run(timeout=15)
    app.selectbox[1].set_value('improved').run()
    app.button[0].click().run(timeout=15)
    assert len(app.error)==1
    assert not any(m.label in {'Processing time', 'Action items', 'Events'} for m in app.metric)
    assert not any('AI INFERENCE COMPLETED' in m.value for m in app.markdown)
