from pathlib import Path
from streamlit.testing.v1 import AppTest


def test_report_requirement_visible_in_pasted_flow():
    import json
    root = Path(__file__).parents[1]
    body = json.loads((root/'data/manual_case_21.json').read_text(encoding='utf-8'))['cases'][0]['body']
    app = AppTest.from_file(str(root/'demo.py')).run(timeout=15)
    app.radio[0].set_value('Paste email').run()
    app.text_area[0].set_value(body)
    app.button[0].click().run(timeout=15)
    assert not app.exception
    tasks = app.session_state.result['tasks']
    assert len(tasks) == 2  # Baseline still misses contextual attendance.
    assert tasks[0]['deadline'] == '2026-10-12'
    requirement = 'Please include any issues identified during testing.'
    assert tasks[1]['requirements'][0]['quote'] == requirement
    assert any(item.value == requirement for item in app.text)


def test_streamlit_fictional_flow():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    assert not app.exception
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert len(app.session_state.result['tasks'])==2
    assert len(app.session_state.result['events'])==1
    app.button[-1].click().run()
    assert 'result' not in app.session_state


def test_pasted_email_without_spaces_after_periods():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    app.radio[0].set_value('Paste email').run()
    app.text_area[0].set_value('Asha, please send the project report by 2026-10-15.Ravi, please review the presentation by 2026-10-16.The team meeting is on 2026-10-17 at 10 am UTC.')
    app.button[0].click().run(timeout=15)
    assert not app.exception
    result=app.session_state.result
    assert [(t['owner'],t['deadline']) for t in result['tasks']]==[('Asha','2026-10-15'),('Ravi','2026-10-16')]
    assert len(result['events'])==1
    assert result['events'][0]['date']=='2026-10-17'


def test_v2_example_preserves_sender_context_and_hides_reserved():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    assert not any('reserved' in str(option) for option in app.selectbox[0].options)
    app.selectbox[0].set_value('v2-dev-11').run()
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert app.session_state.result['tasks'][0]['deadline']=='2027-01-22'
    assert any('Expected answer' in expander.label for expander in app.expander)


def test_v2_thread_example_preserves_message_boundaries():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    app.selectbox[0].set_value('v2-dev-19').run()
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert [t['status'] for t in app.session_state.result['tasks']]==['superseded','pending']
    assert app.session_state.result['tasks'][-1]['evidence'][0]['message_id']=='m2'


def test_changing_case_or_method_clears_stale_result():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    app.button[0].click().run(timeout=15)
    assert 'result' in app.session_state
    app.selectbox[0].set_value('v2-dev-02').run()
    assert 'result' not in app.session_state
    app.button[0].click().run(timeout=15)
    assert not app.session_state.result['tasks']
    app.selectbox[1].set_value('improved').run()
    assert 'result' not in app.session_state


def test_no_idle_telemetry_and_result_survives_rerun(monkeypatch):
    readings = []
    def sample():
        readings.append(1)
        return {'sampled_at': '2026-10-12T13:00:00+00:00',
                'ram': {'used_mib': len(readings)*1024, 'total_mib': 16384, 'percent': 50},
                'gpu': None}
    monkeypatch.setattr('mailmind.resources.sample_resources', sample)
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    assert not readings and not app.metric
    app.button[0].click().run(timeout=15)
    before=app.session_state.result.copy()
    sampled=len(readings)
    app.run(timeout=15)
    assert len(readings)==sampled  # No idle collection after completion either.
    assert app.session_state.result == before
    assert not any(m.label in {'System RAM used','GPU activity','GPU memory used'} for m in app.metric)


def test_live_telemetry_refreshes_while_model_worker_fails(monkeypatch):
    import time
    from mailmind.improved import ModelUnavailable
    readings=[]
    def sample():
        readings.append(time.monotonic())
        return {'sampled_at':'2026-10-12T13:00:00+00:00','ram':None,'gpu':None}
    def fail(request, **kwargs):
        time.sleep(2.2)
        raise ModelUnavailable('controlled failure')
    monkeypatch.setattr('mailmind.resources.sample_resources',sample)
    monkeypatch.setattr('mailmind.pipeline.analyse',fail)
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    app.selectbox[1].set_value('improved').run()
    initial=len(readings)
    app.button[0].click().run(timeout=15)
    assert not app.exception and len(app.error)==1
    assert initial==0 and len(readings) >= 2  # Start of analysis and in-flight update.
    assert 'result' not in app.session_state
