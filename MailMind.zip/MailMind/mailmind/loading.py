"""Presentation-only loading card. Never receives email text or model output."""
from html import escape

PHASES = {
    'preparing': ('Preparing your email', 'Reading the selected text and building the analysis request.'),
    'model': ('Waiting for local Qwen', 'The local runtime is processing the request and generating JSON. This includes any runtime queue time; token progress is not reported.'),
    'validating': ('Checking the returned output', 'Checking the JSON structure, source evidence and supported dates. These checks cannot guarantee every interpretation is correct.'),
    'rules': ('Running the comparison baseline', 'Programmed patterns extract information. No AI model runs in this mode.'),
    'complete': ('Analysis ready', 'Validation finished. Review the extracted information against the email.'),
}


def loading_card(phase, elapsed, reading, model, approach):
    title, detail = PHASES[phase]
    ram, gpu = reading['ram'], reading['gpu']
    ram_value = f"{ram['used_mib']/1024:.1f} GiB" if ram else 'Unavailable'
    util = gpu['utilization_percent'] if gpu else None
    gpu_value = f'{util:.0f}%' if util is not None else 'Unavailable'
    mem = gpu['used_mib'] if gpu else None
    vram_value = f'{mem/1024:.2f} GiB' if mem is not None else 'Unavailable'
    if util is None:
        explanation = 'GPU activity is unavailable; this does not mean zero usage.'
    elif util == 0:
        explanation = 'No GPU compute was sampled just now. Model memory can stay allocated between computations; this alone does not prove a stall.'
    else:
        explanation = f'The NVIDIA GPU is active ({util:.0f}% sampled utilization). Other apps can contribute to this activity.'
    selected = 'No AI model · Rules only' if approach == 'baseline' else 'Configured model · ' + model
    steps = ['preparing', 'rules' if approach == 'baseline' else 'model', 'validating']
    current = steps.index(phase) if phase in steps else len(steps)
    step_html = ''.join(f'<span class="mm-step {"done" if i < current else "active" if i == current else ""}">{i+1} · {label}</span>'
                        for i, label in enumerate(['Prepare', 'Rules' if approach == 'baseline' else 'Qwen', 'Validate']))
    return f'''<aside class="mm-loading" aria-label="Live analysis activity">
      <div class="mm-loading-head"><span class="mm-orbit" aria-hidden="true"></span><div role="status" aria-live="polite"><strong>{escape(title)}</strong><div>{elapsed:.0f} seconds elapsed · Working locally</div></div></div>
      <p class="mm-runtime">{escape(selected)}</p><div class="mm-steps">{step_html}</div>
      <p>{escape(detail)}</p><strong class="mm-hardware-label">Live laptop usage</strong>
      <div class="mm-live-grid"><div><small>System RAM</small><b>{ram_value}</b></div><div><small>GPU activity</small><b>{gpu_value}</b></div><div><small>GPU memory</small><b>{vram_value}</b></div></div>
      <p class="mm-explanation">{escape(explanation)}</p>
      <small>Whole laptop / NVIDIA GPU 0, including other apps. Samples about every 2 seconds · {escape(reading['sampled_at'][11:19])} UTC. Elapsed time is not an ETA.</small>
    </aside>'''
