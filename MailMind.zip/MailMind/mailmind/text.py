import re
from bs4 import BeautifulSoup
from .schema import Message


# Do not interpret punctuation inside common identifiers as missing spaces.
COMPACT_BOUNDARY = re.compile(r"(?<=[.!?])(?=[A-Z][a-z])")
PROTECTED_TOKEN = re.compile(
    r"https?://\S+|www\.\S+|[\w.+-]+@[\w.-]+"
    r"|\b(?:[\w-]+\.)+(?:com|org|net|edu|gov|io|co|in)\b"
    r"|\b[\w.-]+\.(?:pdf|docx?|xlsx?|csv|txt|json|py|js)\b"
    r"|\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr)\.", re.I
)


def split_compact_sentences(text: str) -> list[str]:
    """Split joined sentences without inserting text or changing evidence spans."""
    protected = [match.span() for match in PROTECTED_TOKEN.finditer(text)]
    cuts = [m.start() for m in COMPACT_BOUNDARY.finditer(text)
            if not any(start < m.start() <= end for start, end in protected)]
    bounds = [0, *cuts, len(text)]
    return [text[start:end] for start, end in zip(bounds, bounds[1:])]


def canonical_text(message: Message) -> str:
    """Evidence is exact in this decoded text; HTML markup is not evidence."""
    if message.content_type == "text/plain":
        return message.body.replace("\r\n", "\n").replace("\r", "\n")
    soup = BeautifulSoup(message.body, "html.parser")
    for node in soup(["script", "style", "noscript", "head"]):
        node.decompose()
    # Preserve quoted HTML text in canonical source but exclude it from candidates.
    for node in soup.select("blockquote, .gmail_quote"):
        node.insert_before("\n> QUOTED REPLY\n")
    for node in soup.find_all(["p", "div", "br", "li", "tr", "h1", "h2", "h3"]):
        node.insert_before("\n")
        node.insert_after("\n")
    return soup.get_text(separator="", strip=False).strip()


def sentences(text: str) -> list[str]:
    kept = []
    for line in text.splitlines():
        line = line.strip()
        if re.match(r"^(--\s*$|On .+wrote:|From:|> QUOTED|Sent from my|Best regards[,!]?|Regards[,!]?|Thanks[,!]?\s*$)", line, re.I):
            break
        if line.startswith(">"):
            continue
        # Pasted subject headers and standalone salutations are context, not
        # extraction candidates. Canonical source is retained for evidence.
        if re.match(r"^Subject:\s*", line, re.I) or re.fullmatch(r"(?:Hi|Hello|Dear)\s+[^.!?]+[,!]", line, re.I):
            continue
        protected = [match.span() for match in PROTECTED_TOKEN.finditer(line)]
        boundaries = [m for m in re.finditer(r"(?<=[.!?])\s+|;\s+", line)
                      if not any(start < m.start() <= end for start, end in protected)]
        starts = [0] + [m.end() for m in boundaries]
        ends = [m.start() for m in boundaries] + [len(line)]
        for start, end in zip(starts, ends):
            sentence = line[start:end]
            kept.extend(s.strip() for s in split_compact_sentences(sentence) if s.strip())
    return kept


def suspicious(text: str) -> bool:
    return bool(re.search(r"ignore (?:all |previous |prior |the )*(?:instructions|rules)|system prompt|api[_ -]?key|access token|reveal .*secret|<\|.*?\|>", text, re.I))
