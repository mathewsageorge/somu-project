"""Render recorded results without inventing unavailable metrics."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default='results/model-size-comparison.json')
    parser.add_argument('--output', default='results/MODEL-SIZE-COMPARISON.md')
    args = parser.parse_args()
    report = json.loads((ROOT/args.input).read_text(encoding='utf-8'))
    lines = ['# Pretrained model comparison', '', f"Recorded UTC: {report['timestamp']}", '', report['note'], '',
             '| Set | Method | Task precision | Task recall | Task F1 | Event F1 | Mean latency (ms) |',
             '|---|---|---:|---:|---:|---:|---:|']
    for name, method in report['methods'].items():
        for dataset, run in method.get('datasets', {}).items():
            if run['status'] != 'completed':
                lines.append(f'| {dataset} | {name} — incomplete | — | — | — | — | — |')
                continue
            m = run['metrics']; t = m['task_detection']
            lines.append(f"| {dataset} | {name} | {t['precision']:.3f} | {t['recall']:.3f} | {t['f1']:.3f} | {m['event_detection']['f1']:.3f} | {m['mean_latency_ms']:.1f} |")
    lines += ['', '## Longer project-review email', '',
              'Counts are extraction records, not accuracy scores. The current rules split the slide-preparation and sharing instructions and keep report contents as a separate task. Owners from greetings/pronouns remain unresolved; no new coreference model was added.', '']
    for name, method in report['methods'].items():
        lines += [f'### {name}', '']
        pred = method.get('project_review', {})
        if 'tasks' not in pred:
            lines += ['Not completed; see machine-readable result.', '']
            continue
        lines += [f"{len(pred['tasks'])} task records; {len(pred['events'])} event records; {pred['latency_ms']:.1f} ms.", '']
        for task in pred['tasks']:
            lines.append(f"- [{task['status']}] {task['action']} — owner: {task['owner'] or 'unresolved'}; calendar deadline: {task['deadline'] or 'unresolved/not specified'}.")
        for event in pred['events']:
            lines.append(f"- Event: {event['description']}")
        lines += ['', 'Review notes:', ''] + [f'- {note}' for note in pred['ambiguities']] + ['']
    lines += ['## Interpretation limits', '',
              '- Both model methods use the same prompt, temperature 0, seed 42, schema and deterministic rules. Different families and model sizes are compared; this does not isolate parameter count alone.',
              '- The old model uses CPU inference and the candidate uses GPU offloading. Timing is a deployment comparison, not a controlled hardware benchmark. One sequential run and prompt caches limit timing conclusions.',
              '- These fictional sets have already been inspected during development. No result here is a new independent test estimate, proof of generalization, or human summary-factuality score.',
              '- Exact evidence matching does not prove a correct interpretation. The model still chooses sentences; owners, date normalization and thread reconciliation use the existing rules.',
              '- After this frozen comparison, review warnings were added for unclassified sentences and no-action labels that conflict with request/cancellation patterns. These checks disclose disagreement; they do not replace predictions with rule-generated tasks. See project-review-qwen35-labels.json for the inspected longer-email labels. The four missed instructions were explicitly labelled none.',
              '- Model weights were not trained. Before considering fine-tuning, collect independently checked longer emails with consent and freeze a fresh test set.',
              '- Per-case predictions, token usage, source hashes and advertised model identities are in the linked JSON. Local inference API cost is not a measured electricity or hardware cost.', '',
              f"Full measurements: [{Path(args.input).name}]({Path(args.input).name})."]
    (ROOT/args.output).write_text('\n'.join(lines)+'\n', encoding='utf-8')
