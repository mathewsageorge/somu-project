# MailMind implementation plan

1. Strict schemas, canonical email text, fictional development data, deterministic baseline, pasted-email demo.
2. Constrained LLM extraction with Ollama, separate held-out fixtures, evaluation and honest run records.
3. FastAPI boundary, MV3 TypeScript panel, local demo flow and accessible review/export controls.
4. Chrome Identity OAuth and API-based selection by Gmail ID or explicit search; no inbox scraping.
5. Local JSON export; Google Tasks/Calendar writes remain optional and disabled unless implemented with explicit confirmation.
6. Tests, build, integration checks, setup/security/research documentation and final feature status.

Architecture: side panel → selected Gmail API message/thread → local FastAPI → baseline or configured local model → schema/evidence validation → editable result. OAuth tokens stay in Chrome's token cache and never go to FastAPI. Streamlit calls the same pipeline directly. No database or email persistence. Model weights/credentials are prerequisites only for the model path; demo baseline is offline after dependency installation.
