"""Annotation integrity and evaluator behavior; never run NLP on reserved data."""
import hashlib
import json
import shutil
import sys
from pathlib import Path
import pytest
from scripts import evaluate_v2 as evaluation


def test_frozen_labels_are_valid_and_disjoint():
    dev, manifest = evaluation.load_split('development')
    reserved, _ = evaluation.load_split('reserved')
    assert len(dev) == 24 and len(reserved) == 12
    assert {c['id'] for c in dev}.isdisjoint(c['id'] for c in reserved)
    bodies = lambda rows: {m['body'].strip() for c in rows for m in c['messages']}
    assert bodies(dev).isdisjoint(bodies(reserved))
    assert all(c['reference_summary'] and c['annotation_status'].startswith('single-author') for c in dev+reserved)
    tags = {t for c in dev for t in c['tags']}
    assert {'no-task','multiple-tasks','thread','relative-date','ambiguous-date','reschedule',
            'malicious-instructions','html','quoted-reply','signature','compound','completion-update','derived-time'} <= tags
    for name,rows in [('development',dev),('reserved',reserved)]:
        assert manifest['splits'][name]['tasks'] == sum(len(c['gold']['tasks']) for c in rows)
        assert manifest['splits'][name]['events'] == sum(len(c['gold']['events']) for c in rows)


def test_reserved_execution_requires_explicit_release(monkeypatch):
    monkeypatch.setattr(sys,'argv',['evaluate_v2.py','--split','reserved','--output','results/should-not-exist'])
    monkeypatch.setattr(evaluation,'evaluate',lambda *args: pytest.fail('Reserved model inference must not execute'))
    with pytest.raises(SystemExit) as exc:
        evaluation.main()
    assert exc.value.code == 2


def test_changed_dataset_rejected(tmp_path,monkeypatch):
    destination=tmp_path/'data/evaluation_v2'
    destination.mkdir(parents=True)
    source=evaluation.ROOT/'data/evaluation_v2'
    for name in ['manifest.json','development.json']:
        shutil.copyfile(source/name,destination/name)
    with (destination/'development.json').open('a',encoding='utf-8') as stream:
        stream.write(' ')
    monkeypatch.setattr(evaluation,'ROOT',tmp_path)
    with pytest.raises(ValueError,match='hash changed'):
        evaluation.load_split('development')


def test_event_field_mismatch_not_hidden_by_detection():
    rows=[dict(id='case',gold=dict(tasks=[],events=[dict(message_id='m',quote='The meeting moved.',date_text='June 2',date='2027-06-02',time_text=None,timezone=None,status='announced')]))]
    run=dict(runs=[dict(id='case',prediction=dict(tasks=[],events=[dict(description='The meeting moved.',evidence=[dict(message_id='m',quote='The meeting moved.')],date_text='June 1',date='2027-06-01',time_text=None,timezone=None,status='announced')]))])
    evaluation.add_error_analysis(run,rows)
    assert run['event_field_exact_accuracy_on_matched_events']['date']==dict(correct=0,total=1,accuracy=0)
    assert {e['field'] for e in run['error_analysis']}=={'date_text','date'}


def test_missing_event_has_no_matched_field_denominator():
    rows=[dict(id='case',gold=dict(tasks=[],events=[dict(message_id='m',quote='The meeting moved.')]))]
    run=dict(runs=[dict(id='case',prediction=dict(tasks=[],events=[]))])
    evaluation.add_error_analysis(run,rows)
    assert run['event_field_exact_accuracy_on_matched_events']['date']['accuracy'] is None
    assert run['error_analysis'][0]['error']=='missed_or_boundary_mismatch'
