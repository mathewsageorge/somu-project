# Case 22: structured extraction update

12 October 2026. **Partial pass; useful improvements, remaining semantic errors.** Qwen3.5-4B-Q4_K_M was not replaced or fine-tuned. Rules Only and Previous AI remain selectable. The preceding structured implementation is frozen in `mailmind/structured_legacy.py` for comparison, including its known defects. No dependencies were added.

## Diagnosis and implementation

The original user observation (2 tasks, 1 event, 33.54 seconds) is a manual observation, not our measured baseline. Original exported JSON was unavailable. Our pre-change reproduction produced 3 tasks, but stripped collective owners because the model named people without citing the greeting. Separate owner/participant evidence fields now allow contextual attribution to be validated without inferring names globally.

The old event representation selected a date-bearing sentence as its description and UI heading. It had no short title or model-supplied schedule history. The new schema carries a source-backed title, participants, logistics and previous schedule separately; the UI renders them.

Summary rejection was partly an evidence problem: a long claim contained a number unsupported by its cited rows, so the whole claim was dropped. Short separately cited claims and a model-selected fact checklist reduce this failure's scope. They do not guarantee semantic accuracy or full coverage. An experimental task checklist encouraged over-extraction and was removed after development counterchecks.

We also found a concrete arithmetic defect: the clock parser removed the trailing `PM` as though it were a timezone. The legacy result calculated 02:45 instead of 14:45. The corrected helper preserves AM/PM; tests cover noon, midnight and date rollover. This is validation/arithmetic, not a task-detection rule.

Pre-change finish reason was `stop`, with 456 output tokens against the 3,000-token limit. Output-token exhaustion did not explain that run. Final timing runs also stopped normally. A bounded summary field can nevertheless end awkwardly at its character limit (seen in Case 21); normal completion does not mean good prose.

Implementation details: [design](../docs/CASE22-DESIGN.md), [model JSON schema](../docs/structured-model.schema.json), [annotation policy](../data/CASE22-ANNOTATION.md).

## Case 22 before and after

| Property | Earlier structured reproduction | Updated release run |
|---|---|---|
| Logical task cards | 3; collective owners absent after validation | 3; Priya, Kiran, and collective preparation |
| Collective owners | Unresolved | Priya, Kiran, Meera, with cited context |
| Preparation arrival | Incorrect 02:45 in comparison run | 22 October 2026, 14:45 source-local |
| Priya deadline / requirement | Existing extraction | October 19; blocker requirement retained |
| Kiran deadline / requirement | Existing extraction | October 20; rollback in action, backup requirement retained |
| Meeting | Date-bearing sentence heading | Named deployment readiness meeting |
| Meeting history | Not represented by structured output | October 20, 11 AM → October 22, 3 PM; one active event |
| Logistics | Not a separate field | Unchanged link and agenda retained with evidence |

`IST` stays the original timezone wording. With no confirmed regional timezone, 14:45 is a source-local calculation, not a resolved UTC instant. Event linkage and contextual owners remain reviewable model interpretations.

Summary audit of the final release run: QA completion, defect resolution, both main deadlines, Meera's uploaded evidence, rescheduling, early attendance, deployment dependencies and unfinalized deployment date are present. The summary still omits unchanged link/agenda, the blocker and rollback details, and the explicit statement that Meera needs no further work. Those details are available in the task/event cards or source, but **summary completeness is not fully fixed**. No independent human factuality score is claimed.

## Development regression results

Eight same-author fictional development cases were executed. They were inspected during iteration and are not held-out research evidence. Earlier baseline/AI outputs use identical inputs from `case22-development-final`; despite that directory's name, its structured output is an intermediate trial. Final new outputs are in `case22-release-validation`. Intermediate failures remain archived rather than overwritten.

| Case | Expected tasks/events | Final tasks/events | Semantic review |
|---|---:|---:|---|
| Manual 22 | 3 / 1 | 3 / 1 | Main tasks, owners, dates, title/history and 14:45 arrival correct; summary omissions remain |
| Manual 21 | 3 / 1 | 3 / 1 | Owners and 10:20 arrival correct; summary incomplete, one claim rejected and remaining prose ends awkwardly |
| Both recipients, rescheduled | 1 / 1 | 1 / 1 | Correct owners, 13:40 arrival/history; summary's phrasing of meeting time versus arrival is ambiguous |
| Everyone, known recipients | 1 / 1 | 1 / 1 | Correct group attribution; conditional publication not a task |
| Entire unnamed team | 1 / 1 | 1 / 1 | Task retained with unknown members; event date promoted to task deadline without an explicit deadline instruction |
| You and your team | 1 / 1 | 2 / 1 | Extra dependency task; misses known recipient Eva; summary incorrectly makes Eva the requester |
| Completed, no action | 0 / 0 | 0 / 0 | No false pending task or future event |
| Two meetings, ambiguous instruction | 1 / 2 | 1 / 2 | Retains task and owners, leaves link/arrival null; first event has unnecessary same-as-current history |

Task count agreement is not accuracy. A qualitative matching audit finds the 11 expected logical actions represented, plus one extra conditional deployment card, but ownership, deadline interpretation and summary errors remain. This is a development observation, not a blind precision/recall benchmark. All eight final outputs passed structured/exact-quotation validation; **an existing quote does not prove that its interpretation is correct**. In particular, the Eva requester hallucination demonstrates the limit of lexical/evidence checks.

## Timing and memory

Two repeats per method on the identical Case 22 input, same loaded local model, sequential calls and rotated method order. No model-runtime changes were made. The computer was not reserved exclusively; cache, power and thermal conditions were not controlled. These small samples cannot establish a general performance distribution.

| Method | End-to-end median (range), seconds | HTTP median | Server prompt median | Server generation median | Input/output tokens per run |
|---|---:|---:|---:|---:|---:|
| Previous sentence-selection AI | 9.23 (8.84–9.63) | 8.67 | 0.88 | 7.47 | 1490 / 145 |
| Earlier structured AI | 26.18 (26.07–26.28) | 25.72 | 0.90 | 24.26 | 1699 / 456 |
| Updated structured AI | 59.45 (58.95–59.95) | 58.97 | 0.23 | 58.50 | 1952 / 1059 |

The updated method is slower: approximately 2.27 times the earlier structured median. It generates 2.32 times as many tokens, and generation dominates measured time. This supports output length as a major contributor, without attributing all differences to structured decoding. Cache effects are visible in prompt timings. The separate eight-case run measured 62.63 seconds for Case 22.

GPU sampled peak was 2,415 MiB for each method. System-wide RAM peaks were 13,806 MiB (previous), 14,243 MiB (earlier structured), and 13,778 MiB (updated). Samples are taken every two seconds and can miss peaks. These are whole-machine measurements, not model-process allocation or a memory saving claim. Local inference has no metered API fee; electricity cost was not measured. No per-process peak or controlled training-memory estimate is available.

Raw measured results, usage, server timing, source hashes and source snapshots: [comparison JSON](case22-comparison.json), [release validation](case22-release-validation/results.json), [timing repeats](case22-timing-repeats/results.json). Raw fictional model responses are retained only in these explicit research artifacts, not normal demo logging.

## Verification and next research step

173 Python tests passed; one existing Starlette/httpx deprecation warning. Tests include grounding, schema fields, cancellations, prompt-injection handling and arrival arithmetic. Extension TypeScript/build passed. Software tests verify implementation contracts, not NLP accuracy. See `python-tests-case22.xml`. Browser verification is recorded separately in `case22-browser-verification.md`; Google OAuth and the new extension rendering have not been live reverified in this update.

Keep this implementation experimental. The next evidence-based improvement should target semantic attribution and summary coverage on a newly annotated development batch, with independent review and a fresh unseen set only after freezing the pipeline. Reduce duplicated generated fields only after measuring their grounding benefit. Do not tune repeatedly on the reserved historical test set or claim this change solves all email language understanding.
