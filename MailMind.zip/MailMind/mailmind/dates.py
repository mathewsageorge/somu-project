import re
from datetime import date, timedelta
from zoneinfo import ZoneInfo
from .schema import Message

MONTHS = 'January February March April May June July August September October November December'.split()
MONTH_PATTERN = '(?:' + '|'.join(MONTHS) + ')'
WEEKDAY_PATTERN = '(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)'
NAMED_DATE_PATTERN = rf'(?:\d{{1,2}}\s+{MONTH_PATTERN}(?:\s+\d{{4}})?|{MONTH_PATTERN}\s+\d{{1,2}}(?:,?\s+\d{{4}})?)'
DATE_PATTERN = rf"\b(?:{WEEKDAY_PATTERN},?\s+{NAMED_DATE_PATTERN}|\d{{4}}-\d{{2}}-\d{{2}}|tomorrow|today|next\s+{WEEKDAY_PATTERN}|{WEEKDAY_PATTERN}|\d{{1,2}}/\d{{1,2}}(?:/\d{{2,4}})?|{NAMED_DATE_PATTERN}|end of (?:day|week))\b"
CLOCK_PATTERN = r'(?:\d{1,2}(?::\d{2})?\s*(?:am|pm)\b|\d{2}:\d{2}\b)'


def deadline_text(text: str) -> str | None:
    """Keep an exact date/time span, excluding subsequent action clauses."""
    marker = re.search(r'\b(?:by|before|due|deadline(?: is|:)?)\s+(.+)', text, re.I)
    if not marker:
        return None
    tail = marker.group(1).rstrip('.!?')
    # Ignore opening Markdown emphasis for parsing, preserving the date/time
    # itself as an exact source substring for evidence validation.
    tail = re.sub(r'^(?:\*\*|__)', '', tail)
    found = re.match(DATE_PATTERN, tail, re.I)
    if found:
        # Case-sensitive zone recognition avoids consuming words such as "and".
        end = found.end()
        clock = re.match(rf'\s+at\s+{CLOCK_PATTERN}', tail[end:], re.I)
        if clock:
            end += clock.end()
            zone = re.match(r'\s+(?:[A-Za-z_]+/[A-Za-z_]+|[A-Z]{2,5})\b', tail[end:])
            if zone:
                end += zone.end()
        return tail[:end]
    return tail


def date_text(text: str) -> str | None:
    m = re.search(DATE_PATTERN, text, re.I)
    return m.group() if m else None


def normalize_date(wording: str | None, message: Message) -> tuple[str | None, str | None]:
    if wording is None:
        return None, None
    wording = wording.strip()
    if (wording.startswith('**') and wording.endswith('**')) or (wording.startswith('__') and wording.endswith('__')):
        wording = wording[2:-2]
    weekday = re.fullmatch(rf'({WEEKDAY_PATTERN}),?\s+({NAMED_DATE_PATTERN}(?:\s+at\s+{CLOCK_PATTERN}(?:\s+(?:[A-Za-z_]+/[A-Za-z_]+|[A-Z]{{2,5}}))?)?)', wording, re.I)
    if weekday:
        normalized, reason = normalize_date(weekday[2], message)
        if normalized and date.fromisoformat(normalized).strftime('%A').lower() != weekday[1].lower():
            return None, 'Weekday conflicts with calendar date; review original wording.'
        return normalized, reason
    # Normalize the calendar date only. Preserve the clock and zone in original
    # wording; do not imply a resolved instant or convert ambiguous abbreviations.
    with_time = re.fullmatch(rf'({DATE_PATTERN})\s+at\s+{CLOCK_PATTERN}(?:\s+(?:[A-Za-z_]+/[A-Za-z_]+|[A-Z]{{2,5}}))?', wording, re.I)
    if with_time:
        wording = with_time.group(1)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", wording):
        try:
            return date.fromisoformat(wording).isoformat(), None
        except ValueError:
            return None, "Invalid calendar date; review original wording."
    named = re.fullmatch(rf'(\d{{1,2}})\s+({MONTH_PATTERN})\s+(\d{{4}})', wording, re.I)
    month_first = re.fullmatch(rf'({MONTH_PATTERN})\s+(\d{{1,2}}),?\s+(\d{{4}})', wording, re.I)
    if named or month_first:
        day, month, year = named.groups() if named else (month_first[2], month_first[1], month_first[3])
        try:
            return date(int(year), [m.lower() for m in MONTHS].index(month.lower()) + 1, int(day)).isoformat(), None
        except ValueError:
            return None, "Invalid calendar date; review original wording."
    if re.fullmatch(rf'(?:\d{{1,2}}\s+{MONTH_PATTERN}|{MONTH_PATTERN}\s+\d{{1,2}})', wording, re.I):
        return None, "Year is not specified for this date; confirm it rather than silently borrowing a year from another sentence."
    if wording.lower() in ("tomorrow", "today"):
        if message.sent_at is None or message.timezone is None:
            return None, "Relative date needs sender timestamp and confirmed timezone."
        local = message.sent_at.astimezone(ZoneInfo(message.timezone)).date()
        return (local + timedelta(days=wording.lower() == "tomorrow")).isoformat(), None
    return None, "Date wording is ambiguous or outside conservative normalization; review it."
