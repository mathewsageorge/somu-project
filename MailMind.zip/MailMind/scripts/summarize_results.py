import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
data=json.loads((root/'results/test_results.json').read_text(encoding='utf-8'))
rows=['# Recorded experiments','',f"Run: {data['timestamp_utc']}. Split: {data['split']}, {data['cases']} fictional cases.",
      '', '| Method | Task P | Task R | Task F1 | TP / FP / FN | Event F1 | Mean latency |', '|---|---:|---:|---:|---|---:|---:|']
for name, run in data['approaches'].items():
    if run['status']!='completed':
        rows.append(f'| {name} | blocked | — | — | — | — | — |')
        continue
    m=run['metrics'];t=m['task_detection']
    rows.append(f"| {name} | {t['precision']:.3f} | {t['recall']:.3f} | {t['f1']:.3f} | {t['tp']} / {t['fp']} / {t['fn']} | {m['event_detection']['f1']:.3f} | {m['mean_latency_ms']:.2f} ms |")
rows+=['','## Field and evidence results','', '| Method | Matched tasks | Owner accuracy | Original deadline accuracy | Normalized date accuracy | Status accuracy | Exact evidence | Summary key-span coverage |', '|---|---:|---:|---:|---:|---:|---|---|']
for name, run in data['approaches'].items():
    if run['status']!='completed':continue
    m=run['metrics'];a=m['field_exact_accuracy_on_matched_tasks'];e=m['evidence_validity'];s=m['summary_gold_span_coverage']
    rows.append(f"| {name} | {m['matched_task_denominator']} | {a['owner']:.3f} | {a['deadline_text']:.3f} | {a['deadline']:.3f} | {a['status']:.3f} | {e['valid']}/{e['total']} | {s['covered']}/{s['total']} |")
rows+=['', 'Non-null owner and deadline precision/recall/F1, with unmatched tasks included, are recorded separately in test_results.json. Both methods share these extraction rules; perfect values on these sparse fixtures do not establish robust entity/date understanding.',
       '', 'Human summary factuality: **not measured**. Exact evidence means text is present, not that its interpretation is correct. Key-span coverage is easy on these very short messages and includes only the 13 annotated spans. No calibrated confidence values are reported.',
       '', '## Error inventory','']
gold={c['id']:c['gold'] for c in json.loads((root/'data/test.json').read_text(encoding='utf-8'))}
for name, run in data['approaches'].items():
    if run['status']!='completed':continue
    rows.append(f'### {name}')
    rows.append('')
    for r in run['runs']:
        g=gold[r['id']]
        for idx in r['missed_gold_indices']:rows.append(f"- {r['id']}: missed task — {g['tasks'][idx]['quote']}")
        for p in r['prediction']['tasks']:
            match=next((t for t in g['tasks'] if t['quote']==p['action'] and t['message_id']==p['evidence'][0]['message_id']),None)
            if match is None:rows.append(f"- {r['id']}: extra task — {p['action']}")
            elif match['status']!=p['status']:rows.append(f"- {r['id']}: status {p['status']} vs gold {match['status']} — {p['action']}")
        pe={(e['evidence'][0]['message_id'],e['description']) for e in r['prediction']['events']}
        ge={(e['message_id'],e['quote']) for e in g['events']}
        for _,q in sorted(ge-pe):rows.append(f'- {r["id"]}: missed event — {q}')
        for _,q in sorted(pe-ge):rows.append(f'- {r["id"]}: extra event — {q}')
    rows.append('')
rows+=['## Interpretation and reproducibility','',
       'The small pretrained model improves recall but introduces false positives and confuses meeting announcements with tasks. The baseline remains the default. The proposed “improved” method is not empirically superior on this test. No test-driven prompt tuning was performed after this comparison. Date/owner rules and exact text provenance alone cannot correct wrong intent classification.',
       '', 'CPU runtime: llama.cpp b11443, four CPU threads, context 8192, temperature 0, seed 42; Qwen2.5-0.5B-Instruct Q4_K_M. Download URLs, pinned model revision and hashes are in model-manifest.json; prompt/source hashes are in test_results.json. Measured process working set was approximately 0.63 GB during the initial run. Latencies are one sequential run after development warm-up, with runtime prompt caching enabled; no cold-start or throughput claim. Local API billing is absent; electricity/hardware cost was not measured (null). Per-case token usage is retained.',
       '', 'An early development run rejected invalid repeated/out-of-range model IDs. Candidate-dependent schema bounds and strict post-validation were added before the final comparison. A transport schema-format experiment also failed validation; these integration/debug attempts are not research performance runs. Final results were regenerated after the HTML inline-text correctness fix, which did not change labelled fixture semantics. This is author-created testing, not a blinded benchmark.',
       '', 'The fictional sample is small and template-related. There are no independent annotations, statistical significance claims, calibrated uncertainty estimates, real-email claims or research-novelty claims. Follow docs/RESEARCH.md for the independent consent-based study required before deployment.']
(root/'results/EXPERIMENTS.md').write_text('\n'.join(rows)+'\n',encoding='utf-8')
print('Generated results/EXPERIMENTS.md from actual evaluation artifacts.')
