# Try the broader evaluation

Latest update: the 12 reserved cases have now been evaluated on the frozen version. Read `results/FINAL-RESERVED-EVALUATION.md`. They remain excluded from the demo, and must no longer be called unseen in a later iteration. The instructions below still work for practising on the development examples; their “unrun” references describe the earlier phase.

Update, 8 October: cancellation/completion tracking was subsequently fixed using development cases. See `results/TASK-STATE-UPDATE.md` for the before/after results. The historical comparison below is preserved; the current AI run finds 22/22 task records with correct matched statuses on this familiar development set. This is tuned performance, not unseen accuracy.

An **expected answer** is our manually specified interpretation of an email, written before seeing the program's answer. A **development case** is an example we can inspect while improving the system. A **reserved case** is saved for a later evaluation after the system is frozen. The 12 reserved cases here have not been run; because the assistant authored both sets, they are not a blind external benchmark.

## What is ready

- 24 new fictional development cases with 22 labelled task records and four events. Some task records represent cancelled, superseded or completed work; 22 does not mean 22 currently pending actions.
- 12 separate reserved cases, excluded from the demo and this prediction run.
- Exact expected owners, original deadline wording, calendar dates, final statuses, event fields and summary points.
- A completed rules-versus-AI comparison using the same 24 inputs, with no production extraction changes made during the comparison.
- A blank human summary-review worksheet. No human factuality scores or annotation-agreement results have been fabricated.

## Five examples to try first

1. Open http://127.0.0.1:8502/ and choose **Example thread**. Use the **Fictional example** dropdown to find the `v2-dev-...` examples. This preserves sender timestamps, timezones, HTML format and thread boundaries automatically; do not concatenate multi-message threads into the paste box for this experiment.
2. Start with **v2-dev-01**. The full email appears immediately under **Selected email**, before the analysis controls. Conversations show each message separately. Read it, then open **Expected answer (fictional development data)**. It should have two requests, for Leena and Omar, with different deadlines. Raw JSON is available separately under **Technical input details**.
3. Select **Rules only (baseline)** and click **Analyse**. Compare actions, owners, dates and status with the expected answer. Then select **AI model + rule checks** and click **Analyse** again; changing the selector alone does not run a fresh analysis.
4. Try **v2-dev-02**: informational email, no task. **v2-dev-03**: a request using “reconcile,” which the rules missed. **v2-dev-09**: meeting rescheduled to 4 February 2027 at 2 PM UTC. **v2-dev-20**: both historical request and cancellation should be marked cancelled. **v2-dev-21**: the earlier delivery-list request should be completed, with the later completion sentence as evidence.
5. Use **Export JSON** if you want to keep a result. Record disagreements; do not assume either method is correct merely because it produced output.

Expected answers are draft annotations and can also be wrong. Review disputed cases with your supervisor or another annotator and document corrections as a new label version. The full answer key is `data/evaluation_v2/DEVELOPMENT-ANSWER-KEY.md`.

## Original comparison, before lifecycle fixes

| Method | Labelled task records found | Extra tasks | Task F1 | Mean time per email/thread |
|---|---|---|---|---|
| Rules only | 20 / 22 | 0 | 0.952 | 1.2 ms |
| AI plus rule checks | 21 / 22 | 0 | 0.977 | 1761.9 ms |

F1 combines precision (how many returned tasks match labels) and recall (how many labelled tasks were found). This is exact-span scoring on a small, same-author fictional development set, not real-world accuracy. Both found all four labelled events. Rules missed two indirect/unrecognised-verb requests. The model missed one cancellation; both methods failed to mark a previously requested delivery as completed. High detection F1 therefore does not establish correct final task state.

See `results/evaluation-v2-development/REPORT.md` for the actual errors, `results.json` for field/evidence/summary metrics and predictions, and `human-review.csv` for unfilled human summary ratings. Give raters separate copies and keep the adjacent method-key file away from them. The source snapshot and hashes preserve the exact NLP implementation used for this run.

The next research decision should follow human review of the expected answers and the recorded cancellation/completion failures. The reserved set remains locked until a later explicitly authorized final evaluation. No fine-tuning or Google setup was needed for this step.
