"""Development regressions; provisional inputs are not held-out evaluation."""
import json
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from mailmind.pipeline import analyse, materialize
from mailmind.schema import AnalysisRequest, Message, validate_evidence
from mailmind.text import sentences

ROOT = Path(__file__).resolve().parents[1]
BODY = next(c['body'] for c in json.loads((ROOT/'data/manual_review_provisional.json').read_text())['cases'] if c['id']=='manual-19')


def run(body=BODY):
    return analyse(AnalysisRequest(messages=[Message(id='m', body=body)]))


def test_original_and_current_schedule_with_exact_evidence():
    result = run()
    assert len(result.events) == 1
    event = result.events[0]
    assert (event.status, event.date, event.time_text) == ('rescheduled','2026-10-16','3:30 PM')
    assert event.timezone_raw == 'IST' and event.timezone is None
    assert (event.original_schedule.date, event.original_schedule.time_text) == ('2026-10-15','11:00 AM')
    assert event.original_schedule.timezone_raw == 'IST'
    assert len(event.evidence) == 3
    validate_evidence(result, {'m': BODY})


def test_classifier_undated_intro_collapses_without_changing_labels():
    rows = sentences(BODY)
    result = materialize([Message(id='m',body=BODY)], [('m',s,'event') for s in rows[:3]], 'improved','test-classifier')
    assert len(result.events) == 1 and result.events[0].status == 'rescheduled'


@pytest.mark.parametrize('body',[
    BODY.replace('The updated meeting schedule is', 'The updated interview schedule is'),
    BODY.replace('The meeting was originally planned', 'The budget meeting was originally planned'),
    BODY.replace('The updated meeting schedule is', 'A separate meeting is'),
    BODY.replace('The updated meeting schedule is', 'The other meeting schedule is'),
    BODY.replace('Due to an unexpected scheduling conflict, we need to reschedule our project discussion meeting.', 'Two different meetings are being discussed.'),
    BODY.replace('we need to', 'we do not need to'),
    BODY.replace('we need to', 'if necessary, we will'),
])
def test_distinct_or_ambiguous_references_not_merged(body):
    result = run(body)
    assert len(result.events) == 2
    assert all(e.original_schedule is None for e in result.events)


@pytest.mark.parametrize('extra',[
    'Another meeting is on 2026-10-20 at 2 PM UTC.',
    'The meeting on October 16, 2026 is cancelled.',
])
def test_extra_or_cancelled_event_blocks_unsafe_merge(extra):
    result = run(BODY.replace('The meeting link', extra+'\nThe meeting link'))
    assert len(result.events) == 3
    assert all(e.original_schedule is None for e in result.events)
    assert result.events[0].status == result.events[1].status == 'needs_review'


def test_missing_destination_not_merged():
    result = run(BODY.replace('October 16, 2026, at 3:30 PM IST', 'a date to be decided'))
    assert all(e.original_schedule is None for e in result.events)


def test_no_cross_message_guessing():
    rows = sentences(BODY)
    result = analyse(AnalysisRequest(messages=[Message(id='a',body='\n'.join(rows[:2])), Message(id='b',body=rows[2])]))
    assert len(result.events) == 2
    assert all(e.original_schedule is None for e in result.events)


def test_fabricated_original_schedule_evidence_rejected():
    result = run()
    result.events[0].original_schedule.time_text = '8:15 PM'
    with pytest.raises(ValueError, match='Extracted field'):
        validate_evidence(result, {'m':BODY})


def test_streamlit_displays_status_both_schedules_and_raw_zone():
    app = AppTest.from_file(str(ROOT/'demo.py')).run(timeout=15)
    app.radio[0].set_value('Paste email').run()
    app.text_area[0].set_value(BODY)
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert len(app.session_state.result['events']) == 1
    assert any('Status: Rescheduled' in x.value for x in app.markdown)
    assert any('Current schedule: 2026-10-16' in x.value and 'IST' in x.value for x in app.caption)
    assert any('Previous schedule (no longer current): 2026-10-15' in x.value for x in app.caption)
