chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(() => { /* no private logging */ });
