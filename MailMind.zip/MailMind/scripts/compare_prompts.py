"""Run frozen prompt comparisons on fictional fixtures; preserve older reports."""
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import mailmind.improved as model_module
from evaluate import evaluate

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',default='data/dev.json')
    parser.add_argument('--output',default='results/prompt-development.json')
    args=parser.parse_args()
    os.environ['MODEL_PROVIDER']='llamacpp'
    path=ROOT/args.data
    rows=json.loads(path.read_text(encoding='utf-8'))
    revised=model_module.SYSTEM
    report={'timestamp_utc':datetime.now(timezone.utc).isoformat(),
            'dataset':args.data,'dataset_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'model':'Qwen2.5-0.5B-Instruct-Q4_K_M','temperature':0,'seed':42,
            'source_sha256':{n:hashlib.sha256((ROOT/'mailmind'/n).read_bytes()).hexdigest() for n in ['improved.py','pipeline.py','schema.py','text.py','dates.py']},
            'note':'Same model weights and grounding rules. Revised instructions add examples and an explicit none category to the classification schema. Original model retains its two-label schema. No model training.',
            'runs':{}}
    for name,prompt in [('rules',None),('original_model',(ROOT/'docs/prompts/original-v1.txt').read_text(encoding='utf-8')),('revised_model',revised)]:
        if prompt is not None:
            model_module.SYSTEM=prompt
            model_module.CLASSIFICATION_KINDS=['task','event'] if name=='original_model' else ['task','event','none']
        run=evaluate(rows,'baseline' if prompt is None else 'improved')
        if prompt is not None:
            run['prompt_sha256']=hashlib.sha256(prompt.encode()).hexdigest()
            run['allowed_labels']=model_module.CLASSIFICATION_KINDS.copy()
        report['runs'][name]=run
        (ROOT/args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps({'method':name,'status':run['status'],'metrics':run['metrics']},indent=2),flush=True)
    (ROOT/'docs/prompts/revised-v3.txt').write_text(revised,encoding='utf-8')
