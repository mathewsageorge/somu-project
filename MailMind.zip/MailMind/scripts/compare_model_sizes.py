"""Same prompt/rules/inputs across local models. Existing data are not unseen."""
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluate import evaluate
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message
from mailmind.improved import SYSTEM, ModelUnavailable


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='results/model-size-comparison.json')
    args = parser.parse_args()
    destination = ROOT/args.output
    if destination.exists():
        raise SystemExit('Choose a new output filename to preserve previous measurements.')
    report = {'timestamp': datetime.now(timezone.utc).isoformat(),
              'note': 'Same prompt and rules; previously inspected development/diagnostic cases. Not an independent held-out accuracy estimate. No fine-tuning.',
              'prompt_sha256': hashlib.sha256(SYSTEM.encode()).hexdigest(),
              'source_sha256': {n: hashlib.sha256((ROOT/'mailmind'/n).read_bytes()).hexdigest()
                                for n in ['text.py','dates.py','pipeline.py','improved.py','schema.py']},
              'temperature': 0, 'seed': 42, 'datasets': {}, 'methods': {}}
    datasets = {}
    for name in ['dev', 'event_challenge_v2']:
        source = ROOT/'data'/f'{name}.json'
        datasets[name] = json.loads(source.read_text(encoding='utf-8'))
        report['datasets'][name] = {'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'cases': len(datasets[name])}
    body = (ROOT/'data/regression_project_review.txt').read_text(encoding='utf-8')
    report['regression_sha256'] = hashlib.sha256(body.encode()).hexdigest()
    def save():
        destination.write_text(json.dumps(report, indent=2), encoding='utf-8')
    for name, url, model in [('rules', None, None),
                             ('qwen25_05b', 'http://127.0.0.1:8081', 'Qwen2.5-0.5B-Instruct-Q4_K_M'),
                             ('qwen35_4b', 'http://127.0.0.1:8082', 'Qwen3.5-4B-Q4_K_M')]:
        approach = 'baseline' if url is None else 'improved'
        method = {'model': model, 'endpoint': url, 'datasets': {}}
        report['methods'][name] = method
        if url:
            os.environ.update(MODEL_PROVIDER='llamacpp', LLAMACPP_URL=url, LLAMACPP_MODEL=model)
            try:
                with httpx.Client(timeout=10, trust_env=False) as client:
                    health = client.get(url+'/health'); health.raise_for_status()
                    models = client.get(url+'/v1/models'); models.raise_for_status()
                method['advertised_models'] = models.json()
            except httpx.HTTPError:
                method['status'] = 'blocked: local server unavailable'
                save()
                continue
        method['status'] = 'running'
        for dataset, rows in datasets.items():
            run = evaluate(rows, approach)
            method['datasets'][dataset] = run
            print(json.dumps({'method':name,'dataset':dataset,'status':run['status'],'metrics':run['metrics']}), flush=True)
            save()
        try:
            r = analyse(AnalysisRequest(messages=[Message(id='pasted-1', body=body)], approach=approach))
            method['project_review'] = r.model_dump(mode='json')
            print(json.dumps({'method':name,'project_review_tasks':[t.action for t in r.tasks],
                              'project_review_events':[e.description for e in r.events]}), flush=True)
        except ModelUnavailable:
            method['project_review'] = {'status': 'blocked: local model unavailable or invalid output'}
        method['status'] = ('completed' if all(r['status']=='completed' for r in method['datasets'].values())
                            and 'tasks' in method['project_review'] else 'partial')
        save()
