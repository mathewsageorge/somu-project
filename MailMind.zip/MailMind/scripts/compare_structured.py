"""Reproducible development comparison; no reserved inputs. Saves fictional outputs only."""
import argparse, ctypes, hashlib, json, subprocess, sys, threading, time
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from dotenv import load_dotenv
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, validate_evidence
from mailmind.text import canonical_text

class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('total',ctypes.c_ulonglong),('available',ctypes.c_ulonglong),('page_total',ctypes.c_ulonglong),('page_available',ctypes.c_ulonglong),('virtual_total',ctypes.c_ulonglong),('virtual_available',ctypes.c_ulonglong),('extended',ctypes.c_ulonglong)]

def sample():
    r={}
    try:
        m=Memory();m.length=ctypes.sizeof(m);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        r['system_ram_used_mib']=(m.total-m.available)/1048576
    except (AttributeError,OSError): pass
    try:
        output=subprocess.run(['nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=4,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        mem,util=output.stdout.splitlines()[0].split(',')
        r.update(gpu_memory_used_mib=float(mem),gpu_utilization_percent=float(util))
    except (OSError,ValueError,IndexError,subprocess.TimeoutExpired):pass
    return r

def run():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    dest=Path(args.output);dest.mkdir(parents=True,exist_ok=False)
    load_dotenv(ROOT/'.env')
    dev=json.loads((ROOT/'data/dev.json').read_text())
    ids={'dev-multiple','dev-information','dev-html','dev-quoted','dev-ambiguous','dev-cancel','dev-injection'}
    cases=[c for c in dev if c['id'] in ids]
    manual=json.loads((ROOT/'data/manual_case_21.json').read_text())['cases'][0]
    tasks=[{'quote':q,'owners':o,'deadline':d,'status':'pending'} for q,o,d in [
        ('Aisha, please complete the UAT testing and share your observations by October 12, 2026.',['Aisha'],'2026-10-12'),
        ('Rahul, could you prepare the testing report and send it to the team by October 13, 2026?',['Rahul'],'2026-10-13'),
        ('All three of you should join the meeting 10 minutes early to verify the presentation setup.',['Aisha','Rahul','Neha'],None)]]
    cases.append({'id':manual['id'],'messages':[{'id':manual['id'],'body':manual['body']}],'gold':{'tasks':tasks,'events':[{'quote':'Our project review meeting is scheduled for October 14, 2026, at 10:30 AM IST.'}]}})
    p=json.loads((ROOT/'data/manual_review_provisional.json').read_text())
    c=next(c for c in p['cases'] if c['id']=='manual-19')
    cases.append({'id':'manual-19-reconstruction','messages':[{'id':'m','body':c['body']}],'gold':{'tasks':[],'events':[{'quote':'The updated meeting schedule is October 16, 2026, at 3:30 PM IST.'}]}})
    (dest/'inputs-and-labels.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
    record={'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Nine inspected development cases, same-author draft labels. Conditional courtesy blocker request in manual21 is review information, not a fourth deliverable. Manual19 reconstructed. Not held-out accuracy.',
            'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'mailmind').glob('*.py'))},'runs':[]}
    for c in cases:
        for method in ['baseline','improved','structured']:
            stop=threading.Event();samples=[]
            def monitor():
                while not stop.is_set():
                    samples.append(sample());stop.wait(2)
            thread=threading.Thread(target=monitor,daemon=True);thread.start()
            row={'case_id':c['id'],'method':method}
            try:
                req=AnalysisRequest(messages=c['messages'],approach=method)
                r=analyse(req);validate_evidence(r,{m.id:canonical_text(m) for m in req.messages})
                row['output']=r.model_dump(mode='json');row['evidence_valid']=True
                expected=c['gold']['tasks'];used=set();matched=[]
                for t in r.tasks:
                    candidates=[i for i,g in enumerate(expected) if i not in used and (t.action.rstrip('.!?') in g['quote'] or g['quote'].rstrip('.!?') in t.action)]
                    if candidates:
                        idx=candidates[0];used.add(idx);g=expected[idx]
                        owners=t.owners or ([t.owner] if t.owner else [])
                        target=g.get('owners', [g['owner']] if g.get('owner') else [])
                        matched.append({'owner_correct':set(owners)==set(target),'deadline_correct':t.deadline==g.get('deadline'),'status_correct':t.status==g.get('status','pending')})
                row['metrics']={'tp':len(used),'fp':len(r.tasks)-len(used),'fn':len(expected)-len(used),'matched_fields':matched,'event_count':len(r.events),'expected_event_count':len(c['gold']['events'])}
            except Exception as exc:
                row['error_type']=type(exc).__name__ # Do not expose sensitive error payloads.
            finally:
                stop.set();thread.join(timeout=6)
            row['resources']={'sample_interval_seconds':2,'samples':len(samples),'sampled_peaks':{k:max(s[k] for s in samples if k in s) for k in {k for s in samples for k in s}},'scope':'System-wide RAM and GPU, including runtime and other apps; sampled peaks, not allocated model-only memory. Short baseline calls can overlap sampling.'}
            record['runs'].append(row)
            (dest/'results.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
            print(c['id'],method,row.get('metrics',row.get('error_type')),flush=True)
if __name__=='__main__':run()
