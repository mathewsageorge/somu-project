# MailMind — demonstration and viva guide

**Sonu Jacob Jose · 12 October 2026**

## Before presenting

Open `MailMind_Project_Report.pdf` and `MailMind_Presentation_Loading.pptx`. The presentation has speaker notes. Current scope is the local web application; Chrome extension integration and Gmail connection are future scope. Review the limitations, not only the good example. College/register/guide details were not provided and have not been invented; add your institution's required front matter separately if needed.

Use the running demo at **http://127.0.0.1:8502/**. From a portable installation follow README setup; start the local model before selecting Structured AI. Avoid running benchmarks or other GPU-heavy applications during the demonstration. Inference time can vary.

## Five-minute demo

1. **Introduce the problem (30 s).** “MailMind helps a reader understand a selected email by extracting a summary, tasks and meeting details with source quotations.”
2. **Show the original input (30 s).** Choose **Example thread**, then **Test Case 22 · UAT approval and rescheduled meeting**. Explain that this is fictional development data, already inspected.
3. **Show the model (30 s).** Select **Structured AI · Qwen extraction (new)**. Point to Qwen3.5-4B-Q4_K_M. “This pretrained model runs locally; I did not train it. It interprets context into JSON, then validation checks structure and source support.”
4. **Click Analyse (roughly 50–65 s in recent single checks, variable).** Point to the floating animated activity card, which stays in view even below a long email. Explain the actual Prepare, Qwen and Validate phases, and the elapsed timer. Show the live system RAM, GPU activity and GPU memory panel. It refreshes about every two seconds, including while the model runs. Explain that the values include other apps and are not model-only measurements. Then explain pending work, completed work and meeting announcements. Explain that GPU activity includes other apps, allocated VRAM can remain at zero activity, and no token progress or ETA is available. Do not promise a fixed runtime.
5. **Inspect tasks (45 s).** Priya: review/approve by October 19 with blockers. Kiran: checklist/rollback by October 20 with database-backup verification. Priya/Kiran/Meera: join early, calculated 14:45 source-local. Expand evidence and point to the greeting that supports the collective owners.
6. **Inspect Events (30 s).** One deployment readiness meeting, rescheduled from October 20 at 11 AM to October 22 at 3 PM IST. Show unchanged link/agenda. IST region is unresolved, so no invented UTC conversion.
7. **Inspect Summary and Review notes (30 s).** Identify one remaining omission: blocker/rollback detail is present in task cards but compressed away in the summary. “Source matching does not prove complete understanding.”
8. **Export JSON (15 s).** Explain that export is explicit and stays local. The final browser export was schema/evidence checked.
9. **Show evaluation slide (30 s).** Latest development task precision 0.846, recall 1.000, F1 0.917 on 8 fictional emails / 11 labels. Two false-positive tasks remain. Do not call F1 “overall accuracy.”

If time permits, choose **Previous AI** on the same email to compare model responsibilities and latency. Rules Only is a reference comparison, not the main approach. Changing method clears stale results and requires Analyse again.

## Useful viva answers

**What is NLP?** Natural language processing is software that processes human language. Here the language is email text; outputs are summaries and structured information.

**What is the model?** Qwen3.5-4B-Q4_K_M, an existing quantized pretrained language model, executed with llama.cpp locally. “4B” describes the parameter scale; quantization reduces deployment memory.

**Did you train or fine-tune it?** No. This project implements inference-time prompting, structured extraction, validation, a user application and evaluation. The fictional examples were used to debug/evaluate, not to update model weights.

**What is a baseline?** A simpler comparison system. Rules Only uses programmed patterns and source sentence selection. It helps measure what the model-based method adds and where it causes regressions.

**Why JSON?** It gives predictable fields that code can validate and interfaces can display. Valid JSON can still contain a wrong interpretation, so schema validation is necessary but insufficient.

**Why preserve evidence?** It lets a person trace each item back to the email. Exact quotation checks reject invented quotations; they do not prove that a quoted person is the correct owner.

**Why is accuracy not 100%?** Language can be ambiguous and incomplete. The current experiments also show actual extra tasks and summary omissions. We report separate metrics and error analysis rather than promise universal correctness.

**What are the results?** Latest structured development task precision 0.846, recall 1.000, F1 0.917. Matched owner sets 11/11; explicit normalized deadlines 4/4. These small, reused fictional inputs do not establish real-world performance. The earlier 0.960 F1 is a different frozen version on a different reserved set.

**Is the main method better than Previous AI?** It produces richer grouped fields and natural summaries, but on the latest development set its detection precision/F1 is lower because of extra tasks. More expressive output also takes longer. The project reports that tradeoff.

**How long does it take?** Two repeated Case 22 runs had a 49.99 s median; final browser check was 53.81 s. Previous AI median was 7.12 s. Conditions were not fully controlled. The richer method generated 1,099 output tokens versus 145.

**Does Gmail work?** Chrome extension integration and Gmail connection are future scope. Exploratory source exists, but the submitted application uses pasted or fictional emails in the local web interface. Do not claim a completed connected Gmail flow or Tasks/Calendar creation.

**What do the live usage numbers mean?** RAM used/total is physical system memory. GPU activity shows reported NVIDIA GPU-0 utilization; GPU memory shows allocated VRAM across applications. Model weights can occupy VRAM even at 0% activity. Values are live laptop-wide observations, not model-process-only measurements. Missing driver readings show Unavailable.

**Is email private?** The configured model and backend run on loopback. Only selected content is analysed; no database or raw-email logging by default. Explicit research exports contain fictional data. User downloads/clipboard copies remain user-managed.

**What is the contribution?** An implemented local email-analysis workflow with comparable NLP methods, structured context-aware extraction, exact evidence validation and reproducible evaluation/error analysis. It does not claim a new language model architecture or established research novelty.

**What is next?** Independent annotations, a fresh hidden test, consented anonymized real emails, semantic attribution checks and measured latency reduction. Fine-tuning can be studied later with suitable data and compute.

## Submission checklist

- Read the report and speaker notes; explain the code and limitations in your own words.
- Check your college's required cover/front-matter format and any academic disclosure policy.
- Verify the model and demo are running before entering the presentation room.
- Keep the PDF/PPTX and packaged project available offline. The ZIP does not contain model weights or credentials.
- Keep metrics attached to their version, dataset and denominator. Do not combine historical and latest results.
