"""MailMind: local, evidence-backed email analysis."""
