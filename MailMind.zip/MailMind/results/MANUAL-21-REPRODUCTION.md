# Manual Test Case 21: Project Status and Weekly Review

Reproduced 11 October 2026 with the full user-supplied email. Fixture: `data/manual_case_21.json`, distinct from `v2-dev-21`. Subject and signature formatting are rendered as plain text; sender timestamp/timezone remain null. This is a known development regression, not held-out evaluation. A semantic review checklist is stored with the fixture, not passed to either method.

Actual input snapshot, source hashes and both outputs: `manual-21-before/inputs.json` and `manual-21-before/results.json`. Both methods successfully executed and passed exact-source evidence validation. One run each; no repeatability or general accuracy estimate.

## Four tasks in each method, but different content

| Item | Rules | AI + rules |
|---|---|---|
| Aisha: complete UAT testing | Separate task, no deadline | Separate task, no deadline |
| Aisha: share observations | Separate task, deadline 2026-10-12 | Separate task, deadline 2026-10-12 |
| Rahul: prepare and send report | One task, owner Rahul, deadline 2026-10-13 | Same |
| Fourth task | Include testing issues; owner/date null | Join meeting early; owner/date null |
| Meeting | One event, 2026-10-14, 10:30 AM, raw IST, resolved timezone null | Same |

AI model identifier: Qwen3.5-4B-Q4_K_M. Pipeline latency: rules 29.24 ms, AI 8044.04 ms; AI reported 1279 input/104 output tokens. These are single-run values with uncontrolled warm/cold state, not speed comparisons. No memory measurement was made.

## Error attribution

1. **Aisha grouping — shared post-processing.** `context.task_chunks` splits on the conjunction and its current exceptions do not cover testing/observations. `pipeline.materialize` assigns the final deadline only to the second chunk. Model input/output protocol selects whole sentences, so this split is downstream of Qwen.
2. **Rahul's secondary requirement — two separate issues.** Rules extract the inclusion sentence independently. AI omits it from task candidates and reports a model/rule disagreement. Neither approach links it as a requirement of Rahul's report. Retaining evidence only for Rahul's first sentence does not preserve this secondary instruction.
3. **Attendance detection — baseline limitation.** `is_rule_task`/VERBS do not support the join instruction here. Qwen does detect the attendance sentence.
4. **Attendance owners/time — contextual rule limitation.** `contextualize` handles a narrow two-person greeting plus both-of-you attendance pattern, not this three-person greeting and join phrasing. Thus Qwen's correctly selected attendance sentence still gets null owner/date. Expected interpretation: Aisha, Rahul and Neha, 14 October 2026 at 10:20 source-local time, derived from 10:30 minus ten minutes. Retain greeting, meeting and attendance evidence and a review flag. IST remains unresolved; no UTC conversion is justified.
5. **Summary coverage — selection and schema.** Rules select Aisha, Rahul and inclusion sentences. AI selects Aisha, Rahul and attendance. Both omit UAT-completion/availability, Neha's completed documentation, the actual meeting schedule, and the deployment condition. AI also omits the report inclusion requirement. The three-source-sentence cap prevents these seven distinct source-supported facts from all being represented; a better prompt alone cannot overcome this representation limit.
6. **Status/dependency distinction.** Neither method invents a pending task for Neha's completed documentation: preserve that behavior. Neither emits unconditional deployment work, but neither structures or summarizes the explicit testing-confirmation dependency. Missing dependency representation is distinct from an incorrect pending task.

## Acceptance criteria for the next implementation

- Three logical groups under the user's annotation policy: Aisha testing/observations; Rahul report/send including issues; shared early arrival/setup.
- Both activities and October 12 remain attached to Aisha; Rahul retains October 13 and the exact inclusion requirement.
- Attendance owner inference and calculated 10:20/date are explicit and source-backed; raw IST is preserved, resolved timezone null.
- One review event remains at October 14, 10:30 AM. Documentation completion does not become new pending work.
- Preserve the deployment condition and conditional blocker-reporting request as supporting/conditional information. A count of three must not be achieved by silently discarding requirements or adding guessed owners.
- Summary evaluation checks key facts independently from task count. All quotes remain validated; generated prose, if later added, requires a separate factuality review.
- Add varied paraphrases and counterexamples for different assignees/deadlines, ambiguous recipient sets, unrelated adjacent instructions, cancelled meetings and conditional attendance. Do not hardcode these names or dates.

## Reproduce

From project root, using a new output directory:

```powershell
../../work/.venv/Scripts/python.exe scripts/reproduce_manual_review.py --input data/manual_case_21.json --output results/manual-21-new-run
```

No extraction/model/prompt changes were made in this reproduction. The runner gained an optional input-file argument; its original default still uses cases 16–20. No issue is marked fixed and no after-results are claimed.
