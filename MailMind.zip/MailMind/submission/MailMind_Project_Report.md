# MailMind
## Email Summarization and Action Item Extraction
Sonu Jacob Jose
MTech NLP Project Report
12 October 2026

## Abstract and reading guide

MailMind is a local NLP prototype that converts selected email content into a summary, reviewable tasks and meeting details with source evidence. The project investigates whether a pretrained language model can interpret contextual requests while a validation layer preserves traceability. The submitted application is a Streamlit web interface backed by the Python NLP pipeline. Chrome extension integration and Gmail connection are explicitly future scope; exploratory extension/backend source is retained separately. The local model is Qwen3.5-4B-Q4_K_M, executed through llama.cpp on an RTX 3050 laptop with 16 GB system RAM. No model training or fine-tuning was performed.

Three selectable approaches support comparison: a rules-only baseline, a previous model method that selects sentences, and the main method that asks Qwen for structured JSON decisions and generated summary claims. The implementation retains exact source text and message IDs, validates schema and quoted evidence, preserves original date wording and marks unresolved context for review. It uses no email database by default.

On the final eight inspected fictional development emails, the current structured method recorded task precision 0.846, recall 1.000 and F1 0.917 under the documented logical-action matching policy. These are development measurements, not independent or real-world accuracy estimates. Owner and summary errors remain. The latest software suite passed 192 tests, including telemetry and interface checks. Chrome/Gmail integration is outside the current submission scope.

The report describes requirements and related work, explains each method, presents evaluation design and version-specific results, and discusses limitations. Research claims are deliberately narrower than the application goal. Exact quotation validity, task detection, field extraction, summary factuality and software correctness are evaluated as distinct questions. A stronger independent evaluation is future work.

Keywords: email summarization, action items, structured extraction, pretrained language model, source evidence, temporal normalization, local inference.

## 1 Introduction and objectives

Emails mix background information, explicit work requests, completed activities and schedules. A reader must determine what remains to be done, who should do it and when. A scheduling sentence can describe a meeting without assigning a task. A later reply may cancel an earlier request. Collective references such as all three of you require information from elsewhere in the message. These distinctions motivate a combined summarization and information-extraction application.

The project goal is to help a user understand a selected message or thread without automatically acting on it. Expected output includes a concise factual summary, logical task groups, responsible people, original and normalized deadlines, active meeting information, and supporting source quotations. A user reviews the result before copying or exporting it. The fictional demo makes the core pipeline accessible without a Google account.

The research questions are: RQ1, how do the three methods differ in task detection and owner/deadline extraction on identical fictional inputs? RQ2, does structured extraction improve contextual grouping and meeting linkage while preserving source evidence? RQ3, what summary omissions and factuality errors remain despite evidence validation? RQ4, what latency and resource costs arise on a consumer laptop?

The engineering contribution is an integrated prototype with explicit source grounding, comparable methods and reproducible evaluation artifacts. The project does not claim a new model architecture or a novel training algorithm. Its academic value is the careful implementation, empirical comparison, diagnostic error analysis and disclosure of limits.

The present scope is predominantly English, actively selected email text and short threads. Attachments, comprehensive multilingual understanding, autonomous mailbox processing and production-grade Google distribution are outside the verified implementation. The next chapters separate the intended user experience from features already exercised.

## 2 Related work and research position

Action-item detection has a history in dialogue research. Purver et al. [1] study both finding action-item discussions and extracting the phrases describing their tasks. Their setting is multi-party spoken dialogue rather than Gmail, but it highlights why context and commitments matter beyond keyword detection. MailMind applies this motivation to reviewable email tasks without claiming to reproduce that system.

BART [2] is a pretrained sequence-to-sequence model using denoising objectives and demonstrates the usefulness of pretrained models for generation tasks. MailMind does not implement or train BART. It uses an already available instruction model to reduce the engineering and compute burden of building a language model from scratch.

SAMSum [3] provides annotated dialogue summaries and discusses disagreement between lexical metrics and human judgments. It supports the decision to evaluate summary quality beyond copied words. MailMind does not train on SAMSum or claim performance on it. Its fictional development data has a different domain and substantially smaller scope.

ROUGE [4] measures lexical overlap with reference summaries. It can supplement evaluation when references exist, but overlap cannot establish that a recipient was attributed the correct role or that a cancelled task remains inactive. SummaC [5] studies factual inconsistency detection using sentence-level natural-language inference and aggregation. MailMind implements no SummaC scorer; independent claim review is proposed instead of pretending quote membership is entailment.

Qwen3.5-4B is documented by its publisher [6]. The application uses a quantized GGUF distribution of its pretrained weights [7] with a pinned llama.cpp runtime. Quantization enables local deployment but does not establish domain specialization. No fine-tuning was performed. These selected sources position the project as applied NLP system research; they are not an exhaustive novelty review.

## 3 Requirements and user workflow

The current workflow is deliberate input and review in the local web application: choose a fictional example or paste an email, select a method and click Analyse. A future Chrome extension could connect Gmail and retrieve a user-selected message or thread. The result presents Summary, Action items, Events and Review notes. The interface displays the method, configured/used model, processing time and token counts. A floating activity card stays visible while analysis runs, with an animated indicator, elapsed time and live hardware readings. Code callbacks report preparation, the local runtime request and returned-output validation. Token progress and an estimated finish time are unavailable.

Functional requirements include plain text and HTML handling, multiple tasks and no-task messages, named and contextual owners, quoted-reply/signature exclusion, request updates, cancellations, relative dates and ambiguous schedules. The system should preserve source evidence and retain unsupported fields as unknown. Related instructions may be attached to a parent task as requirements rather than split into several cards.

Nonfunctional requirements include local processing by default, bounded requests and timeouts, no credentials in extension source, no raw message logging, exact origins for the backend and understandable errors. The model has no tools or write capabilities. The intended output is assistance requiring review rather than an authority to act.

| Capability | Submission status |
|---|---|
| Pasted or fictional email analysis | Implemented and exercised locally |
| Three NLP methods and structured output | Implemented and evaluated |
| Evidence and local JSON export | Automated and browser verified |
| Chrome extension integration and Gmail connection | Future scope; exploratory source only |
| Calendar or Tasks creation | Optional future feature, not implemented |
| Independent real-email evaluation | Planned, not performed |

The submitted web interface supports viewing, clearing and explicit JSON export. Edit/dismiss controls exist in exploratory extension source; they are not claimed as completed integrated features of the submitted web application.

## 4 Architecture and data flow

The submitted architecture has a Streamlit presentation layer and Python NLP modules, with a local Qwen runtime on loopback. Streamlit invokes the analysis pipeline directly. FastAPI and exploratory TypeScript/Manifest V3 extension source are retained for future integration; Gmail authorization, selected-message retrieval and the connected Chrome workflow are outside the current scope.

| Stage | Responsibility |
|---|---|
| Input selection | Explicit fictional example or pasted message/thread |
| Canonicalization | Decode HTML into visible text and prepare candidate rows |
| Method routing | Baseline, previous AI, or structured AI |
| Local inference | Qwen returns bounded JSON using source row IDs |
| Validation | Schema, exact evidence, supported fields and dates |
| Review and export | Display uncertainty, inspect evidence, export JSON |

The public schema is defined in mailmind/schema.py. mailmind/pipeline.py routes requests and contains the baseline. mailmind/improved.py implements the previous AI method. mailmind/structured.py implements the main method. The earlier structured version is preserved in structured_legacy.py and pre-submission source snapshots are retained in the results directory.

The design uses no database. Normal emails and analyses remain in session memory until explicit export. Research evaluators intentionally save fictional inputs/results. Canonical source text defines evidence comparisons. The web interface shows live laptop-wide RAM used, NVIDIA GPU activity and GPU memory only while analysis is running, refreshing about every two seconds in the loading card. The initial and idle pages have no usage panel or telemetry polling. A worker runs analysis while the UI refreshes. A thread-safe queue carries fixed phase identifiers to the floating activity card; it carries no email text or model output. The card explains sampled GPU activity and clears on success or failure. Animation respects reduced-motion settings. Windows memory APIs and a bounded nvidia-smi query need no extra dependencies. Missing readings remain unavailable; the monitor does not isolate model memory or store telemetry.

## 5 Baseline and previous AI method

The baseline is a reproducible, understandable comparison system. It ranks source sentences for an extractive summary and uses programmed request patterns, verb cues and owner/date extraction. Helper modules reconcile supported task and event updates, preserve requirements and normalize conservative calendar expressions. Its advantages are low latency, explainability and no model dependency. Its limits include indirect requests, unfamiliar wording, implicit responsibility and complex contextual links.

The previous AI method uses Qwen to classify numbered source sentences as task, event or neither and select summary material. A shared materialization layer then applies deterministic field extraction, grouping and state rules. This increases linguistic coverage in some examples while preserving an extractive output style. The model is doing sentence/category selection rather than generating all task fields.

The current main method is different: Qwen supplies grouped tasks, owner lists, event associations, requirements and natural summary claims directly as structured decisions. Rules then validate evidence and interpret supported dates or time offsets. Keeping all methods available lets experiments separate model selection from model-led structured interpretation.

The internal name improved is a historical method identifier. It is not evidence that the previous AI always outperforms the baseline. Likewise, the structured method is the proposed approach, not a universally superior method. Results must be interpreted using the metric, annotation policy and version evaluated.

No dataset was used to update model weights. Prompt development is an inference-time engineering process. Running local API requests is not training, and fictional fixtures are evaluation/development examples rather than a training corpus. A future fine-tuning study would need a separate dataset, train/validation/test design and compute evaluation.

## 6 Main structured extraction method

The main method prepares numbered source rows and sends them with timestamp/timezone context to Qwen. A JSON schema constrains the output shape. The model chooses source IDs for tasks and events and generates separately cited summary sentences. IDs make retrieval of exact evidence deterministic and reduce the need for the model to reproduce quotations verbatim. Valid JSON can still contain wrong decisions, so schema compliance is only one layer.

| Output | Principal fields |
|---|---|
| Summary claim | Natural text and supporting evidence |
| Task | Action, owners, original group, deadline wording/date, status |
| Task context | Requirements, event link, computed source-local arrival |
| Event | Title, current schedule, status, participants, details, history |
| Review metadata | Ambiguities, model, timings and token counts |

Evidence contains a source message identifier and exact contiguous text from canonical input. Owner and participant context can cite a greeting independently of the instruction row. Event names can come from an earlier row while the description ID points to the revised schedule. Original and current schedules are represented separately so a rescheduled meeting need not become two active events.

A model-generated summary fact list supports a coverage warning when its selected facts are not cited. This is a diagnostic, not an objective completeness oracle. The model can select trivial rows or omit important facts. The prompt asks for completed work, pending deliverables, meetings/logistics, preparation, dependencies and unknown dates. Unsupported numeric or urgency details are rejected per claim, which can leave an incomplete summary.

The latest prompt retains explicit collective meeting-preparation tasks even when the event and summary already mention attendance. It distinguishes greeting recipients from the requester and conditions from assigned work. These instructions are general and do not embed expected names or dates from the test emails. Remaining model errors are reported in the results.

## 7 Dates and source validation

Date normalization is deliberately conservative. Original wording is always retained. A fully specified supported calendar date may become an ISO date. Relative wording requires sufficient sender timestamp and timezone context. Missing years and ambiguous numeric dates require review. Calendar normalization and timezone conversion are different operations: a known date does not establish an absolute instant.

Timezone abbreviations can be ambiguous. In Case 22, IST is preserved as raw text and no regional timezone is guessed. The explicit early-arrival offset is subtracted from a model-linked meeting clock in source-local time. The result 2026-10-22T14:45 is labelled as a calculation requiring review, not a resolved UTC timestamp. If more than one event could be meant, the link and arrival should remain null.

During development, a clock parser removed the trailing PM as if it were a timezone abbreviation. The legacy calculation produced 02:45 instead of 14:45. The corrected parser preserves AM/PM; tests cover noon, midnight and day rollover. This concrete arithmetic fix is distinct from improvements in the model understanding the instruction.

The submission update rejects task deadline wording that appears only in context rather than the task instruction or a linked requirement. This prevents an event schedule from automatically becoming a preparation deadline. The policy is conservative and may discard valid cross-sentence deadlines when the model fails to link the assigning requirement. Ordinary announced events do not display model-supplied rescheduling history.

Validation checks message IDs, row bounds, source quotations, supported owner/date/title spans and basic summary numeric consistency. It cannot establish that a source name has the correct role, that a cited date belongs to the right obligation, or that a paraphrase preserves every condition. These are semantic evaluation problems. Review notes expose uncertainty without fabricated confidence probabilities.

## 8 Implementation privacy and security

FastAPI validates requests, limits input size and requires a random local pairing token. Host and Origin restrictions protect the local boundary. Services bind to loopback and model HTTP requests use explicit timeouts. Errors avoid leaking message bodies or token values. Normal processing does not log raw email or extracted sensitive content. The project is a single-user local prototype rather than a hardened multi-tenant service.

Emails are treated as untrusted data. The model context tells it not to follow embedded assistant instructions, and the model has no tools, credentials or Google write access. Source selection and quotation checks reject many unsupported outputs. Common malicious instruction patterns are excluded during preparation, but pattern detection is incomplete. The threat model therefore does not claim prompt injection has been solved.

HTML is parsed into canonical visible text rather than executed or inserted as raw HTML. Quoted replies and signatures are excluded conservatively from candidate extraction. This can omit inline replies in unusual layouts. Supporting evidence refers to the canonical text. Thread order is preserved when reliable timestamps are absent; general paraphrased cancellation and temporal coreference remain difficult.

For future Chrome/Gmail integration, body retrieval would require an appropriate Gmail scope; Google identifies gmail.readonly as restricted [8]. Metadata-only access cannot provide bodies. The planned architecture retrieves selected content by API ID rather than scraping the inbox, using Chrome Identity [9] and the sidePanel API [10]. Existing exploratory source is not proof of a completed connection. OAuth setup, permission review and account acceptance testing are future work.

No background inbox processing, automatic email sending or automatic Calendar/Tasks creation exists. Copy/download are explicit user actions. Clear controls remove displayed analyses, while downloaded exports and clipboard copies remain user-managed. A future consented study must define retention, withdrawal and secure deletion procedures. Public distribution needs separate Google and store-policy review.

## 9 Dataset and annotation policy

All executed research inputs in this project are fictional or explicit fictional reconstructions. They cover multiple owners, no-action messages, HTML, quoted replies, dates, request changes, malicious text, completed activities, meeting rescheduling and group instructions. Fictional inputs enable repeatable debugging without collecting private correspondence. They do not establish how the system behaves on naturally occurring email.

The latest dataset has eight inspected development cases, including the full user-supplied manual Case 21 and Case 22. Case 21 is distinct from the repository case v2-dev-21. Case 22 has the unique identifier manual-22-uat-readiness. Earlier reconstructed screenshots retain their provisional provenance. Do not treat reconstructed wording as a byte-identical original email.

A logical task is an explicit assigned action or commitment. Related production and delivery requirements sharing an owner/deadline form one task. Additional constraints are attached as requirements. Meeting announcements are events, and explicit early preparation is a task linked to an event. Standalone completed work and conditional deployment plans are summary facts unless an explicit task is assigned. Unknown membership stays unknown.

The latest logical-action scoring policy lists 11 expected task groups across the eight emails. It uses source-action anchors and one-to-one matches. Owner sets and supported normalized deadlines are assessed separately. This policy was written with prior predictions visible, so it is not independent ground truth. Annotation quality and group granularity are threats to validity.

Historical experiments used other fictional splits. A 12-case reserved set was run once on a frozen earlier sentence-selection version. That set is now consumed and has not been reused as an unseen test of the new structured code. Earlier task-record policies can count historical request and cancellation records separately. Results across such policies must not be pooled into one accuracy figure.

## 10 Evaluation protocol and metrics

Task detection uses true positives for one-to-one matches to expected task records, false positives for extra unmatched output tasks and false negatives for missed expected records. Precision = TP/(TP+FP), recall = TP/(TP+FN), and F1 = 2PR/(P+R). The latest matcher uses source-action anchors or containment of a partial action span of at least eight characters in a labelled quotation, ignoring trailing punctuation. It does not establish that all related requirements were grouped correctly.

Owner extraction is scored as exact owner-set agreement among matched tasks. The report also exposes a known-owner denominator so empty owner sets do not inflate perceived entity extraction. Deadline scoring distinguishes explicit non-null dates from agreement including nulls. Conditional meeting-relative constraints and arrival arithmetic are reviewed separately. Event count agreement is not a complete event accuracy metric.

Evidence validity checks exact quote membership and message ID. It is an engineering provenance metric, not a factuality probability. Summary evaluation should rate each claim as supported, contradicted or unsupported and independently assess coverage of annotated key facts. The current report gives agent-assisted qualitative analysis; independent human factuality/coverage ratings are not available. No ROUGE, entailment or calibrated confidence score is invented.

The same source inputs and sender context are used for comparisons. The final current output is compared with archived runs of preserved approaches; runtime configuration is kept unchanged. Source snapshots, hashes, inputs, raw fictional responses and errors remain available. An unsuccessful prompt revision that omitted attendance was stopped and retained as an intermediate experiment, not counted as a successful final run.

Latency measurements include total pipeline wall time, model HTTP time and server prompt/generation timing when returned. Two Case 22 repeats rotate method order and run sequentially. System-wide memory/GPU samples occur approximately every two seconds. Cache, power, temperature and other applications are not controlled. This is a small operational comparison, not a controlled throughput or memory-allocation benchmark.

## 11 Historical reserved evaluation

The following measurements belong to the frozen earlier rules/sentence-selection implementation evaluated on 12 previously unrun fictional reserved cases. They are included as project history and must not be advertised as performance of the final structured pipeline. Same-author fictional data and a small sample limit inference even for the frozen version.

| Metric | Rules only | Earlier AI plus shared rules |
|---|---|---|
| Task TP / labelled | 9 / 13 | 12 / 13 |
| Extra tasks | 0 | 0 |
| Precision | 1.000 | 1.000 |
| Recall | 0.692 | 0.923 |
| Task F1 | 0.818 | 0.960 |
| Correct status / matched | 7 / 9 | 9 / 12 |
| Owner extraction F1 | 0.941 | 0.941 |
| Deadline wording F1 | 0.889 | 0.947 |
| Normalized deadline F1 | 0.875 | 0.941 |
| Evidence quotes valid | 35 / 35 | 35 / 35 |

The owner and deadline F1 measures include missed tasks and use the earlier evaluation policy. Evidence validity uses displayed source spans. Both methods found four labelled events, but four examples cannot support broad event-understanding claims. Human summary factuality was not measured. These fields have different denominators and must not be reduced to an overall percentage.

The earlier AI task F1 of 0.960 shows improved detection under that frozen study, while only 9 of 13 labelled tasks were both detected and assigned the correct lifecycle status. This illustrates why high detection F1 can conceal meaningful operational errors. The reserved result is preserved in results/FINAL-RESERVED-EVALUATION.md with frozen code and predictions. A new structured-model test requires a fresh unseen set.

## 12 Final development results

The table uses the same eight inspected fictional inputs with the declared logical-action anchors. Preserved method predictions are compared with the new final structured run. These data were used during development, so improvements indicate local engineering progress rather than an estimate of unseen performance.

| Method | TP / FP / FN | Precision | Recall | F1 |
|---|---|---|---|---|
| Rules only | 4 / 2 / 7 | 0.667 | 0.364 | 0.471 |
| Previous AI | 11 / 1 / 0 | 0.917 | 1.000 | 0.957 |
| Early structured | 10 / 2 / 1 | 0.833 | 0.909 | 0.870 |
| Before final pass | 11 / 1 / 0 | 0.917 | 1.000 | 0.957 |
| Final structured | 11 / 2 / 0 | 0.846 | 1.000 | 0.917 |

| Final structured field check | Result |
|---|---|
| Exact owner sets among matched tasks | 11 / 11 |
| Exact sets on matched known-owner tasks | 10 / 10 |
| Explicit non-null normalized deadlines | 4 / 4 |
| Exact normalized date including nulls | 11 / 11 |
| Event count agreement | 8 / 8 |
| Outputs passing evidence checks | 8 / 8 |

The final pass improves matched owner sets from 10/11 to 11/11 and normalized-date agreement from 9/11 to 11/11 compared with the preceding Case 22 update. However, extra task cards rise from one to two and task F1 falls from 0.957 to 0.917. This is a field/summary improvement with a detection-precision regression, not an across-the-board accuracy gain. Field scores exclude unmatched false-positive cards, so they should be read alongside detection precision.

Count agreement and valid citations do not prove complete summaries or correct task granularity. The denominator and error analysis are part of the result. Source snapshots and machine-readable metrics are retained in results/SUBMISSION-METRICS.json and submission-final-development/results.json.

## 13 Case 22 extraction study

The email reports completed QA regression testing, resolved critical defects and Meera's uploaded evidence. Priya must review UAT results and approve by October 19. Kiran must update the checklist, attach rollback and include backup verification by October 20. A readiness meeting moves from October 20 at 11 AM IST to October 22 at 3 PM IST. All three recipients should join 15 minutes early. Deployment requires approval and checklist verification, and its date remains unfinalized.

| Expected logical item | Final recorded output |
|---|---|
| Priya approval and blockers | Review/approval task with October 19 date and blocker requirement |
| Kiran checklist, rollback and backups | October 20 task with rollback in action and backup requirement |
| Collective early preparation | Priya, Kiran, Meera; 2026-10-22T14:45 source-local |
| One rescheduled meeting | Named event, current/previous schedule and logistics |

The final summary states: The QA team completed regression testing and the development team resolved all critical defects, with Meera having already uploaded the required test evidence. Priya must review final UAT results and provide approval by October 19, 2026, while Kiran must update the release checklist including database backup verification results by October 20, 2026. The deployment readiness meeting was rescheduled from October 20, 2026, at 11:00 AM IST to October 22, 2026, at 3:00 PM IST, with the link and agenda remaining unchanged. All three recipients must join the meeting 15 minutes early to verify access and ensure the presentation is ready. Production deployment will proceed only after receiving Priya's approval and verifying Kiran's updated checklist, though the specific deployment date remains unfinalized.

Qualitative review: the final summary adds the unchanged link/agenda and early preparation, but still compresses away blocker and rollback detail and the explicit no-further-work statement for Meera. Those details remain in the source or item cards. This is a partial coverage improvement, not complete semantic verification. A citation can support a sentence while another important fact is still missing.

## 14 Runtime and resource results

| Case 22 method | Median seconds | Range seconds | Output tokens |
|---|---|---|---|
| Previous AI | 7.12 | 6.68 to 7.57 | 145, 145 |
| Early structured | 20.41 | 20.20 to 20.61 | 456, 456 |
| Final structured | 49.99 | 49.97 to 50.01 | 1099, 1099 |

Each row represents two same-input repeats on the loaded local model. The earlier Case 22 structured update took 59.45 seconds median, with 1,059 output tokens. The final pass is measured above rather than assumed faster. Token volume, prompt caching and generation rate all affect wall time. The model was not replaced or fine-tuned, and the runtime configuration was kept unchanged during the comparison.

The model launcher records an 8,192-token context, one parallel slot, 24 GPU layers, batch 256 and micro-batch 128, with reasoning off. These are launch-script settings, not independently audited current process flags. Qwen output is bounded to 3,000 tokens and requests time out at 90 seconds. Server-reported timings and HTTP wall measurements are retained separately.

| Sampled resource | Final structured observation |
|---|---|
| GPU memory peak | 2401 MiB system-wide |
| System RAM peak | 13686 MiB system-wide |
| Sampling interval | Approximately 2 seconds |
| Hardware | RTX 3050 Laptop 4 GB VRAM; 16 GB system RAM |
| Inference cost | No metered API bill; electricity/hardware cost not measured |

These benchmark figures predate the new live web monitor. They include other running applications and can miss brief peaks. No model-only peak RAM allocation, energy use or statistically stable latency distribution is claimed. A practical next optimization is to reduce duplicated generated fields/citations after checking whether grounding quality is preserved. Accuracy and latency must be considered together.

## 15 Software testing and error analysis

The latest automated suite passed 192 tests with one existing Starlette/httpx deprecation warning. Tests cover schema validation, missing fields, evidence mismatch, multiple/no-task emails, relative/ambiguous dates, quotes, updates/cancellations, embedded malicious instructions, model errors and backend boundaries. New checks cover context-only deadlines, explicit linked due requirements, inappropriate history on ordinary events and unfinished summary warnings. Live-telemetry tests cover missing/invalid driver readings, timeouts, absence of idle polling, result preservation after reruns, and refresh during model failure. New loading tests check phase order, unchanged baseline outputs, model-request failures, GPU zero versus unavailable, and refresh/cleanup on success and failure. The prior extension build is historical, outside the integrated submission scope.

Software tests validate program behavior; many model-path tests use controlled responses and do not replace live model evaluation. The final eight-email run used actual local Qwen. The earlier browser check verified Case 22 preview, three tasks, owners, 14:45 arrival, meeting/history and export in 53.81 seconds. A new run with live hardware monitoring returned the same three tasks and one event in 51.25 seconds; its exported JSON passed schema/evidence checks. GPU activity changed from 0 to 33 percent during inference and returned to 0 afterward, with advancing timestamps. A later floating-loader check returned unchanged task/event/summary content in 62.38 seconds with 2220 input and 1099 output tokens. The card stayed in view and disappeared after completion. These isolated UI checks are not controlled monitor-overhead benchmarks.

In the final eight-case run, the unnamed-team email produces an extra meeting-announcement task, and the partial-team email still produces an extra deployment-condition task. Eva is now correctly included as a recipient/owner and no longer described as the requester, although the generated phrase her team introduces an unsupported gender assumption. Case 21 retains all tasks but loses development completion/availability and preparation from its summary after citation rejection. Case 22 summary still omits some blocker and rollback detail. These are actual remaining failures, not hypothetical concerns.

An initial final-pass prompt revision improved summaries but omitted collective preparation in both manual cases and in another group example. It was rejected as a regression. The retained final version uses the established prompt plus focused attribution, dependency, attendance and completeness checks. This demonstrates evaluation-led iteration rather than selecting only favorable examples.

Chrome extension integration and Gmail connection are explicitly future scope. Existing exploratory code/build checks do not establish an integrated working product. The Streamlit Deploy button is hidden from the demo; this UI change does not imply that a hosting/deployment service was implemented.

## 16 Limitations conclusion and future work

MailMind demonstrates a functioning local workflow and a transparent comparison of rules, model sentence selection and structured model interpretation. The main method can group explicit work, resolve some collective references, retain schedule history and provide natural summary claims with source evidence. The evidence layer makes outputs inspectable and prevents many fabricated field values, but it cannot prove semantic correctness.

There is no defensible guarantee of 100 percent accuracy. Email language can be underspecified, contradictory or unfamiliar, and the small fictional sets do not represent real-world variety. Even 100 percent task detection on a selected set does not imply complete summaries or correct responsibility. The report therefore presents metric-specific results with denominators, version boundaries and remaining failures rather than one overall accuracy claim.

Threats to validity include same-author annotations, reused development cases, subjective grouping, lexical action matching, correct-null field inflation, sparse events, agent-assisted summary review and uncontrolled timing conditions. Prompt development may overfit the examples even without weight training. No independent inter-annotator agreement, real-email benchmark, calibrated uncertainty or comprehensive prompt-injection evaluation is available.

Future evaluation should recruit consenting participants, obtain institutional approval where applicable, anonymize chosen messages locally and separate participant/thread groups before splitting. Two independent annotators should label task groups and summary facts, measure agreement and adjudicate differences. Freeze code, prompt and configuration before a fresh hidden test. Consent must cover other correspondents and retention, with a withdrawal/deletion process.

Engineering priorities include semantic attribution checks, summary coverage and measured token/latency reduction. Chrome extension integration and Gmail connection are future scope, requiring account setup, authorization review and acceptance testing. Fine-tuning is a later research option requiring appropriate data and compute. Calendar or Tasks export would require an explicit user confirmation and a separately reviewed permission flow. The current prototype supports an honest academic demonstration and a reproducible foundation for these extensions.

## References

[1] M. Purver et al. Detecting and Summarizing Action Items in Multi-Party Dialogue. SIGDIAL, 2007, pp. 18-25. https://aclanthology.org/2007.sigdial-1.4/

[2] M. Lewis et al. BART: Denoising Sequence-to-Sequence Pre-training for Natural Language Generation, Translation, and Comprehension. ACL, 2020, pp. 7871-7880. https://aclanthology.org/2020.acl-main.703/

[3] B. Gliwa et al. SAMSum Corpus: A Human-annotated Dialogue Dataset for Abstractive Summarization. NewSum, 2019, pp. 70-79. https://aclanthology.org/D19-5409/

[4] C.-Y. Lin. ROUGE: A Package for Automatic Evaluation of Summaries. Text Summarization Branches Out, 2004, pp. 74-81. https://aclanthology.org/W04-1013/

[5] P. Laban et al. SummaC: Re-Visiting NLI-based Models for Inconsistency Detection in Summarization. TACL 10, 2022, pp. 163-177. https://aclanthology.org/2022.tacl-1.10/

[6] Qwen. Qwen3.5-4B model card. https://huggingface.co/Qwen/Qwen3.5-4B

[7] Unsloth. Qwen3.5-4B GGUF distribution. Pinned revision e87f176479d0855a907a41277aca2f8ee7a09523. https://huggingface.co/unsloth/Qwen3.5-4B-GGUF

[8] Google. Choose Gmail API scopes. https://developers.google.com/workspace/gmail/api/auth/scopes

[9] Chrome for Developers. Identity API. https://developer.chrome.com/docs/extensions/reference/api/identity

[10] Chrome for Developers. Side Panel API. https://developer.chrome.com/docs/extensions/reference/api/sidePanel

External references were checked on 12 October 2026. Local evidence: results/CASE22-REPORT.md; results/FINAL-RESERVED-EVALUATION.md; results/SUBMISSION-METRICS.json; results/submission-final-development/results.json; results/submission-final-timing/results.json; results/python-tests-submission.xml; results/python-tests-live-resources.xml; results/python-tests-loading-ui.xml; results/python-tests-loading-only.xml; results/LOADING-ACTIVITY.md.

## Appendix Demonstration and reproducibility

A short demonstration can be completed without Google credentials. Start the configured local Qwen runtime, then the Streamlit demo on port 8502. Select the Case 22 fictional example and read the original text before running analysis. Choose Structured AI and click Analyse. Explain that Qwen is a pretrained local model and that rules validate its output. While inference runs, show the floating activity card, elapsed time and live RAM/GPU samples. Explain that runtime waiting includes any queue time and that GPU values include other applications. There is no reported token-level progress or estimated finish time. Then describe why completed work, pending requests and meeting announcements need different treatment.

Inspect Priya and Kiran task cards and their requirements. Inspect the collective task and its cited greeting, then the computed 14:45 source-local arrival. Open Events to show the rescheduled meeting name, old/current schedules, participants and unchanged logistics. Explain why IST remains region-unresolved. Open the Summary and Review notes, identify a remaining omission, and export JSON. Compare the same email using Previous AI or Rules Only if time permits.

Reproducible commands from the project folder, using its activated Python environment:

```text
python -m pytest -q -p no:cacheprovider
python -m streamlit run demo.py --server.port 8502
python scripts/evaluate_case22.py --input data/case22_development.json
  --output results/new-run --methods structured
```

The evaluation command is one line; join the wrapped final line. Use a new output directory because existing results are protected. Dependency installation is pinned by requirements.lock and the extension lockfile. Model/runtime hashes are pinned in the download script. Original-laptop environment paths differ from a portable installation; HANDOVER.md documents both.

Viva answer: the application uses an existing model, not a model trained by this project. The baseline provides a reference. Evidence matching supports traceability but not entailment. Metrics come from fictional evaluation and cannot be presented as universal accuracy. Chrome extension integration and Gmail connection are future scope. The work contributes an implemented, measured and reviewable NLP system.
