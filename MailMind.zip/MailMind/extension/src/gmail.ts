export interface Message {id:string;body:string;content_type:'text/plain'|'text/html';sent_at:string|null;timezone:string|null;sender?:string|null}
interface Part {mimeType?:string;filename?:string;body?:{data?:string;attachmentId?:string;size?:number};parts?:Part[];headers?:{name:string;value:string}[]}
interface GmailMessage {id:string;internalDate:string;payload:Part;sizeEstimate?:number}
const scope = 'https://www.googleapis.com/auth/gmail.readonly';
export async function connect(interactive = true):Promise<string> {
  if(!globalThis.chrome?.identity || !chrome.runtime.getManifest().oauth2?.client_id) throw Error('Google setup is incomplete. Demo mode is ready; see docs/GOOGLE.md.');
  try {
    const result = await chrome.identity.getAuthToken({interactive,scopes:[scope],enableGranularPermissions:true});
    if(!result.token || (result.grantedScopes && !result.grantedScopes.includes(scope))) throw Error('scope');
    return result.token;
  } catch { throw Error('Google authorization was denied or expired. Use Connect to authorize Gmail read-only access.'); }
}
async function google<T>(path:string, retry = true):Promise<T> {
  const token = await connect(false);
  let response:Response;
  try {response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/'+path,{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(20000)});}
  catch {throw Error('Gmail request timed out or could not connect.');}
  if(response.status === 401) {
    await chrome.identity.removeCachedAuthToken({token});
    if(retry) return google<T>(path,false);
    throw Error('Google authorization expired. Connect again.');
  }
  if(response.status === 403) throw Error('Gmail permission denied. Check consent, test-user and API configuration.');
  if(!response.ok) throw Error(response.status === 404?'Selected Gmail ID was not found.':'Gmail request failed. Try again later.');
  return response.json() as Promise<T>;
}
export async function disconnect(revoke:boolean) {
  let failed = false;
  if(revoke) {
    try {
      const token=await connect(false);
      const r=await fetch('https://oauth2.googleapis.com/revoke',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({token}),signal:AbortSignal.timeout(15000)});
      failed=!r.ok;
    } catch {failed=true;}
  }
  await chrome.identity.clearAllCachedAuthTokens();
  if(failed) throw Error('Signed out locally. Revocation could not be confirmed; remove access in your Google account settings.');
}
export async function search(query:string) {
  if(!query.trim()) throw Error('Enter a Gmail search query.');
  const list = await google<{messages?:{id:string;threadId:string}[]}>('messages?maxResults=10&q='+encodeURIComponent(query));
  return Promise.all((list.messages??[]).map(async m=>{
    const detail=await google<GmailMessage>('messages/'+encodeURIComponent(m.id)+'?format=metadata&metadataHeaders=Subject&metadataHeaders=From');
    const headers=detail.payload.headers??[];
    return {...m,subject:headers.find(h=>h.name.toLowerCase()==='subject')?.value??'(No subject)',from:headers.find(h=>h.name.toLowerCase()==='from')?.value??''};
  }));
}
export function parseMessage(raw:GmailMessage, timezone:string|null):Message {
  const parts:Part[]=[];
  function visit(p:Part) {if(p.filename)return;if(p.body?.data && ['text/plain','text/html'].includes(p.mimeType??'')) parts.push(p); for(const child of p.parts??[]) visit(child);}
  visit(raw.payload);
  const type=parts.some(p=>p.mimeType==='text/plain')?'text/plain':'text/html';
  const selected=parts.filter(p=>p.mimeType===type);
  if(!selected.length) throw Error('This message has no inline text body. Encrypted or attachment-only email is unsupported.');
  const body=selected.map(p=>{
    const binary=atob(p.body!.data!.replace(/-/g,'+').replace(/_/g,'/'));
    return new TextDecoder('utf-8',{fatal:true}).decode(Uint8Array.from(binary,c=>c.charCodeAt(0)));
  }).join('\n');
  if(body.length>100000) throw Error('Selected email is too large.');
  const sender=raw.payload.headers?.find(h=>h.name.toLowerCase()==='from')?.value??null;
  return {id:raw.id,body,content_type:type,sent_at:new Date(Number(raw.internalDate)).toISOString(),timezone,sender};
}
export async function selected(id:string, thread:boolean, zone:string|null):Promise<Message[]> {
  if(!/^[a-f0-9]{8,64}$/i.test(id)) throw Error('Enter an API message or thread ID, or use search. Gmail URL fragments are not reliable API IDs.');
  if(thread) {
    const value=await google<{messages:GmailMessage[]}>('threads/'+encodeURIComponent(id)+'?format=full');
    if(value.messages.length>30) throw Error('Thread exceeds 30 messages. Select one message.');
    return value.messages.map(m=>parseMessage(m,zone));
  }
  return [parseMessage(await google<GmailMessage>('messages/'+encodeURIComponent(id)+'?format=full'),zone)];
}
