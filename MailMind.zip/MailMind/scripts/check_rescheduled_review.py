"""Persist results only for the explicitly supplied fictional regression fixture."""
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message
from mailmind.improved import ModelUnavailable, SYSTEM

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    destination = ROOT / args.output
    if destination.exists():
        raise SystemExit('Use a new output path; preserve previous results.')
    os.environ.update(MODEL_PROVIDER='llamacpp', LLAMACPP_URL='http://127.0.0.1:8082', LLAMACPP_MODEL='Qwen3.5-4B-Q4_K_M')
    body = (ROOT/'data/regression_rescheduled_review.txt').read_text(encoding='utf-8')
    report = {'timestamp': datetime.now(timezone.utc).isoformat(),
              'note': 'Known fictional development regression, not an unseen test. No training.',
              'fixture_sha256': hashlib.sha256(body.encode()).hexdigest(),
              'prompt_sha256': hashlib.sha256(SYSTEM.encode()).hexdigest(),
              'source_sha256': {name: hashlib.sha256((ROOT/'mailmind'/name).read_bytes()).hexdigest()
                                for name in ['pipeline.py', 'dates.py', 'improved.py', 'context.py']}, 'runs': {}}
    for approach in ['baseline', 'improved']:
        try:
            result = analyse(AnalysisRequest(messages=[Message(id='pasted-1', body=body)], approach=approach))
            report['runs'][approach] = result.model_dump(mode='json')
            print(json.dumps({'approach': approach, 'tasks': len(result.tasks), 'events': len(result.events), 'latency_ms': result.latency_ms}), flush=True)
        except ModelUnavailable as exc:
            report['runs'][approach] = {'blocked': str(exc)}
            print(str(exc), flush=True)
        destination.write_text(json.dumps(report, indent=2), encoding='utf-8')
