import {connect,disconnect,search,selected, type Message} from './gmail.js';
type Evidence={message_id:string;quote:string};
type Schedule={date_text?:string|null;date?:string|null;time_text?:string|null;timezone?:string|null;timezone_raw?:string|null;requirements?:Evidence[]};
type Item=Schedule & {title?:string|null;participants?:string[];details?:Evidence[];owner_group?:string|null;owners?:string[];arrival_local?:string|null;action?:string;description?:string;owner?:string|null;deadline_text?:string|null;deadline?:string|null;original_schedule?:Schedule|null;status:string;evidence:Evidence[];user_edited?:boolean;dismissed?:boolean;original?:unknown};
type Analysis={summary_claims?:{text:string;evidence:Evidence[]}[];summary:Evidence[];tasks:Item[];events:Item[];ambiguities:string[];approach:string;model:string|null;latency_ms:number};
const el=<T extends HTMLElement>(id:string)=>document.getElementById(id) as T;
const val=(id:string)=>el<HTMLInputElement>(id).value.trim();
let result:Analysis|null=null;
let sourceMode='demo';
let active=0;
const text=(tag:string,value:string,cls?:string)=>{const n=document.createElement(tag);n.textContent=value;if(cls)n.className=cls;return n;};
function status(value:string){el('status').textContent=value;}
function clear(){active++;result=null;el('results').hidden=true;el('empty').hidden=false;for(const id of ['summary','tasks','events','ambiguities'])el(id).replaceChildren();}
async function run(fn:()=>Promise<void>){el('error').hidden=true;const buttons=[...document.querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);try{await fn();}catch(e){el('error').textContent=e instanceof Error?e.message:'Operation failed.';el('error').hidden=false;status('Needs attention.');}finally{buttons.forEach(b=>b.disabled=false);}}
el('mode').addEventListener('change',()=>{clear();const mode=val('mode');el('gmail-fields').hidden=mode!=='gmail';el('paste-fields').hidden=mode!=='paste';el('zone-field').hidden=mode==='demo';el('data-label').textContent=mode==='demo'?'FICTIONAL DEMO':'SELECTED CONTENT';status('Ready to analyse.');});
el('connect').onclick=()=>run(async()=>{await connect();el('connection').textContent='Google connected';status('Connected. Select a message.');});
for(const id of ['signout','revoke']) el(id).onclick=()=>run(async()=>{if(id==='revoke'&&!confirm('Revoke MailMind’s Google access?'))return;clear();el('search-results').replaceChildren();el<HTMLInputElement>('gmail-id').value='';el('connection').textContent='Signed out';await disconnect(id==='revoke');status('Google connection cleared.');});
el('search').onclick=()=>run(async()=>{status('Searching message headers…');const hits=await search(val('query'));el('search-results').replaceChildren();for(const hit of hits){const b=text('button',hit.subject+' — '+hit.from,'search-hit') as HTMLButtonElement;b.onclick=()=>{el<HTMLInputElement>('gmail-id').value=el<HTMLInputElement>('thread').checked?hit.threadId:hit.id;status('Message selected. Click Analyse to fetch its content.');};el('search-results').append(b);}if(!hits.length)status('No matching messages.');else status(`${hits.length} results. Select one.`);});
el('thread').onchange=()=>{el<HTMLInputElement>('gmail-id').value='';status('Select a search result again for the chosen message/thread mode.');};
el('analyse').onclick=()=>run(async()=>{
  clear();const runId=active;status('Reading selected content…');
  const mode=val('mode');let messages:Message[];
  if(mode==='demo') messages=await (await fetch('demo.json')).json() as Message[];
  else if(mode==='paste') messages=[{id:'pasted-1',body:val('body'),content_type:el<HTMLInputElement>('html').checked?'text/html':'text/plain',sent_at:val('timestamp')||null,timezone:val('zone')||null}];
  else messages=await selected(val('gmail-id'),el<HTMLInputElement>('thread').checked,val('zone')||null);
  const token=val('token');if(!token)throw Error('Enter the backend pairing token under Local connection & privacy. See README setup.');
  status('Analysing locally…');
  let response:Response;try{response=await fetch('http://127.0.0.1:8000/analyse',{method:'POST',headers:{'Content-Type':'application/json','X-MailMind-Token':token},body:JSON.stringify({messages,approach:val('approach')}),signal:AbortSignal.timeout(100000)});}catch{throw Error('Cannot reach the local backend. Start FastAPI and check ALLOWED_ORIGINS.');}
  if(!response.ok){const errors:Record<number,string>={401:'Pairing token is incorrect.',403:'Panel origin is not allowed. Update ALLOWED_ORIGINS and restart the backend.',422:'Invalid input. Check body size, timestamp and timezone.',503:'Backend or local model is not configured. See README.'};throw Error(errors[response.status]??'Analysis failed safely. Try again.');}
  const data=await response.json() as Analysis;
  if(active!==runId)return;
  result=data;sourceMode=mode;render();status('Analysis ready. Review the source before acting.');
});
function evidence(list:Evidence[]){const details=document.createElement('details');details.append(text('summary','Supporting evidence'));for(const e of list){details.append(text('p',e.message_id,'hint'),text('blockquote',e.quote));}return details;}
function cards(kind:'tasks'|'events'){
  const container=el(kind);container.replaceChildren();const items=result![kind].filter(i=>!i.dismissed);
  if(!items.length)container.append(text('p','None detected. Review the source for missed information.','hint'));
  for(const item of items){const card=text('article','','card');card.append(text('h4',item.action??item.title??item.description??''));
    if(kind==='tasks')card.append(text('p',`Owner: ${item.owners?.join(', ')||item.owner||'Unspecified'} · ${item.status}`),text('p',`Deadline: ${item.deadline_text??'Not specified'}${item.deadline?' → '+item.deadline:''}`));
    else {
      card.append(text('p',`Status: ${item.status}`),text('p',`Current schedule: ${item.date??item.date_text??'Date unspecified'} · ${item.time_text??'Time unspecified'} · ${item.timezone??(item.timezone_raw?item.timezone_raw+' — region needs confirmation':'Timezone unknown')}`));
      if(item.participants?.length)card.append(text('p','Named participants: '+item.participants.join(', ')));
      for(const detail of item.details??[])card.append(text('p',detail.quote));
      const old=item.original_schedule;
      if(old)card.append(text('p',`Previous schedule (no longer current): ${old.date??old.date_text??'Date unspecified'} · ${old.time_text??'Time unspecified'} · ${old.timezone_raw??old.timezone??'Timezone unknown'}`));
    }
    if(item.owner_group)card.append(text('p','Group wording: '+item.owner_group+' — membership may be incomplete'));
    if(item.arrival_local)card.append(text('p','Suggested arrival (source-local, review): '+item.arrival_local));
    if(item.user_edited)card.append(text('p','Edited by you; evidence describes the original extraction.','user-edit'));
    for(const requirement of item.requirements??[])card.append(text('p','Include in this task: '+requirement.quote));
    card.append(evidence(item.evidence));const controls=text('div','','row');const edit=text('button','Edit') as HTMLButtonElement;const dismiss=text('button','Dismiss','secondary') as HTMLButtonElement;
    edit.onclick=()=>{edit.disabled=true;const form=document.createElement('form');form.className='editor';const fields=kind==='tasks'?['action','owner','deadline_text','deadline','status']:['title','description','date_text','date','time_text','timezone','status'];for(const key of fields){const label=text('label',key.replaceAll('_',' '));const input=document.createElement('input');input.name=key;input.value=String((item as unknown as Record<string,unknown>)[key]??'');label.append(input);form.append(label);}const save=text('button','Save edits') as HTMLButtonElement;save.type='submit';form.append(save);const cancel=text('button','Cancel','secondary') as HTMLButtonElement;cancel.type='button';cancel.onclick=()=>{form.remove();edit.disabled=false;};form.append(cancel);form.onsubmit=e=>{e.preventDefault();if(!item.original)item.original=JSON.parse(JSON.stringify(item));for(const key of fields){const input=form.elements.namedItem(key) as HTMLInputElement;if(['action','description','status'].includes(key)&&!input.value.trim()){status('Action, description and status cannot be empty.');return;}}for(const key of fields)(item as unknown as Record<string,unknown>)[key]=(form.elements.namedItem(key) as HTMLInputElement).value.trim()||null;if(kind==='tasks')item.owners=[];item.user_edited=true;render();status('Edits saved in memory.');};card.append(form);};
    dismiss.onclick=()=>{item.dismissed=true;render();status('Item dismissed from view and export.');};controls.append(edit,dismiss);card.append(controls);container.append(card);
  }
}
function render(){if(!result)return;el('results').hidden=false;el('empty').hidden=true;el('summary').replaceChildren();for(const claim of result.summary_claims??[])el('summary').append(text('p',claim.text),evidence(claim.evidence));for(const e of result.summary){el('summary').append(text('p',e.quote),evidence([e]));}if(!result.summary.length&&!result.summary_claims?.length)el('summary').append(text('p','No safe summary sentences available.'));cards('tasks');cards('events');el('task-count').textContent=String(result.tasks.filter(t=>!t.dismissed).length);el('provenance').textContent=`${sourceMode==='demo'?'Fictional demo · ':''}${result.approach}${result.model?' · '+result.model:''} · ${result.latency_ms} ms`;el('ambiguities').replaceChildren(...result.ambiguities.map(a=>text('p',a,'warning')));}
function exported(){if(!result)throw Error('No analysis to export.');return JSON.stringify({...result,demo:sourceMode==='demo',tasks:result.tasks.filter(t=>!t.dismissed),events:result.events.filter(t=>!t.dismissed)},null,2);}
el('clear').onclick=()=>{clear();status('Analysis cleared from this panel.');};
el('copy').onclick=()=>run(async()=>{await navigator.clipboard.writeText(exported());status('Copied reviewed analysis.');});
el('export').onclick=()=>{const url=URL.createObjectURL(new Blob([exported()],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='mailmind-analysis.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status('Exported reviewed analysis.');};
