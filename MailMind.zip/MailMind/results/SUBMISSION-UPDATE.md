# Final submission pass — 12 October 2026

Author of submission: **Sonu Jacob Jose**. Qwen3.5-4B-Q4_K_M, the Rules Only baseline and Previous AI are retained. No model change or fine-tuning occurred.

## Implemented changes

- Retained the established structured prompt and added general checks for collective preparation, recipient/requester attribution, dependencies, context-only deadlines and concise complete summary claims.
- Increased the proposed summary-claim character limit from 320 to 600; the output remains bounded. This reduces pressure to end a claim mid-sentence but does not guarantee coverage.
- Reject deadline wording that occurs only in task context rather than the action or an explicitly linked requirement. Meeting association/arrival calculation remain separate.
- Omit proposed original-schedule history on ordinary announced events; preserve history on rescheduled events.
- Flag unfinished summary punctuation for review. This is diagnostic, not semantic verification.
- Added four regression tests and regenerated the runtime JSON schema. Baseline and previous methods are unchanged.

An initial broader prompt rewrite improved some prose but omitted collective preparation on Cases 21/22 and another group case. It was stopped and rejected. Partial outputs and source are preserved in `submission-development`; do not count that interrupted run as completed or as final performance.

## Final eight-email development comparison

Scored from saved outputs by `scripts/score_submission.py`, using `data/submission-scoring-policy.json`. Eleven expected logical tasks. One-to-one source-action containment matching; this measures task representation rather than full semantic equivalence. Labels were authored with earlier predictions visible, not independently or blindly. Source snapshots, exact inputs and raw fictional responses are retained.

| Method | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|
| Rules only | 4 | 2 | 7 | 0.667 | 0.364 | 0.471 |
| Previous AI | 11 | 1 | 0 | 0.917 | 1.000 | 0.957 |
| Early structured snapshot | 10 | 2 | 1 | 0.833 | 0.909 | 0.870 |
| Structured before final pass | 11 | 1 | 0 | 0.917 | 1.000 | 0.957 |
| Final structured | 11 | 2 | 0 | 0.846 | 1.000 | 0.917 |

Final matched exact owner sets improved from 10/11 to 11/11 (known-owner denominator 10/10). Normalized-date agreement including nulls improved from 9/11 to 11/11. Explicit non-null dates remain 4/4. These field scores exclude unmatched false positives and must be read alongside detection precision. Event count agreement and evidence-valid output checks are each 8/8; neither proves event semantics or summary factuality.

The final pass therefore improves some fields and Case 22 coverage while regressing overall task detection precision. It is not a universal improvement. Actual errors remain:

- An unnamed-team example has an extra meeting-announcement task.
- A partial-team example has an extra deployment-condition task; summary wording introduces an unsupported gender assumption.
- Case 21 still loses important completion/availability and preparation details from its summary after citation rejection.
- Case 22 summary omits blocker/rollback details and explicit no-further-work wording for Meera, though the task cards preserve requirements.

## Timing and resources

Same Case 22 input, sequential rotated method order, two repeats each, same loaded Qwen/runtime configuration. Caching, thermal/power state and other applications were not controlled.

| Method | Median total seconds | Range | Output tokens |
|---|---:|---|---:|
| Previous AI | 7.12 | 6.68–7.57 | 145 |
| Early structured | 20.41 | 20.20–20.61 | 456 |
| Final structured | 49.99 | 49.97–50.01 | 1,099 |

Final server generation time was about 49.5 s; input tokens were 2,220. Approximate two-second system-wide samples peaked at 2,401 MiB GPU memory and 13,686 MiB RAM. These are not model-process-only peaks. No metered API cost; electricity/hardware cost unmeasured. Earlier 59.45 s measurements are retained but do not establish a controlled speedup. Token volume, caching and other conditions can affect latency.

## Checks and release artifacts

- **177 Python tests passed**, with one existing Starlette/httpx deprecation warning: `python-tests-submission.xml`.
- Extension TypeScript/build passed. Google OAuth remains unconfigured/unverified; latest extension rendering is build-checked rather than newly Chrome-tested.
- Final live Streamlit Case 22 run: 3 tasks / 1 event; collective owners and 14:45 source-local arrival; current/previous schedules and unchanged logistics verified; **53.81 s**, 2,220 input / 1,099 output tokens.
- Browser-exported JSON was parsed with the public schema and exact quotations checked against the fixture: `submission-browser-export.json`. Screenshot: `submission-browser.png`.
- Report PDF: 20 pages, all pages rendered and visually inspected. Editable Markdown included.
- PowerPoint: 19 slides, native editable tables/chart and speaker notes; package/layout/font/data checks passed, then every final slide rendered and visually inspected. Desktop PowerPoint playback is not claimed.

Submission artifacts are in `submission/`. Historical reserved-set results in `FINAL-RESERVED-EVALUATION.md` belong to the frozen earlier sentence-selection implementation. Do not describe them as a held-out test of this final structured version or combine denominators across policies.

## Remaining work after submission

Freeze this release. Use fresh independently annotated, consented/anonymized data for further accuracy claims. Prioritize semantic role checks, summary coverage and measured token reduction. Complete Google account acceptance testing separately. Calendar/Tasks creation and fine-tuning remain optional future work. No broad 100% accuracy claim is supported.
