"""Software regressions exposed by the longer email; not NLP accuracy claims."""
import json
from pathlib import Path
import pytest
from mailmind.dates import deadline_text, normalize_date
from mailmind.schema import AnalysisRequest, Message, validate_evidence
from mailmind.pipeline import analyse
from mailmind.text import sentences


def test_spaced_titles_and_non_action_headers():
    body = 'Subject: Annual meeting\nHi Nisha,\nPlease email Dr. Lewis. Please thank Prof. James.\nRegards,\nPat'
    assert sentences(body) == ['Please email Dr. Lewis.', 'Please thank Prof. James.']


@pytest.mark.parametrize('wording, expected', [
    ('12 October 2026 at 5:00 PM IST', '2026-10-12'),
    ('October 12, 2026', '2026-10-12'),
    ('29 February 2028', '2028-02-29'),
    ('29 February 2027', None),
    ('12 October', None),
    ('04/05/2026', None),
])
def test_calendar_dates_preserve_uncertainty(wording, expected):
    assert normalize_date(wording, Message(id='m', body='x'))[0] == expected


def test_deadline_excludes_following_work_clause():
    assert deadline_text('Please reply by 9 October 2026 to confirm receipt.') == '9 October 2026'
    assert deadline_text('Prepare slides by 13 October 2026 at 6:00 PM IST and share them.') == '13 October 2026 at 6:00 PM IST'


def test_earlier_conjunct_keeps_its_deadline():
    r = analyse(AnalysisRequest(messages=[Message(id='m', body='Nisha, please prepare slides by 2026-10-13 and share them.')]))
    assert [(t.deadline_text, t.deadline) for t in r.tasks] == [('2026-10-13', '2026-10-13'), (None, None)]
    assert [t.owner for t in r.tasks] == ['Nisha', 'Nisha']


def test_long_email_baseline_and_exact_evidence():
    body = (Path(__file__).parents[1]/'data/regression_project_review.txt').read_text(encoding='utf-8')
    r = analyse(AnalysisRequest(messages=[Message(id='m', body=body)]))
    assert len(r.events) == 1
    assert (r.events[0].date, r.events[0].time_text, r.events[0].timezone) == ('2026-10-14', '10:30 AM', None)
    assert any('IST needs confirmation' in a for a in r.ambiguities)
    assert r.tasks[0].deadline == '2026-10-12'
    assert r.tasks[-1].deadline_text == '9 October 2026'
    assert next(t for t in r.tasks if 'printed copy' in t.action).status == 'cancelled'
    assert all('Subject:' not in t.action for t in r.tasks)
    validate_evidence(r, {'m': body})


def test_confirmed_timezone_context():
    r = analyse(AnalysisRequest(messages=[Message(id='m', body='The meeting is on 14 October 2026 at 10:30 AM IST.', timezone='Asia/Kolkata')]))
    assert r.events[0].timezone == 'Asia/Kolkata'


def test_invalid_model_event_is_flagged_not_relabelled(monkeypatch):
    import mailmind.improved as module
    monkeypatch.setenv('MODEL_PROVIDER', 'llamacpp')
    class FakeResponse:
        def raise_for_status(self): pass
        def json(self):
            return {'choices':[{'message':{'content':json.dumps({'items':[
                {'sentence_id':0,'kind':'event'}, {'sentence_id':1,'kind':'event'},
                {'sentence_id':2,'kind':'event'}], 'summary_ids':[0,2]})}}]}
    monkeypatch.setattr(module.httpx.Client, 'post', lambda *a, **k: FakeResponse())
    body = 'Please prepare slides. Please book the meeting. The meeting is on 2026-10-14.'
    r = analyse(AnalysisRequest(messages=[Message(id='m',body=body)], approach='improved'))
    assert not r.tasks  # Never silently substitute the baseline's answers.
    assert len(r.events) == 1
    assert any(a.startswith('AI extraction is incomplete: 2') for a in r.ambiguities)
    assert sum('Rejected unsupported event' in a for a in r.ambiguities) == 2
