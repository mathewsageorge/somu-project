# Rescheduled meeting update — 8 October 2026

## Verified outcome

On the user's provisional case 19 reconstruction, rules changed from two event records to one, and Qwen3.5-4B-Q4_K_M plus rules changed from three records to one. The resulting status is `rescheduled`; current date/time are 2026-10-16 / 3:30 PM; previous date/time are 2026-10-15 / 11:00 AM. Both schedules retain raw `IST`, with resolved timezone null. The introduction, original schedule and updated schedule remain exact source evidence with message identifiers.

Actual before outputs: `manual-review-provisional-before/results.json`. Final after outputs: `manual-review-event-state-final/results.json`. Both contain all five provisional inputs run through both methods. Input provenance remains unchanged; these are development reproductions, not byte-identical historical tests or new held-out accuracy estimates. The intermediate `manual-review-event-state-after` run predates additional negation/conditional safeguards; use the final directory for the delivered implementation.

## Implementation

- `mailmind/event_state.py:reconcile_events`: shared deterministic reconciliation after either method selects events. Links only an adjacent affirmative rescheduling introduction, generic original-meeting sentence and generic updated-meeting sentence in one message. Both dated records must have been selected; no omitted model event is invented. Additional selected events or unresolved destination cause review rather than merging.
- `mailmind/pipeline.py:materialize`: retains raw timezone and invokes reconciliation before contextual attendance processing.
- `mailmind/schema.py`: Event now inherits validated date/time fields from EventSchedule; adds optional `timezone_raw`, optional `original_schedule`, and `rescheduled` status. Existing fields remain the current schedule. Existing JSON without the optional fields still parses. Exact-span validation includes original schedule wording/time/raw timezone. Strict external consumers must accept the added status/fields.
- `mailmind/context.py`: allows attendance linkage to a uniquely reconciled rescheduled meeting as well as an announced meeting.
- `demo.py` and `extension/src/panel.ts`: display status, current schedule, historical schedule and raw timezone requiring confirmation. JSON export preserves the new fields and evidence. Extension build regenerated in `extension/dist`.

## Validation

- Full Python suite: **114 passed** (`python-tests-event-state.xml`), including 15 new event-state tests. Existing Starlette/httpx deprecation warning remains.
- Tests cover exact output/evidence, classifier-selected undated announcement, different meetings, negated/conditional announcements, extra/cancelled events, unresolved destination, separate messages, fabricated historical time rejection, and Streamlit controls/rendered captions.
- Live local inference: ten successful final outputs (five cases × two methods), all exact-evidence validated. Case 19 returns one rescheduled event for both methods. Cases 16/18 still return split tasks; case 20 still differs in arrival detection. No claim those issues are fixed.
- TypeScript check and loadable extension build passed (`npm run build`).
- Real headless Chromium MV3 extension + real FastAPI + local model: `event-state.spec.ts` passed, verifying both methods, displayed status/schedules/IST warning, three supporting quotations, and downloaded JSON content. Screenshots: `event-state-baseline-panel.png`, `event-state-improved-panel.png`; layout visually inspected. This is automated browser verification, not a live Gmail/OAuth test.
- Streamlit was restarted on http://127.0.0.1:8502 to load the final code. Its pasted-email flow was exercised with Streamlit AppTest; no claim of a separate manual browser test of Streamlit.

## Limits and remaining work

This is intentionally narrow linking, not general event coreference. Paraphrased announcements, separate-message updates, several competing meetings, subsequent cancellation chains and missing destination details are not comprehensively resolved. Existing single-sentence from/to handling remains unchanged. A cancelled event in the same message blocks this merge; records require review. No Tasks/Calendar writes were added or tested. No timezone conversion is inferred from IST alone. A model failure to select either schedule remains a model omission, not silently repaired by this pass.

Next work: shared action/deadline grouping (cases 16/18), summary coverage, and shared arrival context (case 20). Earlier frozen reserved results apply only to their recorded source snapshot; this changed implementation has not been evaluated on new unseen data.
