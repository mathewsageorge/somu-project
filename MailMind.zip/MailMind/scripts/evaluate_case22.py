"""Explicit fictional development harness; raw model output is saved only here."""
import argparse, hashlib, json, os, statistics, sys, threading, time
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import httpx
from dotenv import load_dotenv
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, validate_evidence
from mailmind.text import canonical_text
from mailmind.structured_legacy import structured as legacy
from compare_structured import sample


def main():
 p=argparse.ArgumentParser();p.add_argument('--input',default='data/manual_case_22.json');p.add_argument('--output',required=True);p.add_argument('--methods',nargs='+',default=['improved','structured_legacy','structured']);p.add_argument('--repetitions',type=int,default=1);args=p.parse_args()
 dest=Path(args.output);dest.mkdir(parents=True,exist_ok=False);load_dotenv(ROOT/'.env')
 dataset=json.loads((ROOT/args.input).read_text(encoding='utf-8'));cases=dataset if isinstance(dataset,list) else [dataset]
 (dest/'inputs.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
 record={'created_at':datetime.now(timezone.utc).isoformat(),'input_sha256':hashlib.sha256((ROOT/args.input).read_bytes()).hexdigest(),'source_hashes':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'mailmind').glob('*.py'))},'config':{'methods':args.methods,'repetitions':args.repetitions,'model':os.getenv('LLAMACPP_MODEL') or os.getenv('OLLAMA_MODEL'),'temperature':0,'seed':42,'design':'Sequential calls, rotated method order across repetitions; unchanged loaded runtime and hardware. No exclusive-machine control or controlled cold cache. HTTP wall time includes serialization, queueing and runtime work; server timings reported separately when present.'},'runs':[]}
 snapshot=dest/'source';snapshot.mkdir()
 for file in (ROOT/'mailmind').glob('*.py'):(snapshot/file.name).write_bytes(file.read_bytes())
 original=httpx.Client.post
 for repeat in range(args.repetitions):
  methods=args.methods[repeat%len(args.methods):]+args.methods[:repeat%len(args.methods)]
  for c in cases:
   for method in methods:
    trace=[];samples=[];stop=threading.Event()
    def monitor():
     while not stop.is_set():samples.append(sample());stop.wait(2)
    def traced(self,url,**kw):
     start=time.perf_counter();response=original(self,url,**kw);elapsed=(time.perf_counter()-start)*1000
     data=response.json();choice=(data.get('choices') or [{}])[0]
     trace.append({'http_wall_ms':elapsed,'server_timings':data.get('timings'),'usage':data.get('usage'),'finish_reason':choice.get('finish_reason'),'ollama_total_duration_ns':data.get('total_duration'),'ollama_eval_duration_ns':data.get('eval_duration'),'content':choice.get('message',{}).get('content') or data.get('message',{}).get('content')})
     return response
    thread=threading.Thread(target=monitor,daemon=True);thread.start();httpx.Client.post=traced
    row={'case_id':c['id'],'method':method,'repeat':repeat}
    start=time.perf_counter()
    try:
     req=AnalysisRequest(messages=c['messages'],approach='structured' if method=='structured_legacy' else method)
     result=legacy(req.messages) if method=='structured_legacy' else analyse(req)
     if method=='structured_legacy':result.latency_ms=round((time.perf_counter()-start)*1000,2)
     validate_evidence(result,{m.id:canonical_text(m) for m in req.messages})
     row.update(output=result.model_dump(mode='json'),evidence_valid=True)
    except Exception as exc:row['error_type']=type(exc).__name__
    finally:
     row['end_to_end_ms']=(time.perf_counter()-start)*1000;httpx.Client.post=original;stop.set();thread.join(timeout=6)
    row['model_calls']=trace
    row['resources']={'samples':len(samples),'sample_interval_seconds':2,'peaks':{k:max(s[k] for s in samples if k in s) for k in {k for s in samples for k in s}},'scope':'System-wide RAM and GPU including other processes, not model-only allocations.'}
    record['runs'].append(row);(dest/'results.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(c['id'],method,repeat,'tasks',len(row.get('output',{}).get('tasks',[])),'events',len(row.get('output',{}).get('events',[])),row.get('error_type','ok'),round(row['end_to_end_ms']),flush=True)
if __name__=='__main__':main()
