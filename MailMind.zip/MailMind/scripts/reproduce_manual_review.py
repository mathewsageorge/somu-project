"""Record actual outputs on provisional reconstructions; never assert original parity."""
import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, validate_evidence
from mailmind.text import canonical_text
from mailmind.improved import ModelUnavailable


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, help='New result directory; existing directories are refused')
    parser.add_argument('--input', default='data/manual_review_provisional.json', help='Dataset path relative to project root, or absolute')
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    load_dotenv(ROOT / '.env')
    source = ROOT / args.input
    dataset = json.loads(source.read_text(encoding='utf-8'))
    record = {
        'created_at': datetime.now(timezone.utc).isoformat(),
        'provenance': dataset['provenance'],
        'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'source_hashes': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in sorted((ROOT / 'mailmind').glob('*.py'))},
        'runs': []
    }
    (output / 'inputs.json').write_text(json.dumps(dataset, indent=2), encoding='utf-8')
    for case in dataset['cases']:
        for method in ['baseline', 'improved']:
            request = AnalysisRequest(messages=[{'id': case['id'], 'body': case['body'],
                                      **dataset['input_context']}], approach=method)
            row = {'case_id': case['id'], 'method': method, 'limitations': case['limitations']}
            try:
                result = analyse(request)
                validate_evidence(result, {m.id: canonical_text(m) for m in request.messages})
                row.update(output=result.model_dump(mode='json'), evidence_valid=True)
                print(f"{case['id']} {method}: {len(result.tasks)} tasks, {len(result.events)} events; evidence valid", flush=True)
            except ModelUnavailable:
                row['error'] = 'Configured local model unavailable or invalid output; no fallback used.'
                print(f"{case['id']} {method}: unavailable", flush=True)
            record['runs'].append(row)
            (output / 'results.json').write_text(json.dumps(record, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
