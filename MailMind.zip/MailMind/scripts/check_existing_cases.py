"""Regression comparison on previously inspected data; not a fresh test set."""
import hashlib
import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluate import evaluate

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='results/project-review-regression-checks.json')
    args = parser.parse_args()
    destination = ROOT / args.output
    if destination.exists():
        raise SystemExit('Choose a new output filename to preserve previous measurements.')
    os.environ['MODEL_PROVIDER'] = 'llamacpp'
    report = {'timestamp': datetime.now(timezone.utc).isoformat(),
              'note': 'Regression checks on previously inspected fictional sets, not new held-out results.',
              'source_sha256': {n: hashlib.sha256((ROOT/'mailmind'/n).read_bytes()).hexdigest()
                                for n in ['text.py','dates.py','pipeline.py','improved.py','context.py']},
              'model': os.getenv('LLAMACPP_MODEL', 'Qwen2.5-0.5B-Instruct-Q4_K_M'), 'datasets': {}}
    for dataset in ['dev', 'event_challenge_v2']:
        path = ROOT/'data'/f'{dataset}.json'
        rows = json.loads(path.read_text(encoding='utf-8'))
        report['datasets'][dataset] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'runs': {}}
        for approach in ['baseline', 'improved']:
            result = evaluate(rows, approach)
            report['datasets'][dataset]['runs'][approach] = result
            destination.write_text(json.dumps(report, indent=2), encoding='utf-8')
            print(json.dumps({'dataset':dataset,'approach':approach,'status':result['status'],'metrics':result['metrics']}),flush=True)
