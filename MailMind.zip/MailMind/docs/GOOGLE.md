# Google and Chrome configuration

Documentation checked 6 October 2026. Actual Google login has not been tested without the user's Cloud project, OAuth client and test account.

1. Create/select a Google Cloud project, enable Gmail API, and configure Google Auth Platform branding, audience and data access. For an external application in Testing, add the intended account as a test user. Workspace administrators may block access independently.
2. Load the unpacked extension from `extension/dist` and note its ID. For a stable identity, use the Chrome extension public-key workflow described in the official tutorial. Do not invent a key/client ID; unpacked IDs can change with path or profile.
3. Create an OAuth client for a **Chrome Extension** (older consoles may call this a Chrome App), bound to that exact extension/application ID. This architecture uses Chrome Identity `getAuthToken`, not a backend web-server client secret or a manually implemented redirect flow.
4. Copy `extension/config.example.json` to ignored `extension/config.local.json`. Set `googleClientId` to the issued client ID. Set `extensionPublicKey` only when using your established public key for a stable extension ID. No client secret is used. Run `npm run build`, reload the extension, and recheck its ID.
5. Add the exact `chrome-extension://ID` origin to `.env` `ALLOWED_ORIGINS`, restart the backend, open the side panel and enter its pairing token. Choose Gmail and click **Connect Google**. Chrome may require signing in to the appropriate profile. Consent is never launched in the background.
6. Explicitly search by subject/from or `rfc822msgid:<message-id>` and select a result. Gmail's RFC Message-ID header, Gmail API `message.id`, thread ID and web URL fragments are different identifiers. The panel uses API message IDs. For a thread, enable the thread checkbox and reselect the search result.
7. Click Analyse, inspect source evidence, edit or dismiss, and export locally. Do not assume the currently visible Gmail tab belongs to the authorized Chrome account; the API account determines search and selection.

## Permissions and lifecycle

Only `https://www.googleapis.com/auth/gmail.readonly` is requested. Metadata scope cannot fetch message bodies. Add-on current-message scopes apply to Google Workspace add-ons, not this standalone Chrome extension architecture. No send/modify, Tasks, Calendar, profile or contacts scope is requested. The extension has sidePanel and identity permissions, with host access for the local backend, Gmail API and Google's revocation endpoint.

Chrome manages its token cache and expiry. Each Gmail operation obtains a non-interactive token. On a 401 the extension removes the cached token and retries once non-interactively; if interaction is required the user must Connect again. Denied consent, 403, 404, timeout, local sign-out and best-effort revocation have explicit UI errors. Revocation removes account access; clearing the local cache alone is not a server-side revocation guarantee.

There is no official API in this design that reveals the message currently open inside Gmail's web UI. The limitation is explicit rather than depending on fragile DOM extraction. Search is user-initiated and fetches only headers for selection; full content is fetched after Analyse.

## Distribution constraints

Gmail read-only is a **restricted** scope. External public use may require restricted-scope verification and, when restricted data is transmitted/stored on servers, a security assessment subject to Google's rules/exemptions. A local prototype and test-user access do not establish public-distribution eligibility. Check current Google verification, Limited Use and Chrome Web Store policies for the final architecture. Confirm test-mode limitations and account eligibility in your console; do not promise permanent test authorization.

Official sources:

- [Chrome OAuth tutorial](https://developer.chrome.com/docs/extensions/how-to/integrate/oauth)
- [Chrome Identity API](https://developer.chrome.com/docs/extensions/reference/api/identity)
- [Side Panel API](https://developer.chrome.com/docs/extensions/reference/api/sidePanel)
- [Gmail scopes](https://developers.google.com/workspace/gmail/api/auth/scopes)
- [Gmail messages resource](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages)
- [List messages](https://developers.google.com/workspace/gmail/api/guides/list-messages)
- [Thread handling](https://developers.google.com/workspace/gmail/api/guides/threads)
- [Restricted-scope verification](https://developers.google.com/identity/protocols/oauth2/production-readiness/restricted-scope-verification)

Manual acceptance checklist (not yet executed): correct profile/test-user consent; denied consent; search finds known message; select and verify exact Gmail source; thread order; missing sender timezone; revoke in account settings and retry; reconnect; sign out; local backend outage. Use a dedicated account with fictional emails and record observed results.
