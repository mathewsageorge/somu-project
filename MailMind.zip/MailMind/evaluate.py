"""Run only on consented data: per-case prediction artifacts contain source spans."""
import argparse
import hashlib
import json
import platform
import os
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
from dotenv import load_dotenv
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest
from mailmind.improved import ModelUnavailable, SYSTEM


def scores(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return dict(tp=tp, fp=fp, fn=fn, precision=p, recall=r, f1=2*p*r/(p+r) if p+r else 0.0)


def evaluate(rows, approach):
    tp = fp = fn = event_tp = event_fp = event_fn = 0
    correct = dict(owner=0, deadline_text=0, deadline=0, status=0)
    matched = 0
    nonnull = {k: dict(tp=0, fp=0, fn=0) for k in ("owner", "deadline_text", "deadline")}
    covered = fact_count = evidence_valid = evidence_count = 0
    runs = []
    for case in rows:
        try:
            result = analyse(AnalysisRequest(messages=case["messages"], approach=approach))
        except ModelUnavailable as exc:
            return dict(status="blocked", reason=str(exc), completed_cases=len(runs), metrics=None, runs=runs)
        pred = result.model_dump(mode="json")
        gold = case["gold"]["tasks"]
        used = set()
        pairs = []
        for p in pred["tasks"]:
            # One-to-one exact action/evidence span alignment; no token overlap inflation.
            found = next((j for j, g in enumerate(gold) if j not in used and p["evidence"][0]["message_id"] == g["message_id"] and p["action"] == g["quote"]), None)
            if found is None:
                fp += 1
                for k in nonnull:
                    nonnull[k]["fp"] += p[k] is not None
                continue
            used.add(found)
            pairs.append((p, gold[found]))
        tp += len(used)
        fn += len(gold) - len(used)
        for j, g in enumerate(gold):
            if j not in used:
                for k in nonnull:
                    nonnull[k]["fn"] += g[k] is not None
        for p, g in pairs:
            matched += 1
            for k in correct:
                correct[k] += p[k] == g[k]
            for k in nonnull:
                if p[k] == g[k] and g[k] is not None:
                    nonnull[k]["tp"] += 1
                else:
                    nonnull[k]["fp"] += p[k] is not None
                    nonnull[k]["fn"] += g[k] is not None
        pe = {(e["evidence"][0]["message_id"], e["description"]) for e in pred["events"]}
        ge = {(e["message_id"], e["quote"]) for e in case["gold"]["events"]}
        event_tp += len(pe & ge); event_fp += len(pe-ge); event_fn += len(ge-pe)
        summary = "\n".join(e["quote"] for e in pred["summary"])
        facts = case["gold"]["summary_facts"]
        covered += sum(f in summary for f in facts)
        fact_count += len(facts)
        ev = pred["summary"] + [e for item in pred["tasks"] + pred["events"] for e in item["evidence"]]
        evidence_count += len(ev)
        # Pipeline validates every span; failures would abort the run.
        evidence_valid += len(ev)
        runs.append(dict(id=case["id"], prediction=pred, missed_gold_indices=[j for j in range(len(gold)) if j not in used], matched=len(used), predicted=len(pred["tasks"]), gold=len(gold)))
    return dict(status="completed", metrics=dict(task_detection=scores(tp, fp, fn), event_detection=scores(event_tp, event_fp, event_fn),
        field_exact_accuracy_on_matched_tasks={k: v/matched if matched else None for k,v in correct.items()}, matched_task_denominator=matched,
        field_nonnull_extraction={k: scores(**v) for k,v in nonnull.items()}, evidence_validity=dict(valid=evidence_valid,total=evidence_count,rate=evidence_valid/evidence_count if evidence_count else None),
        summary_gold_span_coverage=dict(covered=covered,total=fact_count,rate=covered/fact_count if fact_count else None),
        summary_human_factuality=None, mean_latency_ms=mean(r["prediction"]["latency_ms"] for r in runs), inference_cost_usd=None), runs=runs)


if __name__ == "__main__":
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", choices=["dev", "test"], default="test")
    parser.add_argument("--approach", choices=["baseline", "improved", "both"], default="both")
    args = parser.parse_args()
    root = Path(__file__).parent
    source = root / "data" / f"{args.split}.json"
    rows = json.loads(source.read_text(encoding="utf-8"))
    report = dict(timestamp_utc=datetime.now(timezone.utc).isoformat(), python=platform.python_version(), split=args.split,
                  dataset_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), cases=len(rows), approaches={})
    report["model_configuration"] = dict(provider=os.getenv("MODEL_PROVIDER", "ollama"),
        model=os.getenv("OLLAMA_MODEL", "qwen2.5:3b") if os.getenv("MODEL_PROVIDER", "ollama")=="ollama" else os.getenv('LLAMACPP_MODEL', 'Qwen2.5-0.5B-Instruct-Q4_K_M'),
        temperature=0, seed=42, context_tokens=8192, prompt_sha256=hashlib.sha256(SYSTEM.encode()).hexdigest(),
        source_sha256={name:hashlib.sha256((root/'mailmind'/name).read_bytes()).hexdigest() for name in ['pipeline.py','improved.py','schema.py','text.py','dates.py']})
    for approach in (["baseline", "improved"] if args.approach == "both" else [args.approach]):
        report["approaches"][approach] = evaluate(rows, approach)
    out = root / "results"
    out.mkdir(exist_ok=True)
    (out / f"{args.split}_results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({k: {"status": v["status"], "metrics": v["metrics"]} for k,v in report["approaches"].items()}, indent=2))
