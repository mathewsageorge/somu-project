import re
import time
from collections import Counter
from .dates import date_text, deadline_text, normalize_date
from .schema import Analysis, AnalysisRequest, Evidence, Event, Task, validate_evidence
from .text import canonical_text, sentences, suspicious
from .context import event_schedule, task_chunks, contextualize
from .task_state import reconcile, current_state_summary
from .event_state import reconcile_events
from .requirements import link_requirements

REQUEST = re.compile(r"\b(?:please|kindly|can you|could you|would you|must|need to|needs to|will|I'll)\b", re.I)
VERBS = r"send|submit|review|prepare|update|check|book|confirm|upload|share|finish|approve|draft|complete|schedule|deliver|pay|cancel|bring|revise|reply|attend|include"
ACTION = re.compile(rf"\b(?:{VERBS})\b", re.I)
CANCEL = re.compile(r"\b(?:cancelled|canceled|do not|don't|no longer|withdrawn)\b", re.I)
EVENT = re.compile(r"\b(?:meeting|workshop|webinar|call|interview|conference|demo)\b", re.I)


def is_rule_task(sentence: str) -> bool:
    """Shared baseline pattern; a signal for model review, not semantic truth."""
    return bool(ACTION.search(sentence) and (REQUEST.search(sentence) or CANCEL.search(sentence)
                or re.match(rf'^(?:{VERBS})\b', sentence, re.I)
                or re.search(r'\bshould\s+(?:attend|reply|submit|send)\b', sentence, re.I)))


def owner_span(sentence: str) -> str | None:
    # Named addressees and explicit subjects only; no guessing from recipients.
    m = re.match(r"([A-Z][\w'-]*(?: [A-Z][\w'-]*)?),\s+(?:please|could you|can you|kindly)\b", sentence)
    if not m:
        m = re.match(r"([A-Z][\w'-]*(?: [A-Z][\w'-]*)?)\s+(?:will|must|needs to)\b", sentence)
    if m and m.group(1) not in {"I", "We", "You", "They", "He", "She", "It", "This", "The"}:
        return m.group(1)
    return None


def materialize(messages, candidates, approach="baseline", model=None):
    sources = {m.id: canonical_text(m) for m in messages}
    by_id = {m.id: m for m in messages}
    order = {m.id: index for index,m in enumerate(messages)}
    candidates = sorted(candidates, key=lambda row: (order[row[0]], sources[row[0]].find(row[1])))
    tasks, events, ambiguities = [], [], []
    for message_id, sentence, kind in candidates:
        msg = by_id[message_id]
        evidence = [Evidence(message_id=message_id, quote=sentence)]
        schedule, schedule_note = event_schedule(sentence) if kind == 'event' else (sentence, None)
        if schedule_note:
            ambiguities.append(f'{message_id}: {schedule_note}')
        wording = date_text(schedule)
        normalized, reason = normalize_date(wording, msg)
        if reason:
            ambiguities.append(f"{message_id}: {reason}")
        if kind == "task":
            owner = owner_span(sentence)
            status = "cancelled" if CANCEL.search(sentence) else "pending"
            if re.search(r"\b(?:completed|already sent|already submitted|done)\b", sentence, re.I):
                status = "completed"
            if owner is None:
                ambiguities.append(f"{message_id}: Task owner is unspecified or requires coreference review.")
            # A date is a deadline only following an explicit deadline marker.
            chunks, grouped = task_chunks(sentence, VERBS)
            if grouped:
                ambiguities.append(f'{message_id}: Kept linked deliverable actions together under their final deadline; review the shared-deadline interpretation.')
            for index, chunk in enumerate(chunks):
                chunk_owner = owner_span(chunk) or owner
                if len(chunks) > 1 and index == 0:
                    prefix = re.search(rf"\b(?:{VERBS})\b", chunk, re.I)
                    chunk = chunk[prefix.start():] if prefix else chunk
                # A deadline belongs to the clause that actually contains it.
                # Do not move an earlier deadline to a later action or vice versa.
                deadline_wording = deadline_text(chunk)
                deadline, _ = normalize_date(deadline_wording, msg)
                if deadline_wording and not deadline:
                    ambiguities.append(f"{message_id}: Deadline needs review: original wording retained.")
                tasks.append(Task(action=chunk.rstrip(".!?") if len(chunks)>1 else chunk, owner=chunk_owner,
                                  deadline_text=deadline_wording,
                                  deadline=deadline, status=status, evidence=evidence))
            if len(chunks)>1:
                ambiguities.append(f"{message_id}: Compound request split; review whether a stated deadline applies to the other action.")
        elif kind == "event":
            clock = re.search(r"\b\d{1,2}(?::\d{2})?\s*(?:am|pm)\b|\b\d{2}:\d{2}\b", schedule, re.I)
            zone = re.search(r"\b(?:UTC|GMT|[A-Za-z_]+/[A-Za-z_]+)\b", schedule)
            abbreviation = re.search(r'\b(?:IST|CST|BST|EST|PST)\b', schedule)
            confirmed_zone = zone.group() if zone else msg.timezone
            if clock and not confirmed_zone:
                if abbreviation:
                    ambiguities.append(f"{message_id}: Timezone abbreviation {abbreviation.group()} needs confirmation; enter an IANA timezone such as Asia/Kolkata if intended. No UTC conversion performed.")
                else:
                    ambiguities.append(f"{message_id}: Event timezone is missing; no UTC conversion performed.")
            events.append(Event(description=sentence, date_text=wording, date=normalized,
                                time_text=clock.group() if clock else None, timezone=confirmed_zone,
                                timezone_raw=zone.group() if zone else (abbreviation.group() if abbreviation else None),
                                status="cancelled" if CANCEL.search(sentence) else ("announced" if schedule else "needs_review"), evidence=evidence))
    reconcile_events(events, sources, ambiguities)
    link_requirements(tasks, sources, ambiguities)
    contextualize(tasks, events, sources, ambiguities)
    reconcile(tasks, messages, ambiguities, ACTION, VERBS)
    all_sentences = [(m.id, s) for m in messages for s in sentences(sources[m.id]) if not suspicious(s)]
    counts = Counter(w.lower() for _, s in all_sentences for w in re.findall(r"\b\w{4,}\b", s))
    selected = sorted(all_sentences, key=lambda x: sum(counts[w.lower()] for w in re.findall(r"\b\w{4,}\b", x[1])) / max(1, len(x[1].split())), reverse=True)[:3]
    summary = [Evidence(message_id=i, quote=s) for i, s in all_sentences if (i, s) in selected][:3]
    for m in messages:
        if suspicious(sources[m.id]):
            ambiguities.append(f"{m.id}: Potential embedded instructions excluded; inspect the original email.")
    return validate_evidence(Analysis(summary=summary, tasks=tasks, events=events,
                            ambiguities=list(dict.fromkeys(ambiguities)), approach=approach,
                            model=model, latency_ms=0), sources)


def analyse(request: AnalysisRequest) -> Analysis:
    start = time.perf_counter()
    messages = request.messages
    # Sort only with complete timestamp context; never compare aware and naive times.
    if all(m.sent_at for m in messages):
        messages = sorted(messages, key=lambda m: m.sent_at)
    if request.approach == "structured":
        from .structured import structured
        result = structured(messages)
    elif request.approach == "improved":
        from .improved import improved
        result = improved(messages)
    else:
        candidates = []
        for m in messages:
            for s in sentences(canonical_text(m)):
                if suspicious(s):
                    continue
                is_task = is_rule_task(s)
                if is_task:
                    candidates.append((m.id, s, "task"))
                elif EVENT.search(s) and (date_text(s) or re.search(r"\bat\b|cancelled|canceled", s, re.I)):
                    candidates.append((m.id, s, "event"))
        result = materialize(messages, candidates)
    if request.approach != "structured":
        result = current_state_summary(result, ACTION, VERBS)
    validate_evidence(result, {m.id: canonical_text(m) for m in messages})
    result.latency_ms = round((time.perf_counter() - start) * 1000, 2)
    return result
