# Pretrained model comparison

Recorded UTC: 2026-10-08T05:39:10.238281+00:00

Same prompt and rules; previously inspected development/diagnostic cases. Not an independent held-out accuracy estimate. No fine-tuning.

| Set | Method | Task precision | Task recall | Task F1 | Event F1 | Mean latency (ms) |
|---|---|---:|---:|---:|---:|---:|
| dev | rules | 1.000 | 0.917 | 0.957 | 1.000 | 2.7 |
| event_challenge_v2 | rules | 0.800 | 0.667 | 0.727 | 1.000 | 0.8 |
| dev | qwen25_05b | 0.833 | 0.833 | 0.833 | 1.000 | 1331.9 |
| event_challenge_v2 | qwen25_05b | 0.714 | 0.833 | 0.769 | 1.000 | 1241.7 |
| dev | qwen35_4b | 1.000 | 0.833 | 0.909 | 1.000 | 1923.7 |
| event_challenge_v2 | qwen35_4b | 1.000 | 1.000 | 1.000 | 1.000 | 1751.1 |

## Longer project-review email

Counts are extraction records, not accuracy scores. The current rules split the slide-preparation and sharing instructions and keep report contents as a separate task. Owners from greetings/pronouns remain unresolved; no new coreference model was added.

### rules

7 task records; 1 event records; 4.9 ms.

- [pending] Please complete the revised project report and email it to Dr. Meera by 12 October 2026 at 5:00 PM IST. — owner: unresolved; calendar deadline: 2026-10-12.
- [pending] Include the updated methodology, experimental results, and references. — owner: unresolved; calendar deadline: unresolved/not specified.
- [pending] prepare the presentation slides by 13 October 2026 at 6:00 PM IST — owner: Ananya; calendar deadline: 2026-10-13.
- [pending] share them with Rahul — owner: Ananya; calendar deadline: unresolved/not specified.
- [pending] Both of you should attend. — owner: unresolved; calendar deadline: unresolved/not specified.
- [cancelled] You no longer need to submit a printed copy of the report. — owner: unresolved; calendar deadline: unresolved/not specified.
- [pending] Please reply by 9 October 2026 to confirm that you received these instructions. — owner: unresolved; calendar deadline: 2026-10-09.
- Event: Our project review meeting is scheduled for 14 October 2026 at 10:30 AM IST in Seminar Hall B.

Review notes:

- pasted-1: Task owner is unspecified or requires coreference review.
- pasted-1: Compound request split; review whether a stated deadline applies to the other action.
- pasted-1: Timezone abbreviation IST needs confirmation; enter an IANA timezone such as Asia/Kolkata if intended. No UTC conversion performed.

### qwen25_05b

1 task records; 1 event records; 4294.9 ms.

- [pending] Please complete the revised project report and email it to Dr. Meera by 12 October 2026 at 5:00 PM IST. — owner: unresolved; calendar deadline: 2026-10-12.
- Event: Our project review meeting is scheduled for 14 October 2026 at 10:30 AM IST in Seminar Hall B.

Review notes:

- pasted-1: Task owner is unspecified or requires coreference review.
- pasted-1: Timezone abbreviation IST needs confirmation; enter an IANA timezone such as Asia/Kolkata if intended. No UTC conversion performed.
- AI extraction is incomplete: 3 proposed event(s) failed rule checks. Review the rejected sentences below or compare Rules only; no replacement tasks were invented.
- pasted-1: Rejected unsupported event label: Include the updated methodology, experimental results, and references.
- pasted-1: Rejected unsupported event label: Ananya, please prepare the presentation slides by 13 October 2026 at 6:00 PM IST and share them with Rahul.
- pasted-1: Rejected unsupported event label: Both of you should attend.
- Model-selected categories require review; exact evidence does not prove a correct interpretation.

### qwen35_4b

3 task records; 1 event records; 7867.2 ms.

- [pending] Please complete the revised project report and email it to Dr. Meera by 12 October 2026 at 5:00 PM IST. — owner: unresolved; calendar deadline: 2026-10-12.
- [pending] prepare the presentation slides by 13 October 2026 at 6:00 PM IST — owner: Ananya; calendar deadline: 2026-10-13.
- [pending] share them with Rahul — owner: Ananya; calendar deadline: unresolved/not specified.
- Event: Our project review meeting is scheduled for 14 October 2026 at 10:30 AM IST in Seminar Hall B.

Review notes:

- pasted-1: Task owner is unspecified or requires coreference review.
- pasted-1: Compound request split; review whether a stated deadline applies to the other action.
- pasted-1: Timezone abbreviation IST needs confirmation; enter an IANA timezone such as Asia/Kolkata if intended. No UTC conversion performed.
- Model-selected categories require review; exact evidence does not prove a correct interpretation.

## Interpretation limits

- Both model methods use the same prompt, temperature 0, seed 42, schema and deterministic rules. Different families and model sizes are compared; this does not isolate parameter count alone.
- The old model uses CPU inference and the candidate uses GPU offloading. Timing is a deployment comparison, not a controlled hardware benchmark. One sequential run and prompt caches limit timing conclusions.
- These fictional sets have already been inspected during development. No result here is a new independent test estimate, proof of generalization, or human summary-factuality score.
- Exact evidence matching does not prove a correct interpretation. The model still chooses sentences; owners, date normalization and thread reconciliation use the existing rules.
- After this frozen comparison, review warnings were added for unclassified sentences and no-action labels that conflict with request/cancellation patterns. These checks disclose disagreement; they do not replace predictions with rule-generated tasks. See project-review-qwen35-labels.json for the inspected longer-email labels. The four missed instructions were explicitly labelled none.
- Model weights were not trained. Before considering fine-tuning, collect independently checked longer emails with consent and freeze a fresh test set.
- Per-case predictions, token usage, source hashes and advertised model identities are in the linked JSON. Local inference API cost is not a measured electricity or hardware cost.

Full measurements: [model-size-comparison.json](model-size-comparison.json).
