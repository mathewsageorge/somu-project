import json
import pytest
from mailmind.schema import AnalysisRequest, Message
from mailmind.pipeline import analyse
from mailmind.improved import ModelUnavailable


def test_named_local_candidate(monkeypatch):
    import mailmind.improved as module
    monkeypatch.setenv('MODEL_PROVIDER', 'llamacpp')
    monkeypatch.setenv('LLAMACPP_URL', 'http://127.0.0.1:8082')
    monkeypatch.setenv('LLAMACPP_MODEL', 'Qwen3.5-4B-Q4_K_M')
    class Response:
        def raise_for_status(self): pass
        def json(self): return {'choices':[{'message':{'content':json.dumps({'items':[], 'summary_ids':[0]})}}]}
    def post(self, url, **kwargs):
        assert url == 'http://127.0.0.1:8082/v1/chat/completions'
        assert kwargs['json']['model'] == 'Qwen3.5-4B-Q4_K_M'
        return Response()
    monkeypatch.setattr(module.httpx.Client, 'post', post)
    r = analyse(AnalysisRequest(messages=[Message(id='m', body='The file is attached.')], approach='improved'))
    assert r.model == 'Qwen3.5-4B-Q4_K_M'


@pytest.mark.parametrize('url', ['https://example.com', 'http://127.0.0.1:8082/private', 'http://user:pass@127.0.0.1:8082', 'http://192.168.0.1:8082'])
def test_candidate_cannot_send_mail_to_remote_or_credentialed_url(monkeypatch, url):
    monkeypatch.setenv('MODEL_PROVIDER', 'llamacpp')
    monkeypatch.setenv('LLAMACPP_URL', url)
    with pytest.raises(ModelUnavailable, match='loopback'):
        analyse(AnalysisRequest(messages=[Message(id='m', body='The file is attached.')], approach='improved'))


def test_omitted_sentence_is_disclosed_without_inventing_task(monkeypatch):
    import mailmind.improved as module
    monkeypatch.setenv('MODEL_PROVIDER', 'llamacpp')
    monkeypatch.setenv('LLAMACPP_URL', 'http://127.0.0.1:8082')
    class Response:
        def raise_for_status(self): pass
        def json(self): return {'choices':[{'message':{'content':json.dumps({'items':[{'sentence_id':0,'kind':'task'}], 'summary_ids':[0]})}}]}
    monkeypatch.setattr(module.httpx.Client, 'post', lambda *a, **k: Response())
    body = 'Please send the file. Please reply to confirm receipt.'
    r = analyse(AnalysisRequest(messages=[Message(id='m',body=body)], approach='improved'))
    assert len(r.tasks) == 1
    assert any(a.startswith('AI extraction is incomplete: 1 source') for a in r.ambiguities)
    assert 'm: Unclassified sentence: Please reply to confirm receipt.' in r.ambiguities


def test_none_label_conflicting_with_requests_is_flagged_not_replaced(monkeypatch):
    import mailmind.improved as module
    monkeypatch.setenv('MODEL_PROVIDER', 'llamacpp')
    monkeypatch.setenv('LLAMACPP_URL', 'http://127.0.0.1:8082')
    class Response:
        def raise_for_status(self): pass
        def json(self): return {'choices':[{'message':{'content':json.dumps({'items':[
            {'sentence_id':i, 'kind':'none'} for i in range(3)], 'summary_ids':[0]})}}]}
    monkeypatch.setattr(module.httpx.Client, 'post', lambda *a, **k: Response())
    body = 'Please reply to confirm receipt. You no longer need to submit a printed copy. A PDF is sufficient.'
    r = analyse(AnalysisRequest(messages=[Message(id='m',body=body)], approach='improved'))
    assert not r.tasks and not r.events
    assert any(a.startswith('AI extraction is incomplete: 2 sentence(s) labelled no action') for a in r.ambiguities)
    assert len([a for a in r.ambiguities if 'Model/rule disagreement' in a]) == 2
    assert not any('A PDF' in a for a in r.ambiguities)
