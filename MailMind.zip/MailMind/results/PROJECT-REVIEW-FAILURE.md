# Longer-email failure and bounded repair — 7 October 2026

The user's project-review email exposed a substantial failure in the experimental Qwen2.5-0.5B model. The original screenshot output was reproduced exactly: the subject became a task, and the greeting and nine other sentences/fragments became events. This was not correct extraction. The previously reported success on short examples did not establish reliability on longer emails.

## Verified changes

- Protect spaced honorifics such as `Dr. Meera` during sentence splitting. Previously only compact `Dr.Meera` was protected. Exact source spans remain intact.
- Exclude pasted subject lines and standalone salutations from extraction candidates without modifying canonical source text.
- Recognize full English day/month/year dates, normalize valid calendar dates, and preserve original time/zone wording. Missing years and numeric ambiguous dates remain unresolved.
- Stop deadline spans before subsequent work clauses. A deadline stays with the compound clause that contains it, rather than always moving to the final clause.
- Add baseline recognition of direct imperatives and explicit attendance requests. Display task owner, status and deadline wording in the demo without requiring JSON expansion.
- Reject model event labels lacking supported gathering vocabulary or conflicting with an explicit work request. Rejections are visible; they are not silently converted to tasks or replaced with baseline answers. These vocabulary rules can also reject legitimate unfamiliar events and do not validate all possible semantic errors.
- Distinguish an ambiguous timezone abbreviation such as IST from a wholly absent timezone. Accept user-confirmed IANA timezone context; do not infer a UTC instant.

No model weights or production prompt were changed. Two single-sentence experiments failed to resolve classification errors and were not adopted. Their probe artifacts are retained; they are development experiments, not held-out evaluation.

## Actual output on the reported email

`project-review-before.json`, `project-review-parser-only.json`, and `project-review-after.json` contain actual predictions and source hashes.

The updated baseline produces six pending action records, one cancelled printed-copy record, and one meeting. It splits preparing and sharing slides, and treats report contents as a separate instruction. These are sentence/clause records rather than an ideal merged checklist. It extracts Ananya directly but does not resolve Rahul from the greeting or “both of you” across sentences. The report, slides and reply calendar dates are October 12, 13 and 9 respectively; the event date is October 14. The slides deadline is not automatically applied to the separate sharing action. Location is retained in event description/evidence, not a separate location field.

The updated AI produces **only one task and one event**. Three incorrect proposed event labels are rejected and clearly flagged. It still omits valid instructions and the cancelled request. This output remains incomplete and must not be described as a successful extraction. The correct meeting has original `10:30 AM IST` wording; timezone remains unresolved without confirmed IANA context.

## Checks and limitations

51 automated Python tests passed, with one existing test-client deprecation warning (`python-tests-project-review.xml`). These tests cover program behaviour, not general AI accuracy. The running Streamlit AI flow was checked in the browser: the incomplete-result banner, intact report sentence, parsed report deadline and single meeting were visibly verified. Screenshot: `project-review-warning.jpg`.

Both methods were rerun on the existing 12-case development set and 12-case diagnostic set (`project-review-regression-checks.json`). Those sets have already been inspected; this is regression measurement, not a fresh held-out evaluation.

| Existing set | Approach | Task precision | Task recall | Task F1 | Event F1 |
|---|---|---:|---:|---:|---:|
| Development | Rules | 1.000 | 0.917 | 0.957 | 1.000 |
| Development | AI + checks | 0.833 | 0.833 | 0.833 | 1.000 |
| Diagnostic | Rules | 0.800 | 0.667 | 0.727 | 1.000 |
| Diagnostic | AI + checks | 0.714 | 0.833 | 0.769 | 1.000 |

The latest AI diagnostic task F1 is below the earlier 0.857 result. Do not select only favourable numbers. Prompt/schema constraints and source quoting do not guarantee semantic accuracy, and results can change with parsing and inference execution. The main system remains experimental. Future work should compare a more capable local model using frozen instructions and independently checked longer emails, explicitly evaluating cross-sentence owners, grouped actions, cancellations and summary coverage. This user-reported case is now development/regression data and cannot serve as unseen test evidence.

Reproduce from the project directory:

```powershell
python scripts/check_project_review.py project-review-new-run.json
python scripts/check_existing_cases.py
python -m pytest -q
```

Live inference requires the already documented local llama.cpp server on port 8081. Evaluation artifacts intentionally persist input spans for this user-reported regression; ordinary app analyses still are not stored by default.
