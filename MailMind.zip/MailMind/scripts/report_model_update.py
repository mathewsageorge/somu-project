import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
report=json.loads((ROOT/'results/event-challenge-v3.json').read_text(encoding='utf-8'))
gold={c['id']:c['gold'] for c in json.loads((ROOT/'data/event_challenge_v2.json').read_text(encoding='utf-8'))}
lines=['# Model instructions update — 7 October 2026','',
       'The pretrained model weights are unchanged. We added task/event examples to its instructions and an explicit **none** label for sentences that contain neither. Deterministic field extraction, evidence validation and the rule-only baseline remain unchanged. This is prompt/schema engineering, not model training.',
       '', '## New diagnostic comparison','',
       '12 new fictional cases were frozen before their first inference run. They contain six gold tasks and four gold events. They were not supplied in the model prompt or used to revise it after evaluation. They are authored by the same implementation assistant, so they are not an independent blinded benchmark. Existing October 6 research results remain historical.',
       '', '| Method | Tasks found | Extra tasks | Task F1 | Events found | Extra events | Event F1 | Mean ms |',
       '|---|---:|---:|---:|---:|---:|---:|---:|']
for name,run in report['runs'].items():
    assert run['status']=='completed'
    m=run['metrics'];t=m['task_detection'];e=m['event_detection']
    lines.append(f"| {name} | {t['tp']}/6 | {t['fp']} | {t['f1']:.3f} | {e['tp']}/4 | {e['fp']} | {e['f1']:.3f} | {m['mean_latency_ms']:.1f} |")
lines+=['','## Remaining revised-model errors','']
for row in report['runs']['revised_model']['runs']:
    g=gold[row['id']]
    for item in row['prediction']['tasks']:
        match=next((t for t in g['tasks'] if t['quote']==item['action']),None)
        if match is None:
            lines.append(f"- {row['id']}: false task — {item['action']}")
        elif match['deadline_text']!=item['deadline_text']:
            lines.append(f"- {row['id']}: deadline wording '{item['deadline_text']}' vs gold {match['deadline_text']}; normalized date remains null.")
lines+=['', '## Development decisions and limitations', '',
        'The original 12 development cases were used to compare two revisions. Examples alone (candidate v2) improved meeting recall but created five false events. Adding an explicit none label (v3) reduced this to one false event on development. V3 was chosen using the mean of task and event F1 across development results. It still reduced task recall on development from 12/12 to 10/12 and worsened state tracking for cancellations/updates. It must remain experimental; rules remain the application default.',
        '', 'Development artifacts: prompt-development-v2.json and prompt-development-v3.json record exploratory runs. In the exploratory v3 run, the original prompt was also given the three-label schema. prompt-development-final-v3.json reruns the comparison with the original prompt’s original two-label schema. event-challenge-v3.json likewise uses the original two-label schema for the original-model comparison. The revision bundles prompt examples and a schema change; the experiment does not isolate their independent effects.',
        '', 'The challenge manifest records the initial source freeze and the final evaluated source hash, updated before any challenge inference. No challenge-driven prompt revision was made. Final prompts and hashes, allowed labels, per-case predictions, token counts and latency are saved. Small synthetic cases, same-author labels, prompt caching and one sequential run limit conclusions. Evidence matching is still not semantic validation; human summary factuality has not been evaluated.',
        '', '## What the student should test', '',
        'In the demo choose **AI model + rule checks (experimental)** and analyse the Asha/Ravi tutorial email. Expected: two tasks and the team meeting under Events. Then use a different invented email and write the correct answer yourself before running either method. Record misses and extra items rather than assuming the model is correct. A larger, independently labelled evaluation remains the next research stage.']
(ROOT/'results/MODEL-UPDATE.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Wrote results/MODEL-UPDATE.md from actual challenge predictions.')
