"""Read-only laptop telemetry. No email data, persistence or extra dependencies."""
import csv
import ctypes
import math
import platform
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path


class _MemoryStatus(ctypes.Structure):
    _fields_ = [("length", ctypes.c_uint32), ("load", ctypes.c_uint32),
                ("total", ctypes.c_uint64), ("available", ctypes.c_uint64),
                ("page_total", ctypes.c_uint64), ("page_available", ctypes.c_uint64),
                ("virtual_total", ctypes.c_uint64), ("virtual_available", ctypes.c_uint64),
                ("extended", ctypes.c_uint64)]


def _ram():
    if platform.system() == "Windows":
        value = _MemoryStatus()
        value.length = ctypes.sizeof(value)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)):
            raise OSError("Memory reading unavailable")
        total, available = value.total, value.available
    elif platform.system() == "Linux":
        fields = {line.split(":", 1)[0]: int(line.split()[1]) * 1024
                  for line in Path("/proc/meminfo").read_text().splitlines()
                  if line.startswith(("MemTotal:", "MemAvailable:"))}
        total, available = fields["MemTotal"], fields["MemAvailable"]
    else:
        return None
    if total <= 0 or not 0 <= available <= total:
        return None
    return {"used_mib": (total - available) / 1048576,
            "total_mib": total / 1048576, "percent": (total - available) * 100 / total}


def _number(text):
    try:
        value = float(text)
        return value if math.isfinite(value) and value >= 0 else None
    except ValueError:
        return None


def _parse_gpu(text):
    rows = list(csv.reader(text.strip().splitlines()))
    if not rows or len(rows[0]) != 4:
        return None
    name, used, total, utilization = [cell.strip() for cell in rows[0]]
    used, total, utilization = _number(used), _number(total), _number(utilization)
    if not name:
        return None
    if total is None or total <= 0 or used is None or used > total:
        used, total = None, None
    if utilization is not None and utilization > 100:
        utilization = None
    return {"name": name[:200], "used_mib": used, "total_mib": total,
            "utilization_percent": utilization}


def _gpu():
    executable = shutil.which("nvidia-smi")
    if not executable:
        return None
    result = subprocess.run(
        [executable, "--id=0", "--query-gpu=name,memory.used,memory.total,utilization.gpu",
         "--format=csv,noheader,nounits"],
        capture_output=True, text=True, timeout=1.5, check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return _parse_gpu(result.stdout) if result.returncode == 0 else None


def sample_resources():
    """Unavailable measurements stay null, never fabricated as zero usage."""
    sample = {"sampled_at": datetime.now(timezone.utc).isoformat(), "ram": None, "gpu": None}
    for key, reader in [("ram", _ram), ("gpu", _gpu)]:
        try:
            sample[key] = reader()
        except (OSError, AttributeError, ValueError, KeyError, subprocess.TimeoutExpired):
            pass
    return sample
