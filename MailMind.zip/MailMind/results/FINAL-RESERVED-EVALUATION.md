# First reserved evaluation of the frozen MailMind system

Executed on 8 October 2026. **The reserved set has now been evaluated and inspected; it must not be called unseen in future iterations.** The application, prompt and field/status rules were frozen before this run and were not changed in response to its predictions. This is the final execution on this split for the frozen version, not a claim that the project or independent research evaluation is complete.

## Experimental boundary

The 12 fictional cases contain 13 labelled task records and four events. They were separately stored and not previously sent through either NLP approach. Labels were authored before inference. However, the implementation assistant authored both development and reserved data and knew the system: this is **reserved execution, not an independent blind benchmark**. No independent annotation, human agreement measurement, real-email study, training or fine-tuning took place.

The model is the local Qwen3.5-4B Q4_K_M candidate. Its actual weight SHA256 and advertised runtime identifier were checked before inference. The existing final development source hashes also matched current code. `reserved-v2-freeze.json` records the pre-run freeze; `evaluation-v2-reserved/source.zip` preserves the evaluated code. Both methods used the same inputs and labels. Raw results were not replaced by fallback or mock output.

## Actual results

| Measure | Rules only | AI + shared rule checks |
|---|---:|---:|
| Task records found / labelled | 9 / 13 | 12 / 13 |
| Extra task records | 0 | 0 |
| Task precision | 1.000 | 1.000 |
| Task recall | 0.692 | 0.923 |
| Task F1 | 0.818 | 0.960 |
| Correct status / matched task records | 7 / 9 | 9 / 12 |
| Correctly detected AND correct-status task records / all labelled tasks | 7 / 13 | 9 / 13 |
| Events found / labelled | 4 / 4 | 4 / 4 |
| Mean latency per case | 1.5 ms | 1967.6 ms |
| Exact evidence validity | 35 / 35 | 35 / 35 |
| Summary key-span inclusion | 16 / 16 | 15 / 16 |
| Human summary factuality | Not measured | Not measured |

Detection uses one-to-one exact source-message/action-span matching. It is sensitive to annotation boundaries. Status accuracy has a different matched-task denominator for each method, so it must not be mistaken for end-to-end accuracy. The combined detection-and-status row is derived from matched records with correct status; it exposes errors hidden by detection F1 alone. Historical requests and cancellation records count as task records even when they are not pending work.

| Non-null field extraction F1, including missed tasks | Rules only | AI + shared rules |
|---|---:|---:|
| Owner | 0.941 | 0.941 |
| Original deadline wording | 0.889 | 0.947 |
| Normalized deadline date | 0.875 | 0.941 |

All five scored event fields (date wording, calendar date, clock, timezone and status) matched the four gold events for both methods. Four events are too few to support broad claims, and correct nulls are not successful entity extraction. Local inference cost is null because hardware/electricity cost was not measured; there is no invented API bill. Reported latency is one run, affected by cache, hardware and HTTP overhead.

## What failed

1. **Paraphrased cancellation — v2-reserved-09.** “We no longer need that memo” was missed as a cancellation record by both methods. The earlier travel-memo task stayed pending instead of cancelled. The AI summary also omitted that exact cancellation sentence, illustrating why exact evidence alone is not summary factuality.
2. **Paraphrased deadline update — v2-reserved-10.** “Please make that 2027-06-20 for the invoice instead” was detected as a task only by the AI method, but it did not resolve Hari, the revised deadline fields, or the review status. Both methods left the earlier request pending instead of superseded. This is a contextual-linking/field-extraction failure, not solely a sentence-classification failure.
3. **Unrecognised action wording.** Rules missed the translation request and the accessible-transport request, which the AI detected. This supports a limited observation of better recall on this fictional split, not a general superiority or novelty claim.

The rule status pass deliberately requires a narrow explicit action match. It does not perform general pronoun resolution or semantic equivalence. These limitations were left unchanged during this reserved evaluation. Correct evidence shows where text came from; it does not prove the assigned owner, state or interpretation.

## Difference from development performance

The tuned development run found 22/22 labelled task records with correct matched statuses using AI plus rules. The reserved run found 12/13, and only 9/12 returned records had correct status. Report both results with their split sizes and provenance. Do not present the development perfect score as “100% accurate,” nor label task F1 as overall application accuracy. These small same-author data support initial engineering tests, not real-world generalisation or statistical superiority.

## Artifacts and next research work

- `evaluation-v2-reserved/results.json`: actual predictions, metrics, event field denominators, source hashes, token usage and errors.
- `evaluation-v2-reserved/REPORT.md`: detailed generated error listing.
- `evaluation-v2-reserved/human-review.csv`: 24 shuffled summary-review rows, with ratings deliberately blank. Keep `review-method-key.json` away from raters. No human result is claimed.
- `reserved-v2-freeze.json`: model and source verification before inference.
- `data/evaluation_v2/reserved-execution.json`: records that this split is now consumed.

For the thesis, ask two independent reviewers to inspect labels and rate summary claims against whole threads. Report agreement and adjudication separately. If later changes address these now-known errors, evaluate that next version on a fresh independently authored set, or on consented and anonymised real emails under the documented protocol. Preserve these results; do not tune and rerun this split while calling it unseen.

The most recent software suite remains 99 passing tests from the lifecycle implementation. This turn changed evaluation documentation and artifacts only; it did not rerun that suite or change NLP code. Google OAuth/live Gmail validation remains a separate pending integration task.
