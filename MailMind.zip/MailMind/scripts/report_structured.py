"""Aggregate recorded runs; does not invoke inference or re-label examples."""
import json, statistics, sys
from pathlib import Path
root=Path(sys.argv[1]);data=json.loads((root/'results.json').read_text())
metrics={}
for method in ['baseline','improved','structured']:
 rows=[r for r in data['runs'] if r['method']==method]
 valid=[r for r in rows if 'metrics' in r]
 tp=sum(r['metrics']['tp'] for r in valid);fp=sum(r['metrics']['fp'] for r in valid);fn=sum(r['metrics']['fn'] for r in valid)
 fields=[f for r in valid for f in r['metrics']['matched_fields']]
 lat=[r['output']['latency_ms']/1000 for r in valid]
 metrics[method]={'successful_runs':len(valid),'failed_runs':len(rows)-len(valid),'tp':tp,'fp':fp,'fn':fn,'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn) if tp+fn else None,'f1':2*tp/(2*tp+fp+fn) if tp+fp+fn else None,'owner_exact_correct':sum(f['owner_correct'] for f in fields),'deadline_exact_correct':sum(f['deadline_correct'] for f in fields),'status_exact_correct':sum(f['status_correct'] for f in fields),'matched_task_denominator':len(fields),'evidence_valid_runs':sum(r.get('evidence_valid',False) for r in rows),'median_seconds':statistics.median(lat),'range_seconds':[min(lat),max(lat)],'resource_sampled_peaks':{k:max(r['resources']['sampled_peaks'].get(k,0) for r in rows) for k in ['gpu_memory_used_mib','system_ram_used_mib','gpu_utilization_percent']}}
(root/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
print(json.dumps(metrics,indent=2))
