# MailMind: Email Summarization and Action Item Extraction

**Running this on a friend's Windows/NVIDIA laptop?** Start with the [beginner setup guide (PDF)](docs/MailMind_Beginner_Setup_Guide.pdf). Use the [copyable text version](docs/BEGINNER-SETUP.md) for commands. It explains extraction, Python installation, the separate Qwen download, two-terminal startup, first tests, next-day restart and common errors. Send the updated `MailMind.zip`; model weights and environments are excluded.

**12 October 2026 - Loading activity update:** A floating animated activity card stays visible during Analyse, with elapsed time and live RAM/GPU samples. Laptop usage appears only during analysis; there is no initial/idle usage panel or polling. Code callbacks report preparation, local runtime waiting and returned-output validation. No invented percentage or ETA. Latest suite: **192 passing tests**. A live Case 22 check returned unchanged extraction content (3 tasks, 1 event) in 62.38 s. This is not a controlled latency comparison. See [verification notes](results/LOADING-ACTIVITY.md). Chrome/Gmail remain future scope.

**Previous hardware-monitor update (historical results) — local web application.** Chrome extension integration and Gmail connection are **future scope**, as requested; exploratory source is retained without claiming a completed connected workflow. The Streamlit Deploy button is hidden. The new **Live laptop usage** panel refreshes system RAM, NVIDIA GPU-0 activity and GPU memory about every two seconds, including during inference. These are whole-machine readings, not model-only allocation or calibrated benchmarks. Missing readings show Unavailable. No extra dependencies or telemetry persistence. **187 tests passed**; Case 22 model analysis/export still worked with monitoring enabled (3 tasks, 1 event, 51.25 s). See [change and verification notes](results/LIVE-RESOURCES-AND-SCOPE.md), the [updated report](submission/MailMind_Project_Report.pdf) and [updated presentation](submission/MailMind_Presentation_Loading.pptx). Earlier entries retain historical scope/results.

**Earlier submission release — 12 October 2026.** [20-page project report](submission/MailMind_Project_Report.pdf), [19-slide editable presentation with notes](submission/MailMind_Presentation_Loading.pptx), and [demo/viva guide](submission/DEMONSTRATION-AND-VIVA.md) are ready for review. Author: Sonu Jacob Jose. All **177 Python tests** and the extension build passed. Final live Case 22 analysis/export were verified (3 tasks, 1 event, 53.81 s). Latest eight-case development task precision/recall/F1: **0.846 / 1.000 / 0.917**; field improvements coexist with an extra false-positive task and remaining summary errors. Repeated final Case 22 median: **49.99 s**, with comparison conditions/limits documented. Read [the submission update](results/SUBMISSION-UPDATE.md) first. Entries below are historical, including older counts and timings; they are not measurements of this release.

**12 October 2026 — Case 22 update: partial pass.** Structured AI now supplies separately cited collective owners, event names, participants and schedule history. A PM parsing defect is fixed. The unchanged Qwen produced three Case 22 tasks, one meeting and 14:45 source-local arrival in the live demo. All 173 Python tests and the extension build passed; browser analysis/export were verified. Summary omissions, semantic attribution errors and an extra dependency task remain on development cases. Repeated Case 22 latency was 59.45 seconds median, versus 26.18 for earlier structured AI and 9.23 for sentence selection. Read the [complete findings and limitations](results/CASE22-REPORT.md) and [testing steps](docs/STRUCTURED-EXTRACTION.md). All dated results below describe earlier versions.

**11 October 2026 — Structured AI is available.** The unchanged local Qwen now extracts task groups, owners, event links and a natural summary as validated JSON. Rules Only and Previous AI remain selectable. Start with [how to test](docs/STRUCTURED-EXTRACTION.md) and the [measured comparison](results/STRUCTURED-EXTRACTION-REPORT.md). Earlier results below refer to historical implementations, not the new method.

An MTech research prototype with a FastAPI backend, a Chrome Manifest V3 side panel, a Streamlit demo, a rule baseline and a constrained local pretrained-model approach. No Google account or paid API key is needed for the demo. Nothing is trained in this project. The label “improved” identifies the proposed model method, **not a claim that it outperforms the baseline**.

Latest: [first reserved evaluation](results/FINAL-RESERVED-EVALUATION.md), 8 October 2026. On 12 previously unrun fictional cases, the frozen AI method found 12/13 labelled task records (F1 0.960); rules found 9/13 (F1 0.818). Both returned no extra task records, but paraphrased updates still caused incorrect task states. This is a small same-author study, not independent real-email validation. The reserved set has now been consumed; references to it being unrun below are historical.

Current update: [cancellation/completion tracking](results/TASK-STATE-UPDATE.md). Later explicit updates now change earlier matched task states, retain source evidence and guide summary selection. All 99 software tests passed. The AI method now detects 22/22 task records with correct matched statuses on the same 24 development cases used for tuning; this is not a claim about unseen or real email. The 12 reserved cases remain unrun. Results below describe earlier versions.

Newest evaluation: [beginner testing guide](docs/EVALUATION-V2-GUIDE.md) and [actual v2 development results](results/evaluation-v2-development/REPORT.md). Added 24 labelled fictional development cases and 12 reserved cases kept unrun. Labels were frozen before inference. Both methods were run on identical development inputs: rules detected 20/22 labelled task records, AI plus rules 21/22, with no extra tasks; cancellation/completion status errors remain. These are same-author draft annotations, not independently validated research ground truth. The demo includes the new development examples and expandable expected answers, and clears stale results when inputs/methods change. Reserved cases are excluded from the demo.

Latest: [rescheduled-meeting fixes and actual results](results/RESCHEDULED-REVIEW.md), 8 October 2026. The supplied regression now produces three grouped tasks and one meeting with the revised date; contextual owners and calculated early arrival are explicitly marked for review. All 71 software tests passed, which does not establish NLP accuracy. Known cancellation/status and deadline-text errors remain on the reused regression sets. The demo calls the options **Rules only (baseline)** and **AI model + rule checks (experimental)**; the internal API uses `baseline` and `improved`. The [earlier 4B model comparison](results/MODEL-SIZE-COMPARISON.md) predates these prompt/rule changes; [model setup](docs/MODEL-COMPARISON.md) remains applicable.

Current verified demo: **http://127.0.0.1:8502/** (4B configuration). An older demo may still be running on 8501; use 8502 for the new comparison. See the setup guide above for the exact launch command.

## 1. Install and run the pasted-email demo

Prerequisites: Python 3.13 (tested), Node.js 24/npm (tested), Chrome 116+ for the extension. Use a terminal in the MailMind directory. Commands below use Windows PowerShell; on Linux/macOS use `python3` and `.venv/bin/python`.

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.lock
.venv\Scripts\python -m streamlit run demo.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

Select a fictional example or paste an email, choose **baseline**, and click **Analyse**. Relative dates require an offset-aware sender timestamp plus confirmed IANA timezone. Unknown fields remain null. Click **Clear analysis** to remove the displayed result from session state; closing the tab ends the session. Input widgets may retain their current values until cleared or closed.

## 2. Start the backend

```powershell
.venv\Scripts\python scripts/init_env.py
.venv\Scripts\python -m uvicorn mailmind.api:app --host 127.0.0.1 --port 8000 --no-access-log
```

`init_env.py` creates an ignored `.env` containing a random local pairing token. Never put this token, Google access tokens, or model keys in source code. The public health endpoint is `http://127.0.0.1:8000/health`. Analysis requires `X-MailMind-Token`. No database is used.

## 3. Load the Chrome extension

The delivered `extension/dist` is already built and loadable in demo mode. To rebuild:

```powershell
cd extension
npm ci
npm run build
```

Open `chrome://extensions`, enable Developer mode, choose **Load unpacked**, and select `extension/dist`. Copy its extension ID. Add `chrome-extension://THAT_ID` to the comma-separated `ALLOWED_ORIGINS` in `.env`, then restart FastAPI. Click the extension toolbar icon to open its side panel. Expand **Local connection & privacy**, paste the local `MAILMIND_TOKEN`, and click **Analyse email**. The token remains in panel memory only.

The panel shows a summary, task and event cards, exact evidence and ambiguity reasons. Edit or dismiss cards, then copy or export JSON. User edits are marked and retain the original extraction. The schema validates machine output; user-edited exports are review artifacts and may contain deliberately changed values. Dismissed items are omitted from exports. No exports are uploaded anywhere.

## 4. Enable model inference (optional for the baseline demo)

**Verified 4B candidate:** see [model comparison setup](docs/MODEL-COMPARISON.md). The current local installation uses Qwen3.5-4B Q4_K_M on port 8082. The older lightweight CPU setup below is retained for reproduction/comparison. Weight files and GPU runtimes are separate downloads, not included in the release ZIP.

Both supported providers are local-only. They classify existing sentence IDs; summaries and fields are extracted from those sentences. The model cannot emit arbitrary action text, and no tools are exposed to it.

**Ollama:** install Ollama separately, run `ollama pull qwen2.5:3b`, keep Ollama running, and set `MODEL_PROVIDER=ollama` and `OLLAMA_MODEL=qwen2.5:3b` in `.env`. This adapter has contract tests; see STATUS for live verification.

**CPU llama.cpp:** the project includes a version-pinned download helper for the lightweight Qwen2.5-0.5B-Instruct Q4_K_M model. It downloads third-party Windows x64 executables and weights into the directory you supply and records their checksums. Review licenses and URLs in the helper before redistribution.

```powershell
.venv\Scripts\python scripts/fetch_local_model.py --directory work/local-model
# Find llama-server.exe under work/local-model/runtime, then run it:
work\local-model\runtime\llama-server.exe -m work/local-model/model.gguf --host 127.0.0.1 --port 8081 -c 8192 -t 4 --log-disable
```

Set `MODEL_PROVIDER=llamacpp` in `.env` and restart FastAPI/Streamlit. If the extracted runtime has a subdirectory, use the actual executable path. The compact model is an initial CPU experiment; domain accuracy must be measured. Never expose the model port to the public network. Model processes may retain prompt/KV memory until terminated; MailMind does not persist it.

## 5. Connect Google

Follow [Google configuration](docs/GOOGLE.md). A Google OAuth client bound to your extension ID and consent/test-user configuration are required; no credentials are included. The extension uses Chrome Identity, and tokens go directly to Gmail, never the backend.

MailMind does not automatically identify the open Gmail conversation. Use explicit Gmail search and select a result, or supply an API message/thread ID. Search retrieves up to ten message headers. **Analyse** retrieves only the selected body or thread. Threads are limited to 30 messages; inline UTF-8 plain text/HTML is supported. Attachments, encrypted mail and non-UTF-8 bodies may require pasting decoded text.

## 6. Reproduce tests and evaluation

```powershell
.venv\Scripts\python -m pytest -q
.venv\Scripts\python evaluate.py --split test --approach both
cd extension
npm ci
npx playwright install chromium
# Use the virtualenv Python if it is not at the test harness's workspace default:
$env:MAILMIND_PYTHON = (Resolve-Path ../.venv/Scripts/python.exe).Path
npm test
```

To include the optional live-model browser check, start llama.cpp and set `MODEL_PROVIDER=llamacpp` and `TEST_LIVE_MODEL=1` in the test process environment before `npm test`.

The browser test launches an isolated headless Chromium profile, loads the actual MV3 extension and starts a real FastAPI process on port 8000. Stop an existing backend before running it. Model evaluation must have a local model running; unavailable inference is recorded as blocked and never replaced with baseline predictions. `evaluate.py` loads `.env` and emits per-case predictions for these fictional fixtures. Do not run it on private mail without agreeing to persist those artifacts.

Data: `data/dev.json` (12 cases), `data/test.json` (16 cases), immutable split hashes in `data/split_manifest.json`. Labels are authored, not derived from predictions. See [annotation guidance](data/ANNOTATION.md), [research report](docs/RESEARCH.md), [results](results/test_results.json), and [status](STATUS.md).

## Troubleshooting

| Symptom | Action |
|---|---|
| Pairing token incorrect | Use `MAILMIND_TOKEN` from the backend's `.env`; restart after changing it. |
| Origin forbidden / cannot reach backend | Add the exact extension origin to `ALLOWED_ORIGINS`; use 127.0.0.1:8000; restart backend. Do not use `*`. |
| Model unavailable | Start the configured local runtime and model; check `MODEL_PROVIDER`; baseline remains available. |
| Date remains unresolved | Supply trusted timestamp/timezone for relative dates. Numeric dates and weekdays deliberately require review. |
| Google setup incomplete | Build with your own `extension/config.local.json`, reload the extension, follow GOOGLE.md. |
| Gmail access denied | Confirm Gmail API is enabled, read-only scope granted, correct Chrome profile and consent test user. |
| npm cache permission error | Set `npm ci --cache <a writable local directory>`. |
| Old tasks remain in summary | Review thread evidence: extractive summaries may include obsolete requests. Paraphrased state changes are a known limitation. |

See [architecture](docs/ARCHITECTURE.md), [privacy/threat model](docs/PRIVACY.md), and [demonstration script](docs/DEMO.md). This prototype does not send email, process an inbox in the background, or create Google Tasks/Calendar entries.
