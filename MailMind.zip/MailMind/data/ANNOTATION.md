# Fictional dataset and annotation protocol

This file describes the original seed benchmark. The 8 October expansion has its own explicit compound/contextual annotation conventions in [evaluation_v2/ANNOTATION.md](evaluation_v2/ANNOTATION.md): 24 development cases and 12 reserved, unrun cases. Keep results separate rather than pooling incompatible annotation versions.

All names and messages are invented. Development: 12 cases. Held-out fixture set: 16 cases, distinct messages and names, with deliberate hard cases. These labels were authored by the implementation assistant, without independent human annotation or agreement measurement. They are **held-out execution fixtures**, not a blinded external benchmark: the same author designed the system and both splits. Shared templates and tiny sample size can inflate scores. Freeze split hashes before reporting results; do not tune to test errors. A later revision requires a fresh external test set.

## Annotation unit

Read the complete ordered thread. Annotate each actionable clause, including explicit commitments, requests and sufficiently clear indirect requests. A meeting announcement is an event, not a task to attend. Scheduling/booking a meeting is a task. Informational statements and quoted older content are not new requests. Split coordinated clauses when they identify distinct work.

For each task record: the exact action/statement span in `quote`, canonical `message_id`, explicitly named owner or null, exact deadline wording (excluding “by”/“before”), normalized ISO date or null, and final status after reading the thread. Preserve historical requests with cancelled/superseded status. Explicit cancellation instructions can themselves be represented as cancelled task records; do not count them as active work. Use pending unless cancellation, completion or supersession is supported. Pronouns remain null in this conservative annotation policy; a future coreference track may label them separately.

Use an offset-aware timestamp plus confirmed IANA timezone for “today/tomorrow.” Do not choose US/UK ordering for numeric dates, infer a year, assume a timezone for an event, or assign a deadline to every conjunct. Dates with explicit ISO year/month/day are independently resolvable. For compound cases, the trailing deadline is attached only to its local action and scope is marked for review.

Evidence must be verbatim from canonical decoded body text. HTML is converted to visible text; scripts/styles are removed; markup is not evidence. Plain-text line endings are normalized. No case folding, fuzzy evidence matching or invented ellipses. Gold `quote` identifies an action span for exact alignment; a predicted evidence sentence may be longer than that span. Multiple evidence messages may support a final status.

Events in this seed set are annotated with detection spans. Event field accuracy is not measured by the current benchmark. Summary facts are short exact gold spans covering key information, with latest thread state preferred. Not every case has summary annotations; the evaluator reports that denominator. A summary quoting a source can still mislead through omission or obsolete context.

## Independent annotation expansion

Use two trained annotators, blind to model outputs, on a shared pilot. Adjudicate disagreements with a third reviewer. Measure task-span agreement (exact and relaxed boundary F1), owner/deadline agreement and status agreement separately. Revise guidelines using development data only. Keep test labels hidden until model/prompt configuration is frozen. Report agreement, inclusion criteria, split construction and every exclusion.
