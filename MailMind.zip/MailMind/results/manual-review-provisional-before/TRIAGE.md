# Provisional human-review reproduction and improvement plan

Date: 2026-10-08. No production pipeline, schema, prompt, or UI changes made during this investigation.

## Provenance and execution

These are the user's screenshot reconstructions, not recovered original emails. Case 16 omits Rahul's request and the project-objective statement; case 20 omits the original beginning/greeting. Cases 17–19 have reconstructed openings. No missing content was supplied by the developer. All messages are plain text with null sender timestamp and timezone. The exact supplied reproduction bodies and limitations are in inputs.json. results.json contains ten actual outputs, model identity, latency, token usage, source hashes and input hash. The configured local Qwen3.5-4B-Q4_K_M model ran successfully; no remote provider or fallback was used. Exact source-evidence validation passed in all ten analyses. This does not establish semantic correctness.

These cases are now development/regression inputs. They must not be described as independent held-out tests, and their outputs must not overwrite the previous reserved evaluation or be combined with the user's original pass counts. One run per method was performed; model repeatability across runs was not measured.

## Observations from actual JSON

| Case | Rules tasks/events | AI tasks/events | Finding |
|---|---|---|---|
| 16 | 2 / 1 | 2 / 1 | Priya's instruction split; first action loses deadline. Raw deadline captures only Thursday, event date only Monday. Missing Rahul/objective lines cannot be evaluated. |
| 17 | 0 / 0 | 0 / 0 | No invented tasks/events. Rules summary includes courtesy; AI preserves connectivity verification. |
| 18 | 2 / 0 | 2 / 0 | Review/feedback split; only feedback gets deadline. Both omit UAT completion from summary; rules retain deployment condition, AI omits it. No structured dependency. |
| 19 | 0 / 2 | 0 / 3 | Original and updated schedule emitted as separate announced events. AI adds undated rescheduling announcement. Neither output has one logical rescheduled event. |
| 20 | 2 / 1 | 3 / 1 | Rules miss shared arrival; AI detects it but cannot link date or owners. Both correctly avoid pending task for completed slides. |

Case 20's AI summary DOES include arrival in this run, unlike the earlier screenshot report; it omits the workshop announcement and slide completion. Reconstruction differences and model execution differences preclude attributing this discrepancy to a specific cause. The incomplete-warning reported for case 16 did not appear on this shortened input.

Null years for October 15/19 etc. without a year/context and null resolved timezone for ambiguous IST are conservative behavior, not normalization failures. However, truncating `Thursday, October 15` to `Thursday` is a separate loss of useful raw wording. The exact source evidence still contains the complete date.

## Root causes and targeted plan

1. **Event lifecycle first.** `mailmind/pipeline.py:materialize` creates one event per selected sentence. `mailmind/context.py:event_schedule` recognizes single-sentence moved/rescheduled/postponed-to patterns, but does not join original/updated schedule sentences. `mailmind/schema.py:Event` has no rescheduled status or structured schedule history. Add conservative event reconciliation only where identity and explicit original/update relationships are supported. Keep current fields for compatibility, add original schedule/evidence and rescheduled status, retain raw timezone separately. Show status in `demo.py` and inspect extension consumers before changing schema. Do not merge unrelated meetings merely because they share a message or date.
   - Acceptance: provisional case 19 becomes one rescheduled event, current October 16, 2026 3:30 PM, previous October 15 11:00 AM, raw IST retained, resolved timezone null. No undated duplicate announcement. Test unrelated meetings, multiple possible referents, cancellation after reschedule, missing destination, single-sentence rescheduling and multi-message chronology. Unresolved identity must produce review, not a guessed merge.
2. **Compound requests and raw dates.** `context.py:task_chunks` splits at known verbs after `and`; its grouping exception covers only delivery pronouns such as share it/them. It does not cover review-and-feedback or review-and-update instructions. `pipeline.py:materialize` then assigns dates separately per chunk. Inspect `dates.py:date_text/deadline_text` matching order so a weekday does not discard an adjacent calendar date. Use a documented grouping policy with review flags where shared scope is uncertain, not universal merging of conjunctions.
   - Acceptance: cases 16/18 retain both requested activities and shared deadline wording; separate owners, separate deadlines and independent deliverables remain distinct. No year invented for case 16. Case 18 retains explicit 2026-10-14.
3. **Summary coverage and dependencies.** Rules frequency ranking in `pipeline.py:materialize` can prefer courtesy or historical background. `improved.py:Selection/SYSTEM` allows up to three selected sentences; no sentence rewriting occurs. `schema.py:Analysis.summary` requires evidence spans and caps them at three. This limits coverage when more than three sentences contain required facts. First define separate factuality/coverage/conciseness annotations; then add evidence-backed coverage handling and structured conditional relationships. A concise generated summary is a separate schema/prompt feature and must retain supporting evidence rather than weakening exact quote validation.
   - Acceptance: case 18 includes completed UAT status, review/feedback deadline and deployment conditional on confirmation. Case 19 prioritizes new schedule and unchanged link/agenda context. Case 20 covers preparation, event, arrival and completed slides without creating new pending work. Negative tests must prevent unconditional deployment and invented dates.
4. **Arrival/context resolution.** `pipeline.py:VERBS/is_rule_task` does not recognize reach/arrive requests. `context.py:contextualize` handles only a narrow both-of-you early-attendance pattern with a two-person greeting. Task schema exposes calendar date but no dedicated clock/inference provenance field. Extend arrival handling with an explicit link to a unique event, and expose derived/contextual values with evidence and review reasons. Do not turn three names mentioned in a body into confirmed recipients when the greeting is missing.
   - Acceptance: case 20 retains 9:00 AM, links workshop day to October 22 with disclosed contextual inference, leaves timezone unresolved, and does not assert the three owners as confirmed. Separately authored synthetic greeting-present/ambiguous-greeting cases can test owner resolution; never insert that greeting into this fixture.

## Verification sequence

Preserve this before-run directory unchanged. Implement lifecycle changes first, adding schema/negative regression checks and updating all consumers. Run relevant tests and the existing suite. Rerun both methods on these same five inputs into a NEW directory; inspect JSON and visible UI. Record semantic before/after comparisons rather than calling every exact-span difference an error. Continue to compound requests, dates and summaries in separately reviewable changes. Record which outputs are automated, manually inspected, or unverified. Do not report all 20 cases fixed based on these five incomplete reconstructions.

No calendar-writing feature exists in this application currently. Future calendar integration must require confirmation and honor lifecycle/uncertainty; this investigation did not exercise calendar creation or updates.

## Remaining source gaps

The full case-16 input is needed only to reproduce the Rahul/objective observations. Case-20 greeting is needed to verify original recipient interpretation. Historical exported JSON would allow direct comparison with the earlier execution; it is not required to begin fixes against these explicitly provisional inputs.

Reproduction command (choose an unused output directory):

```powershell
../../work/.venv/Scripts/python.exe scripts/reproduce_manual_review.py --output results/manual-review-provisional-new-run
```
