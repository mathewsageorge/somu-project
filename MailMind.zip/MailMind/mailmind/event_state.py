"""Conservative same-message reconciliation of explicit meeting schedule updates.

This is a rule, not model coreference. Only an adjacent announcement/original/
updated sequence with generic 'the meeting' references is linked. Other selected
events in the message prevent linking. No facts or omitted model events are added.
"""
import re
from .schema import EventSchedule, Evidence
from .text import sentences, suspicious

INTRO = re.compile(r'^(?:Due to [^,.!?]+, )?we (?:need to|must|will) reschedule (?:our|the) [\w -]*meeting\.$', re.I)
OLD = re.compile(r'^The meeting was originally (?:planned|scheduled) for\b', re.I)
NEW = re.compile(r'^The updated meeting schedule is\b', re.I)


def reconcile_events(events, sources, ambiguities):
    for mid, source in sources.items():
        rows = sentences(source)
        local = [e for e in events if e.evidence[0].message_id == mid]
        for index in range(1, len(rows) - 1):
            intro, old, new = rows[index - 1:index + 2]
            if not (INTRO.search(intro) and OLD.search(old) and NEW.search(new)):
                continue
            if any(suspicious(s) for s in (intro, old, new)):
                continue
            previous = [e for e in local if e.description == old]
            updated = [e for e in local if e.description == new]
            if len(previous) != 1 or len(updated) != 1:
                continue
            prior, current = previous[0], updated[0]
            outsiders = [e for e in local if e.description not in (intro, old, new)]
            if outsiders or not current.date or not current.time_text or any(
                    e.status != 'announced' for e in (prior, current)):
                prior.status = current.status = 'needs_review'
                ambiguities.append(f'{mid}: Meeting schedule update needs review: event identity or destination is unresolved; records were not merged.')
                continue
            current.original_schedule = EventSchedule(**{key: getattr(prior, key)
                for key in EventSchedule.model_fields})
            current.status = 'rescheduled'
            current.evidence = [Evidence(message_id=mid, quote=s) for s in (intro, old, new)]
            events[:] = [e for e in events if e is current or not (
                e.evidence[0].message_id == mid and e.description in (intro, old))]
            ambiguities.append(f'{mid}: Rescheduled meeting: linked adjacent original and updated schedules. Only the updated schedule is current; review the contextual event link before use.')
            break
