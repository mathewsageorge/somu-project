"""Report transparent logical-action development scores from saved predictions only."""
import json, statistics
from pathlib import Path

root=Path(__file__).resolve().parents[1]
policy=json.loads((root/'data/submission-scoring-policy.json').read_text())
old=json.loads((root/'results/case22-development-final/results.json').read_text())
before=json.loads((root/'results/submission-before/results.json').read_text())
after=json.loads((root/'results/submission-final-development/results.json').read_text())
rows=[r for r in old['runs'] if r['method'] in ('baseline','improved','structured_legacy')]
rows += [{**r,'method':'structured_before'} for r in before['runs']]
rows += [{**r,'method':'structured_final'} for r in after['runs']]
metrics={};cases=[]
for method in dict.fromkeys(r['method'] for r in rows):
 selected=[r for r in rows if r['method']==method]
 total=dict(tp=0,fp=0,fn=0,owner_correct=0,owner_matched=0,known_owner_correct=0,known_owner_matched=0,explicit_deadline_correct=0,explicit_deadlines=0,deadline_with_null_correct=0,matched=0,event_count_agreement=0,valid_outputs=0,outputs=len(selected))
 for r in selected:
  gold=policy['cases'][r['case_id']];out=r.get('output',{});used=set();field=[]
  for task in out.get('tasks',[]):
   match=next((i for i,t in enumerate(gold['tasks']) if i not in used and (task['action'].startswith(t['anchor']) or (len(task['action'].rstrip('.!?'))>=8 and task['action'].rstrip('.!?') in t['quote']))),None)
   if match is None:total['fp']+=1;continue
   used.add(match);g=gold['tasks'][match];owners=task.get('owners') or ([task['owner']] if task.get('owner') else [])
   correct=set(owners)==set(g['owners']);total['owner_correct']+=correct;total['owner_matched']+=1
   if g['owners']:total['known_owner_correct']+=correct;total['known_owner_matched']+=1
   if g['deadline'] is not None:total['explicit_deadline_correct']+=task.get('deadline')==g['deadline'];total['explicit_deadlines']+=1
   total['deadline_with_null_correct']+=task.get('deadline')==g['deadline'];total['matched']+=1
   field.append({'anchor':g['anchor'],'owner_correct':correct,'deadline_correct':task.get('deadline')==g['deadline']})
  total['tp']+=len(used);total['fn']+=len(gold['tasks'])-len(used)
  total['event_count_agreement']+=len(out.get('events',[]))==gold['event_count']
  total['valid_outputs']+=bool(r.get('evidence_valid'))
  cases.append({'id':r['case_id'],'method':method,'tasks':len(out.get('tasks',[])),'events':len(out.get('events',[])),'matched_fields':field,'latency_ms':out.get('latency_ms'),'error_type':r.get('error_type')})
 p=total['tp']/(total['tp']+total['fp']) if total['tp']+total['fp'] else 0
 rec=total['tp']/(total['tp']+total['fn']) if total['tp']+total['fn'] else 0
 total.update(precision=p,recall=rec,f1=2*p*rec/(p+rec) if p+rec else 0)
 metrics[method]=total
timing=json.loads((root/'results/submission-final-timing/results.json').read_text())
performance={}
for method in timing['config']['methods']:
 runs=[r for r in timing['runs'] if r['method']==method and 'output' in r]
 vals=[r['end_to_end_ms']/1000 for r in runs]
 performance[method]={'n':len(vals),'median_seconds':statistics.median(vals),'min_seconds':min(vals),'max_seconds':max(vals),'input_tokens':[r['output']['input_tokens'] for r in runs],'output_tokens':[r['output']['output_tokens'] for r in runs],'generation_ms':[r['output'].get('model_generation_ms') or r['model_calls'][0].get('server_timings',{}).get('predicted_ms') for r in runs],'peaks':{k:max(r['resources']['peaks'].get(k,0) for r in runs) for k in ['gpu_memory_used_mib','system_ram_used_mib']}}
result={'scope':policy['scope'],'metrics':metrics,'cases':cases,'performance':performance}
(root/'results/SUBMISSION-METRICS.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'metrics':metrics,'performance':performance},indent=2))
