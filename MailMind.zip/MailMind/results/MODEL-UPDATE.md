# Model instructions update — 7 October 2026

The pretrained model weights are unchanged. We added task/event examples to its instructions and an explicit **none** label for sentences that contain neither. Deterministic field extraction, evidence validation and the rule-only baseline remain unchanged. This is prompt/schema engineering, not model training.

## New diagnostic comparison

12 new fictional cases were frozen before their first inference run. They contain six gold tasks and four gold events. They were not supplied in the model prompt or used to revise it after evaluation. They are authored by the same implementation assistant, so they are not an independent blinded benchmark. Existing October 6 research results remain historical.

| Method | Tasks found | Extra tasks | Task F1 | Events found | Extra events | Event F1 | Mean ms |
|---|---:|---:|---:|---:|---:|---:|---:|
| rules | 3/6 | 0 | 0.667 | 4/4 | 1 | 0.889 | 0.2 |
| original_model | 6/6 | 8 | 0.600 | 1/4 | 0 | 0.400 | 1072.1 |
| revised_model | 6/6 | 2 | 0.857 | 4/4 | 0 | 1.000 | 870.0 |

## Remaining revised-model errors

- new-07: false task — The workshop materials were uploaded yesterday.
- new-09: deadline wording 'processing can begin' vs gold None; normalized date remains null.
- new-12: false task — All issues have been resolved.

## Development decisions and limitations

The original 12 development cases were used to compare two revisions. Examples alone (candidate v2) improved meeting recall but created five false events. Adding an explicit none label (v3) reduced this to one false event on development. V3 was chosen using the mean of task and event F1 across development results. It still reduced task recall on development from 12/12 to 10/12 and worsened state tracking for cancellations/updates. It must remain experimental; rules remain the application default.

Development artifacts: prompt-development-v2.json and prompt-development-v3.json record exploratory runs. In the exploratory v3 run, the original prompt was also given the three-label schema. prompt-development-final-v3.json reruns the comparison with the original prompt’s original two-label schema. event-challenge-v3.json likewise uses the original two-label schema for the original-model comparison. The revision bundles prompt examples and a schema change; the experiment does not isolate their independent effects.

The challenge manifest records the initial source freeze and the final evaluated source hash, updated before any challenge inference. No challenge-driven prompt revision was made. Final prompts and hashes, allowed labels, per-case predictions, token counts and latency are saved. Small synthetic cases, same-author labels, prompt caching and one sequential run limit conclusions. Evidence matching is still not semantic validation; human summary factuality has not been evaluated.

## What the student should test

In the demo choose **AI model + rule checks (experimental)** and analyse the Asha/Ravi tutorial email. Expected: two tasks and the team meeting under Events. Then use a different invented email and write the correct answer yourself before running either method. Record misses and extra items rather than assuming the model is correct. A larger, independently labelled evaluation remains the next research stage.
