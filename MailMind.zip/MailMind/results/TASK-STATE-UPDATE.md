# Cancellation and completion tracking — 8 October 2026

This iteration addresses the development failures recorded in `evaluation-v2-development/results.json`. The same 24 development inputs and frozen draft labels were reused. **This is development tuning, not unseen evaluation.** The 12 reserved cases were not read for tuning or run. No weights were trained or replaced.

## Implementation

- The model prompt distinguishes an explicit cancellation directive from a standalone no-action notice and includes illustrative cancellation/completion pairs. A completion notice remains informational; it is not a new pending task.
- `mailmind/task_state.py` scans later unquoted, non-suspicious source sentences independently of model selection. It applies narrow affirmative completion and explicit cancellation patterns only to existing matching task records. This is a rule component, not learned inference or a silent baseline replacement.
- Matching requires the same supported action verb and object. Named updates must match the existing owner. Ownerless updates must have a unique matching target. Multiple possible targets are marked `needs_review`; different named owners are not merged. Unsupported verbs do not match merely because neither has a known action key.
- Future promises, negated completion, questions, conditional wording, quoted updates and different objects do not count as completion in the tested counterexamples. Passive paraphrases, pronouns, broader semantic equivalence and authority of a sender are not established by these rules.
- Full timestamps determine message order where available; otherwise supplied thread order is used. Source order, rather than model output-list order, determines task ordering. Superseded records stay superseded when their replacement is later cancelled. New requests after completion remain pending.
- Updated tasks retain exact original and update evidence. Summaries prioritise evidenced status changes over obsolete requests, with a review note. This does not prove full summary factuality or coverage.

## Actual before/after development results

| Method/version | Task TP / FP / FN | Task F1 | Correct status among matched tasks |
|---|---|---|---|
| Rules, before | 20 / 0 / 2 | 0.952 | 19 / 20 |
| Rules, after | 20 / 0 / 2 | 0.952 | 20 / 20 |
| AI + rules, before | 21 / 0 / 1 | 0.977 | 19 / 21 |
| AI + rules, after | 22 / 0 / 0 | 1.000 | 22 / 22 |

The matched-task denominator changes when detection changes; status percentages alone are not an end-to-end measure. Both methods detected all four labelled events. Before results are in `evaluation-v2-development`; final after results, per-case predictions, source hashes and code snapshot are in `evaluation-v2-task-state-final`. The first implementation run is retained in `evaluation-v2-task-state`; the final run adds guards against unknown-verb merging and cancellation questions. Both final approaches returned valid exact evidence; human summary factuality remains unmeasured.

The final AI run averaged 1781.6 ms per case; rules averaged 1.5 ms. This is one local run with cache/hardware effects, not a controlled performance benchmark. Local hardware/electricity costs are unmeasured; no paid API cost is invented.

## Checks and remaining limitations

All **99 Python tests passed** (`python-tests-task-state.xml`), including 20 added lifecycle regression/counterexample checks. One existing Starlette/httpx test-client deprecation warning remains. Automated software tests and a tuned fictional dataset do not establish real-world reliability. Rules still missed the reconcile request and the indirect approval request. The model's perfect span/field scores on these 24 familiar cases must not be described as 100% email understanding.

The restarted Streamlit demo was exercised through the live browser using the AI method: `v2-dev-20` displayed two cancelled records and a cancellation summary (2519.68 ms); `v2-dev-21` displayed one completed task, a completion summary and both message IDs in evidence (2541.7 ms). Evidence: `task-state-browser.json` and `task-state-browser.png`. This was agent-driven verification, not a human usability study.

An AI no-action label can still omit a cancellation record. The separate status rule can update an existing matching request in that situation, while the original model/rule disagreement warning remains visible. If no prior task was selected, the rule creates no replacement task. Unsupported references or ambiguous updates still require review.

## Try the change

In the demo choose **Example thread**, then **v2-dev-20** and **AI model + rule checks**, and click **Analyse**. The original printed-ledger request and cancellation record should both be cancelled, with the cancellation in the summary. Then analyse **v2-dev-21**: Jules's earlier delivery-list request should be completed, with the later completion sentence as supporting evidence and summary. Historical cancelled/completed cards are intentionally retained; they are not pending work.
