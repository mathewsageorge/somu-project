"""Inspect labels on the explicitly saved development regression, never live mail."""
import json
import os
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import mailmind.improved as module
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message
from mailmind.text import sentences

if __name__ == '__main__':
    os.environ.update(MODEL_PROVIDER='llamacpp', LLAMACPP_URL='http://127.0.0.1:8082', LLAMACPP_MODEL='Qwen3.5-4B-Q4_K_M')
    source = (ROOT/'data/regression_project_review.txt').read_text(encoding='utf-8')
    rows = sentences(source)
    captured = {}
    original_post = module.httpx.Client.post
    def recording_post(self, *args, **kwargs):
        response = original_post(self, *args, **kwargs)
        response.raise_for_status()
        captured.update(json.loads(response.json()['choices'][0]['message']['content']))
        return response
    module.httpx.Client.post = recording_post
    try:
        result = analyse(AnalysisRequest(messages=[Message(id='pasted-1',body=source)], approach='improved'))
    finally:
        module.httpx.Client.post = original_post
    report = {'note':'Explicit development-regression capture, not general application logging.',
              'sentences': rows, 'model_selection': captured, 'analysis': result.model_dump(mode='json')}
    (ROOT/'results/project-review-qwen35-labels.json').write_text(json.dumps(report, indent=2),encoding='utf-8')
    print(json.dumps(captured, indent=2))
    print(json.dumps({'sentence_count':len(rows),'review_notes':result.ambiguities}, indent=2))
