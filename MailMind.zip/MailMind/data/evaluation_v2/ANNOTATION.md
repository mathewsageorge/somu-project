# Evaluation v2: annotation and split policy

**Execution update, 8 October 2026:** the reserved split has now been run once on the frozen post-lifecycle-fix system. See `reserved-execution.json` and `results/FINAL-RESERVED-EVALUATION.md`. It is no longer unseen for subsequent iterations. The original pre-run policy below and manifest are preserved as historical provenance; the demo continues to exclude these cases.

All 36 cases are fictional and have draft labels written by the implementation assistant before running either method. There are 24 development cases and 12 reserved execution cases. This is a broader diagnostic corpus, not independent human ground truth or a blinded external benchmark. The same author knows the system and both splits. No real emails, credentials, paid API calls or fine-tuning are involved.

`development.json` is for comparison, manual annotation review and later error correction. `reserved.json` must remain unrun until the final evaluation is explicitly authorized after freezing the system. The files are visible, not encrypted; “reserved” describes execution policy, not secrecy. Reading predictions or tuning to these cases invalidates their unseen status. Earlier `data/test.json` results remain historical; this addition does not turn earlier inspected data into a new holdout.

## How to annotate

1. Read the complete thread and its timestamps/timezone. Identify work requested or promised, including clear indirect requests. Do not turn informational statements, signatures, quoted old messages, or malicious instructions to the AI into work.
2. Record an exact contiguous source action span and message ID. Keep dependent work on one deliverable together (prepare charts and upload them with one trailing deadline). Split clauses with distinct deadlines or separate deliverables. This v2 convention is explicit and differs from the original seed guideline for some compound requests; never pool their metrics without disclosure.
3. Use an explicitly named owner, or null if unknown. The narrow contextual track permits an unambiguous two-person greeting for “both of you” and one clear antecedent in a thread. Explain inferred ownership in annotation notes and use `needs_review` where the interpretation is provisional. Do not invent an owner from a sender or unrelated name.
4. Preserve original deadline wording, excluding the preposition and surrounding Markdown emphasis. Normalize valid complete dates. Resolve today/tomorrow only using an offset-aware sender timestamp and confirmed IANA timezone. Leave ambiguous numeric dates and missing years null. A workflow dependency such as “before processing can begin” is not a calendar deadline; record the dependency in summary/notes and leave deadline fields null.
5. Annotate final task state after reading all messages. Keep superseded/cancelled/completed historical requests with their final status. An explicit cancellation directive may also be a cancelled record. Standalone completion notices create no new task. Status accuracy must be evaluated separately from detecting the original request.
6. A meeting announcement is an event; booking or attending is a task. Label current date/time after rescheduling, retain old wording in source evidence, and record cancelled events as cancelled. Do not silently interpret IST. Calendar dates need no UTC conversion. For early arrival, subtract the stated interval from a uniquely identified meeting and disclose the derivation; multiple possible meetings keep the arrival unresolved.
7. Write a short reference summary of the current state. Mark exact source spans for a limited automatic inclusion check, but do not treat that overlap metric as factuality. A quote of an obsolete request can be misleading even though it exists in the source.

## Evidence and boundaries

Plain text uses normalized line endings. HTML evidence is decoded visible text, not markup. Gold action spans can be smaller than their supporting sentence. Contextual fields may be supported elsewhere in the same thread; the production result must retain that evidence if it uses them. Exact action-span scoring penalizes valid segmentation variants. Record and adjudicate those separately, without silently changing labels to match a model.

Every case includes `reference_summary`, scenario tags, and annotation notes where needed. Event annotations add date wording, normalized date, clock, timezone and status, which the earlier seed benchmark did not score. Tests validate structure, exact spans, frozen hashes, and split separation; those tests do not prove semantic annotation correctness.

## Review procedure

Have two people independently review a development pilot before comparing outputs. Resolve disagreements and record reasons in a new dataset version; preserve the original manifest/results. Report exact/relaxed task-span agreement, owner/date/status agreement, and adjudication counts. No agreement statistic is available yet.

For `human-review.csv`, keep `review-method-key.json` away from raters. Split each displayed summary into factual claims, count supported/contradicted/unsupported claims against the whole thread, count covered versus total key obligations/events, and mark whether the latest state is clear. Count a claim using an unresolved interpretation as unsupported unless the summary explicitly states uncertainty. Leave fields blank until a person actually rates them. Each reviewer should use a separate worksheet copy; measure agreement before adjudication.

## Reproducibility

`manifest.json` freezes labels and case counts before inference. The runner refuses changed hashes, overwrites, and a reserved run without an explicit release flag. It records per-case predictions, actual latency/token usage, source hashes, and a source snapshot. Run from the MailMind folder:

```powershell
python scripts/evaluate_v2.py --output results/evaluation-v2-development
```

This uses the configured local model. If unavailable, improved results are marked blocked rather than replaced by baseline predictions. Evaluation deliberately saves these fictional inputs/results. Normal application analysis still has no raw-email persistence by default.
