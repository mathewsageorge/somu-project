"""New authored challenge examples, excluded from prompt examples and development.
Not a blinded benchmark: the implementation author also authored these labels.
"""
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
CASES=[
    ('new-01',['The architecture review meeting is on 2027-03-08 at 11 am UTC.'],[],[0]),
    ('new-02',['Our customer workshop on 2027-03-09 at 3 pm UTC is cancelled.'],[],[0]),
    ('new-03',['Elena, please book the room by 2027-03-05.'],[(0,'Elena','2027-03-05')],[]),
    ('new-04',['Could you arrange transport for the conference?'],[(0,None,None)],[]),
    ('new-05',['Please attend the onboarding meeting on 2027-03-10.'],[(0,None,None)],[]),
    ('new-06',['The receipt is attached.','You do not need to reply.'],[],[]),
    ('new-07',['The workshop materials were uploaded yesterday.'],[],[]),
    ('new-08',['Felix, please share the agenda by 2027-03-11.','The committee meeting is on 2027-03-12 at 9 am UTC.'],[(0,'Felix','2027-03-11')],[1]),
    ('new-09',['Your approval of the purchase order is required before processing can begin.'],[(0,None,None)],[]),
    ('new-10',['The interview is on 2027-03-15 at 14:30.'],[],[0]),
    ('new-11',['Please schedule a call with the supplier by 2027-03-16.'],[(0,None,'2027-03-16')],[]),
    ('new-12',['All issues have been resolved.','No further action is required.'],[],[]),
]

if __name__=='__main__':
    target=ROOT/'data/event_challenge_v2.json'
    if target.exists():raise SystemExit('Frozen challenge already exists; refusing to overwrite.')
    rows=[]
    for id,sentences,tasks,events in CASES:
        rows.append({'id':id,'messages':[{'id':'m1','body':'\n'.join(sentences)}],
                     'gold':{'tasks':[{'message_id':'m1','quote':sentences[i],'owner':owner,'deadline_text':deadline,'deadline':deadline,'status':'pending'} for i,owner,deadline in tasks],
                             'events':[{'message_id':'m1','quote':sentences[i]} for i in events],
                             'summary_facts':sentences},
                     'tags':['new-task-event-challenge']})
    target.write_text(json.dumps(rows,indent=2),encoding='utf-8')
    manifest={'created_utc':datetime.now(timezone.utc).isoformat(),'cases':len(rows),
              'dataset_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
              'frozen_model_source_sha256':hashlib.sha256((ROOT/'mailmind/improved.py').read_bytes()).hexdigest(),
              'limitations':'Authored after prompt freeze, not supplied as examples or used for tuning. Same author as implementation; small synthetic diagnostic set, not independently blinded.'}
    (ROOT/'data/event_challenge_v2.manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Froze 12 new diagnostic cases before inference.')
