# Recorded experiments

Run: 2026-10-06T15:47:13.274221+00:00. Split: test, 16 fictional cases.

| Method | Task P | Task R | Task F1 | TP / FP / FN | Event F1 | Mean latency |
|---|---:|---:|---:|---|---:|---:|
| baseline | 1.000 | 0.875 | 0.933 | 14 / 0 / 2 | 1.000 | 1.61 ms |
| improved | 0.762 | 1.000 | 0.865 | 16 / 5 / 0 | 0.000 | 1643.37 ms |

## Field and evidence results

| Method | Matched tasks | Owner accuracy | Original deadline accuracy | Normalized date accuracy | Status accuracy | Exact evidence | Summary key-span coverage |
|---|---:|---:|---:|---:|---:|---|---|
| baseline | 14 | 1.000 | 1.000 | 1.000 | 0.929 | 39/39 | 13/13 |
| improved | 16 | 1.000 | 1.000 | 1.000 | 0.938 | 45/45 | 13/13 |

Non-null owner and deadline precision/recall/F1, with unmatched tasks included, are recorded separately in test_results.json. Both methods share these extraction rules; perfect values on these sparse fixtures do not establish robust entity/date understanding.

Human summary factuality: **not measured**. Exact evidence means text is present, not that its interpretation is correct. Key-span coverage is easy on these very short messages and includes only the 13 annotated spans. No calibrated confidence values are reported.

## Error inventory

### baseline

- test-11: missed task — Could you arrange transport for the visitors?
- test-12: missed task — Your signature is required on the attached agreement.
- test-16: status pending vs gold cancelled — Nora, please share the agenda by tomorrow.

### improved

- test-02: extra task — The office will close for maintenance.
- test-02: extra task — This message is for information only.
- test-04: extra task — The workshop is on 2026-10-20 at 14:00.
- test-04: missed event — The workshop is on 2026-10-20 at 14:00.
- test-07: extra task — No further action is necessary.
- test-15: extra task — The meeting on 2026-10-21 at 9 am UTC is cancelled.
- test-15: missed event — The meeting on 2026-10-21 at 9 am UTC is cancelled.
- test-16: status pending vs gold cancelled — Nora, please share the agenda by tomorrow.
- test-16: extra event — We no longer need that document.

## Interpretation and reproducibility

The small pretrained model improves recall but introduces false positives and confuses meeting announcements with tasks. The baseline remains the default. The proposed “improved” method is not empirically superior on this test. No test-driven prompt tuning was performed after this comparison. Date/owner rules and exact text provenance alone cannot correct wrong intent classification.

CPU runtime: llama.cpp b11443, four CPU threads, context 8192, temperature 0, seed 42; Qwen2.5-0.5B-Instruct Q4_K_M. Download URLs, pinned model revision and hashes are in model-manifest.json; prompt/source hashes are in test_results.json. Measured process working set was approximately 0.63 GB during the initial run. Latencies are one sequential run after development warm-up, with runtime prompt caching enabled; no cold-start or throughput claim. Local API billing is absent; electricity/hardware cost was not measured (null). Per-case token usage is retained.

An early development run rejected invalid repeated/out-of-range model IDs. Candidate-dependent schema bounds and strict post-validation were added before the final comparison. A transport schema-format experiment also failed validation; these integration/debug attempts are not research performance runs. Final results were regenerated after the HTML inline-text correctness fix, which did not change labelled fixture semantics. This is author-created testing, not a blinded benchmark.

The fictional sample is small and template-related. There are no independent annotations, statistical significance claims, calibrated uncertainty estimates, real-email claims or research-novelty claims. Follow docs/RESEARCH.md for the independent consent-based study required before deployment.
