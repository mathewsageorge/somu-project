import subprocess
from mailmind import resources


def test_actual_zero_gpu_activity_is_not_missing():
    gpu = resources._parse_gpu('NVIDIA GeForce RTX 3050 Laptop GPU, 2401, 4096, 0\n')
    assert gpu['utilization_percent'] == 0
    assert gpu['used_mib'] == 2401 and gpu['total_mib'] == 4096


def test_partial_driver_reading_preserves_known_memory():
    gpu = resources._parse_gpu('NVIDIA GPU, 2300, 4096, [N/A]')
    assert gpu['utilization_percent'] is None
    assert gpu['used_mib'] == 2300


def test_invalid_driver_readings_are_not_numbers():
    assert resources._parse_gpu('not a CSV measurement') is None
    gpu = resources._parse_gpu('GPU, NaN, 0, 1000')
    assert gpu['used_mib'] is None and gpu['utilization_percent'] is None


def test_no_driver_is_graceful(monkeypatch):
    monkeypatch.setattr(resources.shutil, 'which', lambda _: None)
    assert resources._gpu() is None


def test_gpu_command_is_bounded_read_only_and_has_no_shell(monkeypatch):
    monkeypatch.setattr(resources.shutil, 'which', lambda _: 'nvidia-smi')
    def run(args, **kwargs):
        assert '--id=0' in args and '--query-gpu=name,memory.used,memory.total,utilization.gpu' in args
        assert kwargs['timeout'] == 1.5 and not kwargs.get('shell', False)
        return subprocess.CompletedProcess(args, 0, 'GPU, 100, 4096, 20', '')
    monkeypatch.setattr(resources.subprocess, 'run', run)
    assert resources._gpu()['utilization_percent'] == 20


def test_driver_failure_is_unavailable(monkeypatch):
    monkeypatch.setattr(resources.shutil, 'which', lambda _: 'nvidia-smi')
    monkeypatch.setattr(resources.subprocess, 'run', lambda *a, **k: subprocess.CompletedProcess(a, 1, '', 'failure'))
    assert resources._gpu() is None


def test_telemetry_timeout_does_not_break_ram(monkeypatch):
    monkeypatch.setattr(resources, '_ram', lambda: {'used_mib': 100, 'total_mib': 200, 'percent': 50})
    def fail():
        raise subprocess.TimeoutExpired('nvidia-smi', 1.5)
    monkeypatch.setattr(resources, '_gpu', fail)
    result = resources.sample_resources()
    assert result['ram']['percent'] == 50 and result['gpu'] is None
    assert result['sampled_at'].endswith('+00:00')


def test_ram_failure_does_not_break_gpu(monkeypatch):
    def fail():
        raise OSError('unavailable')
    monkeypatch.setattr(resources, '_ram', fail)
    monkeypatch.setattr(resources, '_gpu', lambda: {'name': 'GPU'})
    result = resources.sample_resources()
    assert result['ram'] is None and result['gpu']['name'] == 'GPU'
