# Reference project review and targeted MailMind plan

Reviewed 11 October 2026. **Analysis first: no production code, model, prompt, dependency or architecture changes in this investigation.**

## Scope and provenance

Inspected MailMind's extraction, context, dates, task/event state, schema and evaluation code. Downloaded the two reference notebooks as JSON and read their code cells; did not execute notebooks, deserialize joblib files, train classifiers, or install their dependencies. Also inspected backend extraction and experimental summarization modules. Reference snapshot: `c05fc4ce50f268dcd4684489486fce8702f246db`. Downloaded source and SHA-256 manifest are outside the distributable app under `work/reference-rset`. The project's PDF reports and full application were not independently evaluated; report claims are not treated as reproduced results.

Sources at that snapshot:

- [Task extraction notebook](https://github.com/RSET-CSE-DEPARTMENT/RSET2022-26-S8-Beta/blob/c05fc4ce50f268dcd4684489486fce8702f246db/Group%2015%20Corporate%20Email%20Summarization%20and%20Task%20Extraction/Gp15_Project/taskml/task_extraction_final.ipynb)
- [Email classifier notebook](https://github.com/RSET-CSE-DEPARTMENT/RSET2022-26-S8-Beta/blob/c05fc4ce50f268dcd4684489486fce8702f246db/Group%2015%20Corporate%20Email%20Summarization%20and%20Task%20Extraction/Gp15_Project/classificationml/Email_Classifier.ipynb)
- [Experimental summarization code](https://github.com/RSET-CSE-DEPARTMENT/RSET2022-26-S8-Beta/tree/c05fc4ce50f268dcd4684489486fce8702f246db/Group%2015%20Corporate%20Email%20Summarization%20and%20Task%20Extraction/Gp15_Project/backend/app/ml/experiment)
- [Backend summarization route](https://github.com/RSET-CSE-DEPARTMENT/RSET2022-26-S8-Beta/blob/c05fc4ce50f268dcd4684489486fce8702f246db/Group%2015%20Corporate%20Email%20Summarization%20and%20Task%20Extraction/Gp15_Project/backend/app/routes/summarize.py)
- [spaCy linguistic features](https://spacy.io/usage/linguistic-features) and [English pipelines](https://spacy.io/models/en).

## Confirmed reproduction

Input: Aisha, please complete the UAT testing and share your observations by October 12, 2026.

Both current methods produce two tasks owned by Aisha: the testing action has no deadline; the observations action has 2026-10-12. Exact evidence remains the complete sentence. The live AI output reports Qwen3.5-4B-Q4_K_M and 11,187.27 ms; baseline 28.33 ms. These are single-run measurements, not comparative latency estimates; warm/cold state was not controlled. Evidence and source hashes: `results/reference-review-compound-before.json`.

The model path selects sentence IDs, not generated action text. `pipeline.materialize` calls shared `context.task_chunks`, which splits the selected sentence. Existing exceptions handle delivery pronouns, review-and-feedback and issue-review-and-tracking. Testing-and-observations falls outside them. Therefore this reproduced error is in shared post-processing, not evidence that Qwen needs replacement. Cases 16/18 were fixed narrowly, not for all compound requests.

## Root causes by component

| Concern | Current mechanism and limitation | Proposed response |
|---|---|---|
| Grouping / lost deadline scope | `context.task_chunks`; `pipeline.materialize` attaches a deadline only to its resulting clause | Represent coordinated actions and their owner/deadline scope before deciding how to display/group them; keep original spans |
| Missing secondary requirements | Sentence classification is independent; materialization has no parent-task/requirement link | Retain adjacent inclusion requirements only with a supported parent link; otherwise keep separate with review |
| Owners | `owner_span` recognizes a few explicit subject/address forms; `contextualize` supports one narrow two-person greeting pattern | Address/subject/object role analysis, not first-PERSON assignment; require evidence for collective references |
| Dates | `dates.py` intentionally leaves missing years and ambiguous zones unresolved; next Monday is recognized but not normalized | Define weekday convention, require email timestamp + confirmed timezone, disclose relative/contextual resolution; never borrow today's date |
| Arrival instructions | Narrow early-attendance rule; no dedicated structured task clock | Add optional time and derivation provenance fields, linked to a unique event; retain ambiguity when multiple events exist |
| Summary omissions | Baseline frequency ranking, model `summary_ids`, and a maximum of three source sentences | Coverage-oriented fact inventory before ranking; separate optional rewrite experiment using the existing Qwen runtime |
| Status/dependencies | `task_state` uses explicit verb/object matches; schema has no condition or prerequisite representation | Preserve conditional statements as relationships, not unconditional pending deployment tasks |
| Events | Narrow same-message reconciliation already added; not general thread coreference | Retain regression coverage and ambiguous-identity safeguards; do not deduplicate on text similarity alone |

NER supplies candidate names/dates; it does not establish who is responsible, resolve pronouns, or normalize a time zone. A dependency parser describes grammatical relationships, but it does not by itself prove that two activities form one deliverable. Both must complement semantic interpretation and explicit uncertainty.

## What the reference actually implements

The task notebook combines verb/cue rules, spaCy entities, and KeyBERT/YAKE keyphrase scores. `_find_verb_start` uses POS tags and lemmas. `split_multi_actions` splits at the first conjunction and checks verbs/content length; it is not a general dependency-graph grouping algorithm. `extract_tasks` assigns the same sentence-level assignee and deadline to every split action. This can preserve a shared deadline but risks misassigning distinct deadlines/owners. Action truncation at 20 words can lose secondary requirements. Its entry point accepts summary text, which can already have omitted requests; MailMind should continue extracting from original messages.

`pick_assignee` sensibly prefers direct address and checks some recipient verbs, but later first-PERSON, email-local-part and ORG fallbacks are too permissive for MailMind. Date handling defaults to the current time and Asia/Kolkata when context is absent. Priority and task-confidence scores are heuristic mixtures; urgency is not evidence that extraction is correct. Do not import these defaults or confidence numbers.

The classifier notebook is corporate/non-corporate classification, not task-sentence classification. Early labels are derived from the word Enron; later versions use dataset-origin labels. Such labels can learn corpus differences rather than corporate meaning. Earlier cells fit vectorizers after splitting, but the final saved-vectorizer path calls `fit_transform(X_final)` before `train_test_split`, exposing vocabulary/IDF statistics to the test distribution. Do not reuse its artifact or transfer its reported accuracy to task extraction.

The experimental TextRank code prioritizes mandatory sentences, then graph ranking. Static inspection found `scores[i]` accessed before `scores` is assigned in the ranking branch. It also parses sentences repeatedly inside pairwise similarity computation. Those are reasons not to copy the implementation. Its BART experiment uses `facebook/bart-large-cnn`, while the backend summary route loads a local T5 path: these are distinct code paths, not evidence of a single deployed TextRank+BART architecture. Its embedding grounding filter also keeps sentences based on critical keywords or falls back to the generated text; neither establishes factual entailment.

The task notebook's detection metric uses one-to-one token overlap with threshold 0.60. Its function called strict exact match allows token overlap 0.85 and a two-hour deadline tolerance, so it is not literal exact match. Field accuracy selects a best match without the detection threshold. Summary entity retention and word overlap can miss swapped owners, negation and outdated schedules. These are useful diagnostic ideas, not sufficient factuality measures or directly comparable scores.

## Adopt, experiment, defer

| Technique | Decision | Expected cost / benefit (not yet benchmarked) |
|---|---|---|
| Explicit address + verb/argument analysis | Adopt design, implement with source offsets | Better owner/deadline scope; no new large model |
| Small spaCy parser/NER | Optional CPU experiment in isolated environment | Adds model startup and RAM; measure locally, cache one pipeline, avoid GPU competition; parsing can still err |
| TF-IDF + logistic classifier | Do not reuse corporate classifier; defer new task classifier | Requires separately annotated task labels and leak-free splits; does not solve argument grouping |
| KeyBERT | Defer | Extra embedding inference/model storage; keyphrases are not action/owner relationships |
| TextRank | Optional extractive comparator after coverage fixes | Pairwise graph cost grows roughly quadratically in sentence count; cache sentence features |
| Structured facts then Qwen summary | Prioritize after extraction | Existing model retained; an extra generation pass increases latency/output tokens; validate claim/evidence relationships |
| BART / another large summarizer | Defer pending clear measured advantage | Additional weights/RAM/VRAM and hallucination surface; not justified now |
| Priority | Optional later, explicit reason labels | Start with source-marked urgency and user-selected as-of date; do not infer authority scores or confidence |

## Proposed implementation order and acceptance gates

1. **Freeze current baseline and annotate scope.** Preserve the supplied example plus varied fictional paraphrases, independent actions, different owners/deadlines, negation, completed work and inclusion requirements. Mark these development data. Obtain the exact user Test Case 21; do not confuse it with existing `v2-dev-21` (a completion thread). Document expected atomic activities, logical task groups and deadline scope before inspecting experimental outputs.
2. **Fix grouping/requirements without a new model first.** Introduce an internal clause representation retaining original offsets and relations. Keep combined source-span action for a supported shared deliverable; separate activities when owners/deadlines diverge. Link a secondary requirement only to an unambiguous task. Preserve both methods; changes to shared rules must be identified in comparisons. Gate: supplied compound task has one Aisha task with both activities and 2026-10-12, and independent-action counterexamples remain distinct. Do not merely add another name-specific exception.
3. **Benchmark optional spaCy augmentation.** Compare current, revised rules, and revised rules plus a small CPU parser on identical development cases. Use subject, object, conjunction, negation and modality annotations. Keep it off the production path unless it improves grouping/owner extraction without increasing unsupported assignments and fits measured resource limits. Exact memory/latency budgets should be chosen before accepting the experiment, not invented after a favorable run.
4. **Add contextual owners, temporal provenance and dependencies.** Optional backward-compatible fields for requirement links, condition text/evidence, and interpreted time. Preserve existing fields and update schema, extension and Streamlit together. Do not map a condition to blocked unless the text establishes it is unmet; an explicit conditional state can be safer. All-three references require an established recipient set, not merely three names somewhere in the email.
5. **Improve summaries using fact coverage.** Track actions, current event schedule, changes, completed facts and conditions. Keep a source-backed extractive mode. Benchmark Qwen rewriting of verified facts separately, with claim-to-evidence links and fallback to extracts; never feed the rewrite back into task extraction. Keep quotation validation separate from generated prose validation. BART remains deferred.
6. **Optional priority after correctness.** Sort by resolved dates and explicit urgency with reasons and user overrides. A displayed priority is a user-facing policy choice, not a probability. Unknown deadlines remain unknown; completed/cancelled tasks should not be promoted as urgent work.

## Evaluation changes to implement with the experiments

Existing evaluator already reports task/event precision, recall, F1; owner/deadline exact accuracy among matched tasks; non-null field precision/recall/F1; evidence matching; source-span summary coverage; latency. Preserve these historical strict metrics but add:

- Atomic-activity coverage, logical grouping accuracy and explicit over-split/over-merge counts. Compound tasks need both activity and grouping scores.
- Human-adjudicated one-to-one semantic alignment with saved reasons. Report strict span matching separately; embedding or token similarity may nominate matches, never establish correctness alone. Count missed tasks in end-to-end field scores and publish denominators/null cases.
- True literal task exact match and whole-record exact match under a published normalization policy. Do not label fuzzy matching as exact match.
- Event identity matching, duplicate count, current-versus-original schedule accuracy, status and cancellation correctness.
- Claim-level human summary factuality, important-fact coverage, unsupported claims, obsolete statements, conciseness and usefulness. Empty human ratings stay null, not zero or fabricated scores. Two independent reviewers and disagreement adjudication are preferable.
- Repeated warm/cold latency, median and tail latency, timeouts, token usage; separate Python/backend RSS from the local model process and GPU VRAM. Python allocation tracing alone misses model-server memory. Record sampling interval and peak-vs-snapshot limitation; report unavailable measurements as unavailable.
- Freeze datasets, code/prompt/configuration and model identifiers. Current fictional reserved data are consumed. New held-out examples should be independently authored and frozen before tuning, with threads/templates kept within one split. No corpus-origin labels or vectorizer fitting across train/test boundaries.

## Next decision

Recommended first agreed change: step 2 plus its regression annotations/metrics, keeping Qwen and local execution unchanged. spaCy is an experiment, not an immediate architecture dependency. Implementation and before/after improvement claims follow agreement on this plan. This investigation produced a before-run artifact only; nothing has been reported as fixed.
