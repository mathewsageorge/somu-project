"""Conservative source-based lifecycle rules, separate from model selection.

No new task is created here. Exact verb/object matches update existing records.
Unknown references, passive paraphrases and conditional updates need review.
"""
import re
from .schema import Evidence
from .text import canonical_text, sentences, suspicious

PAST = {'sent':'send','submitted':'submit','reviewed':'review','prepared':'prepare',
        'updated':'update','checked':'check','booked':'book','confirmed':'confirm',
        'uploaded':'upload','shared':'share','finished':'finish','approved':'approve',
        'drafted':'draft','completed':'complete','scheduled':'schedule','delivered':'deliver',
        'paid':'pay','revised':'revise'}
NAME = r"[A-Z][\w'-]*(?: [A-Z][\w'-]*)?"


def core(text, action_pattern):
    found = action_pattern.search(text)
    if not found:
        return None
    text = re.split(r'\b(?:by|before|due)\b', text[found.start():], maxsplit=1, flags=re.I)[0]
    return ' '.join(re.findall(r"[\w'-]+", text.casefold()))


def update_signal(sentence, verbs):
    if sentence.rstrip().endswith('?'):
        return None
    cancel = re.fullmatch(rf"(?:(?P<owner>{NAME}),\s*)?(?:please\s+)?(?:do not|don't|(?:you )?no longer need to)\s+(?P<action>(?:{verbs})\s+.+?)[.!]?", sentence, re.I)
    if cancel:
        return cancel['owner'], cancel['action'], 'cancelled'
    # Full affirmative clause only: no 'not yet', 'will', 'if', question, or
    # 'said that' pattern can enter this match.
    completed = re.fullmatch(rf"(?P<owner>{NAME})\s+has\s+(?:already\s+)?(?P<verb>{'|'.join(PAST)})\s+(?P<object>[^.!?]+)[.!]?", sentence)
    if completed and completed['owner'] not in {'He','She','It','Someone','Nobody','No one'}:
        return completed['owner'], PAST[completed['verb']]+' '+completed['object'], 'completed'
    return None


def reconcile(tasks, messages, ambiguities, action_pattern, verbs):
    active = []
    by_source = {}
    for task in tasks:
        e = task.evidence[0]
        by_source.setdefault((e.message_id,e.quote),[]).append(task)

    def attach(task, mid, quote):
        if not any(e.message_id==mid and e.quote==quote for e in task.evidence):
            task.evidence.append(Evidence(message_id=mid,quote=quote))

    for message in messages:
        for sentence in sentences(canonical_text(message)):
            if suspicious(sentence):
                continue
            current = by_source.get((message.id,sentence),[])
            signal = update_signal(sentence,verbs)
            if signal:
                owner, action, status = signal
                matches = [t for t in active if t.status in {'pending','needs_review'}
                           and core(t.action,action_pattern)==core(action,action_pattern)
                           and (owner is None or (t.owner is not None and t.owner.casefold()==owner.casefold()))]
                if len(matches)==1:
                    task=matches[0]
                    task.status=status
                    attach(task,message.id,sentence)
                    ambiguities.append(f'{message.id}: Status rule marked the earlier task {status} using an explicit matching update: {sentence}')
                elif len(matches)>1:
                    for task in matches:
                        task.status='needs_review'
                        attach(task,message.id,sentence)
                    ambiguities.append(f'{message.id}: Status update has multiple possible task owners/instances; no cancellation or completion was assumed: {sentence}')
            for newer in current:
                if newer.status in {'pending','needs_review'} and not signal:
                    newer_core=core(newer.action,action_pattern)
                    matches=[t for t in active if t.status in {'pending','needs_review'}
                             and newer_core is not None and core(t.action,action_pattern)==newer_core
                             and t.owner==newer.owner and t.evidence[0].message_id != message.id]
                    if len(matches)==1:
                        older=matches[0]
                        older.status='superseded'
                        attach(older,message.id,sentence)
                active.append(newer)
    if len(messages)>1:
        ambiguities.append('Status rules match explicit action wording and owners in thread order. Review paraphrases, pronouns and ambiguous updates; no new tasks are created by these rules.')


def current_state_summary(result, action_pattern, verbs):
    """Prefer evidenced lifecycle updates over obsolete requests, with disclosure."""
    updates=[]; stale=set()
    for task in result.tasks:
        if task.status in {'cancelled','completed','superseded'} and len(task.evidence)>1:
            origin=task.evidence[0]
            # Only lifecycle evidence added by reconcile, not arbitrary context.
            final=task.evidence[-1]
            signal=update_signal(final.quote,verbs)
            supported = (signal is not None and signal[2]==task.status
                         and core(signal[1],action_pattern)==core(task.action,action_pattern))
            supported |= (task.status=='superseded' and core(task.action,action_pattern) is not None
                          and core(final.quote,action_pattern)==core(task.action,action_pattern))
            if supported and final.quote != origin.quote:
                updates.append(final)
                stale.add((origin.message_id,origin.quote))
    if not updates:
        return result
    combined=[]; seen=set()
    for evidence in [*updates,*result.summary]:
        key=(evidence.message_id,evidence.quote)
        if key not in seen and key not in stale:
            combined.append(evidence); seen.add(key)
    result.summary=combined[:3]
    result.ambiguities.append('Summary rule prioritised the supporting status-update sentences over obsolete requests; review remaining coverage.')
    return result
