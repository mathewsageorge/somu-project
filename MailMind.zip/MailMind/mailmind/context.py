"""Narrow, disclosed contextual rules; these are not learned coreference."""
import re
from datetime import datetime, timedelta
from .dates import DATE_PATTERN, deadline_text
from .schema import Evidence
from .text import sentences


def event_schedule(sentence):
    """Use the destination of an explicit from/to reschedule, never its origin."""
    if not re.search(r'\b(?:rescheduled|moved|postponed)\b', sentence, re.I):
        return sentence, None
    destination = re.search(rf'\b(?:rescheduled|moved|postponed)\b.*?\bto\s+(?:\*\*|__)?(?={DATE_PATTERN})', sentence, re.I)
    if destination:
        return sentence[destination.end():], 'Rescheduled event: destination date selected; earlier date retained only in evidence.'
    return '', 'Rescheduled event needs review: destination date could not be resolved; no old date selected.'


def task_chunks(sentence, verbs):
    chunks = re.split(rf'\s+and\s+(?=(?:{verbs})\b|[A-Z][\w\x27-]*,\s+(?:please|could you|can you|kindly)\b)', sentence, flags=re.I)
    # A following share/upload action referring to it/them continues the same
    # deliverable. Keep the whole exact sentence and its final deadline together.
    if (len(chunks) == 2 and not deadline_text(chunks[0]) and deadline_text(chunks[1])
            and re.match(r'(?:share|upload|send|submit)\s+(?:it|them)\b', chunks[1], re.I)):
        return [sentence], True
    # A review followed by feedback or recording its issues is one linked
    # workflow under a final shared deadline, not an arbitrary verb conjunction.
    if len(chunks) == 2 and not deadline_text(chunks[0]) and deadline_text(chunks[1]):
        review = re.search(r'\breview\b', chunks[0], re.I)
        feedback = re.match(r'share\s+(?:your\s+|the\s+)?feedback\b', chunks[1], re.I)
        issue_tracking = (re.search(r'\bissues\b', chunks[0], re.I)
                          and re.match(r'update\s+(?:the\s+)?(?:tracking sheet|issue tracker|issue log)\b', chunks[1], re.I))
        if review and (feedback or issue_tracking):
            return [sentence], True
        activity = re.search(r'\b(?:testing|inspection|investigation|analysis|audit)\b', chunks[0], re.I)
        outcome = re.match(r'(?:share|send|submit)\s+(?:your |the )?(?:observations|findings|results)\s+by\b', chunks[1], re.I)
        if activity and outcome and not re.search(r'\b(?:not|cancel|if|unless)\b', sentence, re.I):
            return [sentence], True
    return chunks, False


def contextualize(tasks, events, sources, ambiguities):
    for task in tasks:
        mid = task.evidence[0].message_id
        source = sources[mid]
        sentence = task.evidence[0].quote
        rows = sentences(source)
        index = rows.index(sentence)
        if index + 1 < len(rows) and re.match(r'^This replaces the (?:previously communicated |previous |old )?deadline\b', rows[index + 1], re.I):
            update = rows[index + 1]
            task.evidence.append(Evidence(message_id=mid, quote=update))
            ambiguities.append(f'{mid}: Deadline update linked to the preceding request: {update} The earlier deadline is superseded; the current wording is {task.deadline_text or "unresolved"}.')
        early = re.fullmatch(r'Both of you should attend the meeting (\d{1,3}) minutes early(?: to [^.]+)?\.', sentence, re.I)
        if not early:
            continue
        task.status = 'needs_review'
        # Only an initial two-person greeting, never a quoted reply/signature.
        greeting = re.match(r'\s*(?:Subject:[^\n]*\n\s*)?(?:Hi|Hello|Dear) ([A-Z][\w\'-]* and [A-Z][\w\'-]*),', source)
        if greeting:
            task.owner = greeting.group(1)
            task.evidence.append(Evidence(message_id=mid, quote=greeting.group().strip()))
            ambiguities.append(f'{mid}: Attendance owner inferred from the two-person greeting ({task.owner}); review this contextual link.')
        matches = [event for event in events if event.evidence[0].message_id == mid
                   and re.search(r'\bmeeting\b', event.description, re.I)
                   and source.find(event.description) < source.find(sentence)]
        if len(matches) != 1 or matches[0].status not in ('announced', 'rescheduled'):
            ambiguities.append(f'{mid}: Early-arrival instruction needs review: no unique active preceding meeting.')
            continue
        event = matches[0]
        task.evidence.extend(event.evidence)
        minutes = int(early.group(1))
        if not event.date or not event.time_text:
            ambiguities.append(f'{mid}: Early-arrival instruction linked to the preceding meeting; its date/time is unresolved.')
            continue
        clock = re.sub(r'\s+', '', event.time_text).upper()
        for fmt in ['%I:%M%p', '%I%p', '%H:%M']:
            try:
                parsed = datetime.strptime(clock, fmt)
                arrival = datetime.fromisoformat(event.date).replace(hour=parsed.hour, minute=parsed.minute) - timedelta(minutes=minutes)
                task.deadline_text = sentence[early.start(1):early.end(1) + len(' minutes early')]
                task.deadline = arrival.date().isoformat()
                zone = event.timezone or 'source local time (timezone unconfirmed)'
                ambiguities.append(f'{mid}: Derived arrival time for "{sentence}": {arrival:%Y-%m-%d %H:%M}, {zone}. Calculated as meeting time minus {minutes} minutes; not a quoted time. Review before use.')
                break
            except ValueError:
                continue
    for mid in sources:
        if all(task.owner for task in tasks if task.evidence[0].message_id == mid):
            note = f'{mid}: Task owner is unspecified or requires coreference review.'
            while note in ambiguities:
                ambiguities.remove(note)
