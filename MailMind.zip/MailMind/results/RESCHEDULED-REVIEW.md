# Rescheduled meeting regression — 8 October 2026

The supplied fictional email exposed a wrong event date and a task/event classification error. This is a known development regression, not an independent held-out test. No model weights were trained or replaced.

## Changes

- Explicit rescheduling selects the destination after `to`, including its clock, rather than the first (old) date/time. An unresolved destination stays null and requires review.
- Requests to attend a meeting are tasks in the model prompt. The event guard now also catches `should attend`; an invalid event label is rejected with a warning, never silently replaced with a rule-generated task.
- A narrow rule groups two deliverable actions when the second refers to `it`/`them` and has a final deadline. Separate explicit deadlines remain separate. This interpretation is disclosed for review.
- Markdown emphasis no longer prevents calendar-date parsing. Deadline wording remains an exact source substring. Missing years are not inferred from unrelated dates.
- A following `This replaces ... deadline` sentence is retained as supporting evidence and an update note. This is a narrow same-message link, not general thread reasoning.
- For the explicit `Both of you should attend the meeting N minutes early` pattern, a two-person initial greeting supplies a reviewable owner inference. A unique preceding active meeting supplies the arrival calculation. Multiple or cancelled meetings block that calculation. The task retains its instruction, greeting and meeting evidence; derived time appears in review notes, not as a fabricated quote. The task is marked `needs_review`.

## Actual verification

`rescheduled-review-before.json` captured live Qwen3.5-4B output before changes: four task records, two event records, and the old meeting date. `rescheduled-review-final.json` captured the final source version: both approaches produce three grouped tasks and one event. Live model latency in that run was 4006.68 ms (920 input / 68 output tokens); external inference cost is not reported.

Expected interpretation of the supplied fixture:

| Item | Owner | Active timing |
|---|---|---|
| Complete report and share it | Rahul | Original wording: 16 October at 5:00 PM IST; year unresolved |
| Prepare slides and upload them | Sneha | Original wording: 17 October at 2:00 PM IST; year unresolved |
| Attend early and verify setup | Rahul and Sneha, inferred from greeting | Derived 2026-10-18 10:15 local time; needs review |
| Project review meeting | — | 2026-10-18, 10:30 AM; Conference Room 3 retained in description |

IST is not silently converted to UTC. Confirm `Asia/Kolkata` in the demo if that is intended. The earlier 14 October deadline is marked superseded in review notes. Completed configuration produces no pending task.

All **71 Python tests passed**, including 13 new checks covering the supplied email, revised clocks, unresolved reschedules, conflicting meetings, cancelled meetings, midnight arithmetic, quoted greetings, separate deadlines, and rejection of incorrectly labelled attendance events. Evidence: `python-tests-rescheduled.xml`. One existing Starlette/httpx test-client deprecation warning remains.

The running Streamlit demo was also exercised through its browser UI after restart: pasted email, AI method, Analyse, three task cards, one meeting, current date, inferred owner and derived-arrival review note were verified. Browser inference latency was 7657.07 ms. Evidence: `rescheduled-review-browser-check.json` and `rescheduled-review-browser.png`. This interaction was agent-driven, not a separate human usability study.

## Broader regression results

The same 24 previously inspected fictional cases were rerun on both current approaches. Existing held-out data were not used to tune these changes. Full predictions and source hashes: `rescheduled-review-regression-checks.json`.

| Set | Approach | Task TP / FP / FN | Task F1 | Event TP / FP / FN |
|---|---|---|---|---|
| dev (12 cases) | Rules | 11 / 0 / 1 | 0.9565 | 1 / 0 / 0 |
| dev (12 cases) | Qwen3.5-4B + rules | 11 / 0 / 1 | 0.9565 | 1 / 0 / 0 |
| event_challenge_v2 (12 cases) | Rules | 4 / 1 / 2 | 0.7273 | 4 / 0 / 0 |
| event_challenge_v2 (12 cases) | Qwen3.5-4B + rules | 6 / 0 / 0 | 1.0000 | 4 / 0 / 0 |

Remaining errors include a missed cancellation in `dev-cancel`, incorrect status on its earlier task, and one false non-null deadline-text extraction in the diagnostic set. Owner/date field correctness on matched tasks is not whole-system recall. Evidence validity was 100% for returned spans, which establishes copying fidelity only. Human summary factuality remains unmeasured; extractive summaries can omit important instructions. These small reused examples do not establish real-email accuracy.

## Try it

1. Open http://127.0.0.1:8502/ and select **Paste email**.
2. Paste `data/regression_rescheduled_review.txt` and select **AI model + rule checks (experimental)**.
3. Click **Analyse**. Check the three task cards and one event against the table above.
4. Expand evidence, read the inferred-owner/arrival notes, and export a fresh JSON. Old downloaded JSON files do not update.
5. To test resolved task years, explicitly add `2026` to the 16 and 17 October deadlines. Confirm the timezone separately. Do not change the original fixture or treat this variant as unseen evaluation data.

Reproduce with `python scripts/check_rescheduled_review.py --output results/your-new-run.json` while the local model server is running. The script refuses to overwrite an earlier run. This script explicitly saves this fictional fixture's results; the application still does not persist raw emails by default.
