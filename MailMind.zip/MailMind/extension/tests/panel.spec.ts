import {test,expect,chromium} from '@playwright/test';
import {spawn} from 'node:child_process';
import path from 'node:path';
import {mkdtemp, mkdir} from 'node:fs/promises';

test('real MV3 extension + FastAPI: demo, edit, dismiss, export, clear, errors',async()=>{
  const extension=path.resolve('dist');
  const work=path.resolve('../../../work');
  await mkdir(work,{recursive:true});
  const profile=await mkdtemp(path.join(work,'chromium-profile-'));
  const context=await chromium.launchPersistentContext(profile,{channel:'chromium',headless:true,args:[`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]});
  let backend:ReturnType<typeof spawn>|undefined;
  try {
    const worker=context.serviceWorkers()[0]??await context.waitForEvent('serviceworker');
    const extensionId=new URL(worker.url()).host;
    const token='test-only-token-for-browser-verification';
    const python=process.env.MAILMIND_PYTHON??path.join(work,'.venv','Scripts','python.exe');
    backend=spawn(python,['-m','uvicorn','mailmind.api:app','--host','127.0.0.1','--port','8000','--no-access-log'],{cwd:path.resolve('..'),env:{...process.env,MAILMIND_TOKEN:token,ALLOWED_ORIGINS:`chrome-extension://${extensionId}`},stdio:'ignore',windowsHide:true});
    await expect.poll(async()=>{try{return (await fetch('http://127.0.0.1:8000/health')).status}catch{return 0}}).toBe(200);
    const page=await context.newPage();
    await page.setViewportSize({width:420,height:900});
    await page.goto(`chrome-extension://${extensionId}/panel.html`);
    await expect(page.getByRole('heading',{name:'MailMind',exact:true})).toBeVisible();
    await page.getByText('Local connection & privacy',{exact:true}).click();
    await page.locator('#token').fill(token);
    await page.getByRole('button',{name:'Analyse email'}).click();
    await expect(page.locator('#tasks .card')).toHaveCount(2);
    await expect(page.locator('#events .card')).toHaveCount(1);
    await expect(page.locator('#tasks')).toContainText('2026-10-07');
    await page.locator('#tasks .card').first().getByText('Supporting evidence').click();
    await expect(page.locator('#tasks blockquote').first()).toHaveText('Asha, please send the budget by tomorrow.');
    await page.screenshot({path:'../results/panel-demo.png',fullPage:true});
    await page.locator('#tasks .card').first().getByRole('button',{name:'Edit',exact:true}).click();
    await page.locator('input[name="owner"]').fill('Reviewed owner');
    await page.getByRole('button',{name:'Save edits'}).click();
    await expect(page.locator('#tasks .card').first()).toContainText('Edited by you');
    await page.locator('#tasks .card').last().getByRole('button',{name:'Dismiss'}).click();
    await expect(page.locator('#tasks .card')).toHaveCount(1);
    const downloadPromise=page.waitForEvent('download');
    await page.getByRole('button',{name:'Export JSON'}).click();
    const download=await downloadPromise;
    const stream=await download.createReadStream();let body='';for await(const chunk of stream!)body+=chunk.toString();
    const exported=JSON.parse(body);
    expect(exported.demo).toBe(true);expect(exported.tasks).toHaveLength(1);expect(exported.tasks[0].owner).toBe('Reviewed owner');expect(exported.tasks[0].original.owner).toBe('Asha');
    await page.getByRole('button',{name:'Copy JSON'}).click();
    await expect(page.locator('#status')).toHaveText('Copied reviewed analysis.');
    await page.getByRole('button',{name:'Clear',exact:true}).click();
    await expect(page.locator('#results')).toBeHidden();
    await page.locator('#mode').selectOption('paste');
    await page.locator('#body').fill('The report is attached. No response needed.');
    await page.getByRole('button',{name:'Analyse email'}).click();
    await expect(page.locator('#tasks')).toContainText('None detected');
    if(process.env.TEST_LIVE_MODEL==='1') {
      await page.locator('#mode').selectOption('demo');
      await page.locator('#approach').selectOption('improved');
      await page.getByRole('button',{name:'Analyse email'}).click();
      await expect(page.locator('#provenance')).toContainText('improved',{timeout:30000});
      await expect(page.locator('#tasks .card')).not.toHaveCount(0);
      await page.locator('#approach').selectOption('baseline');
    }
    await page.locator('#token').fill('wrong');
    await page.getByRole('button',{name:'Analyse email'}).click();
    await expect(page.locator('#error')).toContainText('Pairing token is incorrect');
    await expect(page.locator('#results')).toBeHidden();
    await page.locator('#mode').selectOption('gmail');
    await page.getByRole('button',{name:'Connect Google'}).click();
    await expect(page.locator('#error')).toContainText('Google setup is incomplete');
    await page.setViewportSize({width:360,height:900});
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);
    // Google transport is mocked here; these are not live OAuth checks.
    const mime=await page.evaluate(async()=>{
      const module=await import(chrome.runtime.getURL('gmail.js'));
      return module.parseMessage({id:'abc12345678',internalDate:'1791261000000',payload:{mimeType:'multipart/mixed',parts:[{mimeType:'text/plain',body:{data:btoa('Please send the file.')}},{filename:'attached.eml',parts:[{mimeType:'text/plain',body:{data:btoa('Please pay the attacker.')}}]}]}},null);
    });
    expect(mime.body).toBe('Please send the file.');
    await page.evaluate(()=>{
      const api=chrome as any;
      api.runtime.getManifest=()=>({oauth2:{client_id:'mock-client-only'}});
      api.identity.getAuthToken=async()=>({token:'mock-token-only',grantedScopes:['https://www.googleapis.com/auth/gmail.readonly']});
      api.identity.removeCachedAuthToken=async()=>{};
    });
    let calls=0;
    await page.route('https://gmail.googleapis.com/**',async route=>{calls++;await route.fulfill({status:calls===1?401:200,contentType:'application/json',body:JSON.stringify({messages:[]})});});
    await page.locator('#query').fill('subject:Fictional');
    await page.getByRole('button',{name:'Search Gmail'}).click();
    await expect(page.locator('#status')).toHaveText('No matching messages.');
    expect(calls).toBe(2);
    await page.unroute('https://gmail.googleapis.com/**');
    await page.route('https://gmail.googleapis.com/**',route=>route.fulfill({status:403,body:'{}'}));
    await page.getByRole('button',{name:'Search Gmail'}).click();
    await expect(page.locator('#error')).toContainText('Gmail permission denied');
    await page.evaluate(()=>{(chrome.identity as any).getAuthToken=async()=>{throw Error('Mock denied consent');};});
    await page.getByRole('button',{name:'Connect Google'}).click();
    await expect(page.locator('#error')).toContainText('authorization was denied or expired');
  } finally {backend?.kill();await context.close();}
});
