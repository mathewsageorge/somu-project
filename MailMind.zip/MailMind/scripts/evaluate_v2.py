"""Frozen comparison on fictional v2 data; reserved data require explicit release."""
import argparse
import csv
import hashlib
import json
import os
import random
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluate import evaluate
from mailmind.schema import Analysis, AnalysisRequest, Evidence, Task, Event, validate_evidence
from mailmind.text import canonical_text


def load_split(split):
    folder = ROOT/'data/evaluation_v2'
    manifest = json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    path = folder/f'{split}.json'
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest['splits'][split]['sha256']:
        raise ValueError('Dataset hash changed; version and re-annotate rather than silently changing labels.')
    rows = json.loads(path.read_text(encoding='utf-8'))
    if len({c['id'] for c in rows}) != len(rows):
        raise ValueError('Duplicate case ID')
    for c in rows:
        request = AnalysisRequest(messages=c['messages'])
        sources = {m.id: canonical_text(m) for m in request.messages}
        support = [Evidence(message_id=mid,quote=text) for mid,text in sources.items()]
        expected_tasks = [Task(action=i['quote'],evidence=support,
            **{k:i[k] for k in ['owner','deadline_text','deadline','status']}) for i in c['gold']['tasks']]
        expected_events = [Event(description=i['quote'],evidence=support,
            **{k:i[k] for k in ['date_text','date','time_text','timezone','status']}) for i in c['gold']['events']]
        validate_evidence(Analysis(summary=[],tasks=expected_tasks,events=expected_events,ambiguities=[],
                                   approach='baseline',model=None,latency_ms=0),sources)
        for kind in ['tasks','events']:
            seen = set()
            for item in c['gold'][kind]:
                key = (item['message_id'], item['quote'])
                if key in seen or key[0] not in sources or key[1] not in sources[key[0]]:
                    raise ValueError('Duplicate or ungrounded gold span')
                seen.add(key)
        for fact in c['gold']['summary_facts']:
            if not any(fact in text for text in sources.values()):
                raise ValueError('Summary key span is absent from the source')
    return rows, manifest


def add_error_analysis(run, rows):
    event_fields = ['date_text','date','time_text','timezone','status']
    totals = {key: {'correct': 0, 'total': 0} for key in event_fields}
    cases = {c['id']: c for c in rows}
    errors = []
    for sample in run['runs']:
        case = cases[sample['id']]
        pred = sample['prediction']
        for kind, fields in [('tasks',['owner','deadline_text','deadline','status']), ('events',event_fields)]:
            gold = {(i['message_id'],i['quote']): i for i in case['gold'][kind]}
            matched = set()
            for item in pred[kind]:
                key = (item['evidence'][0]['message_id'], item['action' if kind == 'tasks' else 'description'])
                if key not in gold or key in matched:
                    errors.append(dict(case_id=case['id'],kind=kind,error='extra_or_boundary_mismatch',span=key[1]))
                    continue
                matched.add(key)
                for field in fields:
                    if kind == 'events':
                        totals[field]['total'] += 1
                        totals[field]['correct'] += item[field] == gold[key][field]
                    if item[field] != gold[key][field]:
                        errors.append(dict(case_id=case['id'],kind=kind,error='wrong_field',field=field,expected=gold[key][field],actual=item[field],span=key[1]))
            for key in sorted(set(gold)-matched):
                errors.append(dict(case_id=case['id'],kind=kind,error='missed_or_boundary_mismatch',span=key[1]))
    run['error_analysis'] = errors
    run['event_field_exact_accuracy_on_matched_events'] = {
        field: dict(**counts, accuracy=counts['correct']/counts['total'] if counts['total'] else None)
        for field, counts in totals.items()}


def write_report(folder, report):
    lines=['# Broader fictional development evaluation', '',
        'Single-author draft labels, frozen before inference. No independent annotation, real-email validation, or model training. Reserved cases were not run.' if report['split']=='development' else 'Reserved execution; same-author fictional data, not a blind external benchmark.', '',
        '| Method | Task TP / FP / FN | Precision | Recall | F1 | Events TP / FP / FN | Mean latency (ms) |',
        '|---|---|---|---|---|---|---|']
    for method, run in report['approaches'].items():
        if run['status'] != 'completed':
            lines.append(f"| {method} | Blocked: {run.get('reason')} | — | — | — | — | — |")
            continue
        m = run['metrics']; t=m['task_detection']; e=m['event_detection']
        lines.append(f"| {method} | {t['tp']} / {t['fp']} / {t['fn']} | {t['precision']:.3f} | {t['recall']:.3f} | {t['f1']:.3f} | {e['tp']} / {e['fp']} / {e['fn']} | {m['mean_latency_ms']:.1f} |")
    lines += ['', 'The baseline is rules only; improved is the experimental pretrained model plus shared rules. These names are not performance claims.',
        '', '## Field and summary checks', '',
        'Owner and deadline non-null precision/recall/F1 (including unmatched tasks), matched-task status accuracy, event argument accuracy, token usage and per-case predictions are in `results.json`. Event argument denominators include only correctly matched event spans and can overstate end-to-end quality. Null agreement is not successful entity extraction.',
        '', 'Evidence validity measures exact source copying, not correct interpretation. Summary key-span coverage is only an automatic inclusion check: stale, unimportant or misleading quoted text may still pass. Human factuality and coverage ratings are blank in `human-review.csv`; no human evaluation result is claimed.',
        '', '## Recorded errors', '']
    for method, run in report['approaches'].items():
        lines += [f'### {method}', '']
        for error in run.get('error_analysis',[]):
            detail = f" ({error['field']}: expected {error['expected']!r}, got {error['actual']!r})" if error['error']=='wrong_field' else ''
            lines.append(f"- {error['case_id']}: {error['kind']} — {error['error']}{detail}. Span: {error['span']}")
        if not run.get('error_analysis'): lines.append('No recorded span/field errors, or method blocked; check execution status above.')
    lines += ['', '## Interpretation and next experiment', '',
        'Labels were authored before either prediction run. Production model, prompt and extraction rules were not tuned to these results during this evaluation. Exact-span scoring penalizes otherwise valid segmentation; adjudicate boundary disagreements separately and preserve this original result.',
        '', 'Ask a human reviewer to inspect the development answer key, then revise development labels only in a new dataset version with a change log. Fix recurring development failures, freeze a new system version, and obtain explicit authorization before releasing the reserved cases. Once inspected or used for tuning, a case is no longer unseen.',
        '', 'Inference is local. Per-case token counts are recorded when the runtime returns them; API billing and hardware/electricity costs are unmeasured (null). Latency includes startup/cache/HTTP effects and is not a controlled throughput estimate.']
    (folder/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--split',choices=['development','reserved'],default='development')
    parser.add_argument('--release-reserved',action='store_true',help='Use only after explicit authorization for the final evaluation; do not tune to its output.')
    parser.add_argument('--output',required=True,help='New directory under results/')
    args=parser.parse_args()
    if args.split=='reserved' and not args.release_reserved:
        parser.error('Reserved split is locked for this workflow; explicit final-evaluation release is required.')
    folder=(ROOT/args.output).resolve()
    if not folder.is_relative_to((ROOT/'results').resolve()) or folder.exists():
        parser.error('Choose a new output directory inside results/. Earlier runs are immutable.')
    rows,manifest=load_split(args.split)
    load_dotenv(ROOT/'.env')
    folder.mkdir(parents=True)
    source_files=[*sorted((ROOT/'mailmind').glob('*.py')),ROOT/'evaluate.py',Path(__file__).resolve()]
    report=dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),split=args.split,
        dataset=manifest['splits'][args.split], labels='single-author draft; written before inference; no independent review',
        source_sha256={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files},
        model_configuration=dict(provider=os.getenv('MODEL_PROVIDER','ollama'),model=os.getenv('LLAMACPP_MODEL') if os.getenv('MODEL_PROVIDER')=='llamacpp' else os.getenv('OLLAMA_MODEL','qwen2.5:3b'),
                                 temperature=0,seed=42,context_tokens=8192),approaches={})
    # Snapshot contains code only, never .env, tokens or runtime request logs.
    with zipfile.ZipFile(folder/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in source_files: archive.write(p,p.relative_to(ROOT).as_posix())
    def save():
        (folder/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    save()
    for approach in ['baseline','improved']:
        run=evaluate(rows,approach)
        add_error_analysis(run,rows)
        report['approaches'][approach]=run
        save()
        print(json.dumps({'approach':approach,'status':run['status'],'metrics':run['metrics']}),flush=True)
    # Randomize row order and hide method labels from the ratings sheet. Keep
    # the answer mapping separate; this facilitates but cannot prove blinding.
    review=[]; key={}; rng=random.Random(20261008)
    for approach,run in report['approaches'].items():
        for item in run['runs']:
            review.append((approach,item))
    rng.shuffle(review)
    cases={c['id']:c for c in rows}
    fields=['review_id','case_id','source_thread','summary','supported_claim_count','unsupported_claim_count','contradicted_claim_count','key_points_covered','key_points_total','current_state_clear_yes_no','reviewer','notes']
    with (folder/'human-review.csv').open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields); writer.writeheader()
        for index,(method,item) in enumerate(review,1):
            rid=f'R{index:03d}'; key[rid]=method
            writer.writerow(dict(review_id=rid,case_id=item['id'],source_thread='\n\n'.join(m['body'] for m in cases[item['id']]['messages']),
                summary='\n'.join(e['quote'] for e in item['prediction']['summary'])))
    (folder/'review-method-key.json').write_text(json.dumps(key,indent=2),encoding='utf-8')
    write_report(folder,report)


if __name__=='__main__':
    main()
