"""Pinned ~3.4 GB model/GPU runtime download; no emails or credentials sent."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import httpx

REVISION = 'e87f176479d0855a907a41277aca2f8ee7a09523'
RELEASE = 'b11443'
FILES = {
    'Qwen3.5-4B-Q4_K_M.gguf': (
        f'https://huggingface.co/unsloth/Qwen3.5-4B-GGUF/resolve/{REVISION}/Qwen3.5-4B-Q4_K_M.gguf',
        '00fe7986ff5f6b463e62455821146049db6f9313603938a70800d1fb69ef11a4'),
    'llama-cuda.zip': (
        f'https://github.com/ggml-org/llama.cpp/releases/download/{RELEASE}/llama-{RELEASE}-bin-win-cuda-12.4-x64.zip',
        '1f9806c72a7f7170e7ecac4dbeda24fff2137915d031f6cbfd697e6161c108cb'),
    'cudart.zip': (
        f'https://github.com/ggml-org/llama.cpp/releases/download/{RELEASE}/cudart-llama-bin-win-cuda-12.4-x64.zip',
        '8c79a9b226de4b3cacfd1f83d24f962d0773be79f1e7b75c6af4ded7e32ae1d6'),
}


def checksum(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', required=True)
    target = Path(parser.parse_args().directory).resolve()
    target.mkdir(parents=True, exist_ok=True)
    manifest = {'model': 'Qwen3.5-4B-Q4_K_M', 'publisher': 'Qwen', 'quantization_publisher': 'Unsloth',
                'revision': REVISION, 'runtime_release': RELEASE, 'files': {}}
    for name, (url, expected) in FILES.items():
        path = target/name
        if not path.exists():
            partial = path.with_suffix('.part')
            offset = partial.stat().st_size if partial.exists() else 0
            headers = {'Range': f'bytes={offset}-'} if offset else {}
            print(f'Downloading {name}; resume offset {offset:,} bytes', flush=True)
            with httpx.stream('GET', url, headers=headers, follow_redirects=True, timeout=90) as response:
                response.raise_for_status()
                resumed = offset and response.status_code == 206
                if resumed and not response.headers.get('Content-Range', '').startswith(f'bytes {offset}-'):
                    raise RuntimeError('Unexpected range response')
                count = offset if resumed else 0
                last_report = count
                with partial.open('ab' if resumed else 'wb') as f:
                    for chunk in response.iter_bytes(1024*1024):
                        f.write(chunk)
                        count += len(chunk)
                        if count - last_report >= 256*1024*1024:
                            print(f'{name}: {count/1024**2:.0f} MiB downloaded', flush=True)
                            last_report = count
            if checksum(partial) != expected:
                raise RuntimeError(f'Checksum mismatch: {name}; partial retained, not loaded')
            partial.replace(path)
        if checksum(path) != expected:
            raise RuntimeError(f'Checksum mismatch: {name}; not loaded')
        manifest['files'][name] = {'url': url, 'bytes': path.stat().st_size, 'sha256': expected, 'verified': True}
        print(f'Verified {name}', flush=True)
    runtime = target/'runtime'
    runtime.mkdir(exist_ok=True)
    for archive_name in ['llama-cuda.zip', 'cudart.zip']:
        with zipfile.ZipFile(target/archive_name) as archive:
            for entry in archive.infolist():
                if not (runtime/entry.filename).resolve().is_relative_to(runtime):
                    raise ValueError('Unsafe archive path')
            archive.extractall(runtime)
    (target/'download-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('Verified weights and GPU runtime are ready. Nothing has been trained.', flush=True)
