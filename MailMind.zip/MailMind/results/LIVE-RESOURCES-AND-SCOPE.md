# Local web scope and live hardware panel — 12 October 2026

The user placed **Chrome extension integration and Gmail connection in future scope**. The current submission is the local Streamlit web application and Python NLP pipeline. Exploratory extension/FastAPI source is preserved; no completed connected Google workflow is claimed. The project report and presentation have been updated accordingly.

## UI and implementation

- The Streamlit Deploy button is hidden with a targeted `stAppDeployButton` CSS selector; other run/menu controls remain. This is a UI adjustment, not a deployment implementation.
- A top-of-page panel shows system RAM used/total/percent, NVIDIA GPU-0 utilization, GPU memory used/total and a UTC sample timestamp. Updates occur about every two seconds while the page remains connected.
- Idle updates use a Streamlit fragment, following the [official fragment guidance](https://docs.streamlit.io/develop/concepts/architecture/fragments). During analysis the existing pipeline runs in one worker while the UI polls completion and refreshes the panel. The worker makes no Streamlit calls.
- `mailmind/resources.py` uses the standard library: Windows GlobalMemoryStatusEx (Linux MemAvailable fallback) and a read-only, shell-free `nvidia-smi` query with a 1.5 s timeout and hidden Windows process. No dependencies were added.
- Unknown/failed readings show Unavailable, never fake zero. Other vendors and missing NVIDIA drivers are not supported for GPU readings. Only NVIDIA GPU 0 is displayed.
- These are whole-laptop/GPU measurements, including other apps. They are not model-only allocations or accuracy/confidence metrics. Loaded weights can use VRAM at zero GPU activity. No email text enters telemetry; readings are not persisted by the normal UI or added to analysis JSON.

## Verification

**187 tests passed** with one existing Starlette/httpx deprecation warning: `python-tests-live-resources.xml`. Ten new tests cover zero-vs-missing readings, partial/invalid CSV, missing drivers, failed commands, bounded shell-free queries, driver timeout/RAM failure, repeated refresh preserving a result, and refresh during a model failure. The existing failure-banner check was narrowed to analysis metrics so hardware readings cannot be mistaken for a completed inference.

Live browser check at port 8502:

- Deploy absent from the visible/accessibility UI.
- RAM, GPU name/activity and VRAM readings displayed.
- Timestamp advanced from 13:20:54 UTC to 13:21:09 UTC during the same model run; GPU activity changed from 0% to 33%.
- Case 22 completed with the same 3 tasks / 1 event, Qwen model name and 2,220 input / 1,099 output tokens. Pipeline time: **51.25 s**.
- GPU activity returned to 0% after completion; idle sample timestamps continued advancing without clearing the result.
- JSON export worked; public schema/exact evidence validation against the Case 22 fixture is recorded with the copied export `live-monitor-browser-export.json`.
- Screenshot captured during analysis: `live-resources-inference.png`.

A direct hardware sample during inference measured 13,632.2 MiB RAM used of 16,109.1 MiB physical RAM, 2,401 MiB GPU memory of 4,096 MiB, 42% GPU activity and 174.5 ms sampling wall time. This is one observation, not a benchmark or peak claim. The browser and terminal readings occurred at different instants.

## Research/result boundaries

No NLP code, Qwen weights, prompts, labels or prior measured comparison results changed. The 51.25 s live check is not a controlled comparison of monitor overhead. Historical 49.99 s median and other reported timings predate this UI monitor. Reported detection/field results remain version-specific. The updated presentation retains the original native chart and source workbook bytes; every final slide is rendered for review.
