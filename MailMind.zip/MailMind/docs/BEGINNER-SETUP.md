# MailMind - beginner Windows setup guide
Prepared for sharing by Sonu Jacob Jose. 12 October 2026.

Use the PDF for reading and this text version for copying commands. Each numbered heading corresponds to a guide page.

## Start here: MailMind on another laptop

A beginner-friendly Windows setup guide. Prepared for sharing by Sonu Jacob Jose, 12 October 2026. Follow the numbered steps in order. You do not need to know programming.

### What Sonu should send

Send the updated MailMind.zip and this guide. The ZIP contains the application, fictional examples and results. It does not contain Python, an installed Python environment, Qwen model weights, runtime binaries or credentials. Your friend must install/download the missing parts below.

To copy commands easily, right-click docs\BEGINNER-SETUP.md, choose Open with, then Notepad. Copy only the command lines, not the triple-backtick code-block labels. The PDF is for reading; the text file avoids PDF copy/paste changes.

### Choose the route that matches the laptop

Route A: the basic website and Rules Only comparison. Complete pages 1-2. It needs Python and internet for installation. It does not need an NVIDIA GPU, Google account, API key or model download. This proves the website runs; it does not demonstrate AI inference.

Route B: the main Structured AI system. Complete pages 1-4, then use page 5 for later starts. These GPU instructions target Windows 10/11 on an Intel/AMD 64-bit laptop with an NVIDIA GPU. The existing verified laptop has 16 GB RAM and an RTX 3050 with 4 GB VRAM. Other configurations can need adjustment and are not guaranteed.

If the laptop has no NVIDIA GPU, start with Route A. This guide does not claim a tested CPU-only Qwen setup. If it is a Mac, Linux machine or Windows ARM laptop, the model runtime commands need a different build. Do not download the Windows CUDA runtime for those systems.

### Before starting

Plug in the charger. For Route B, close games and other heavy apps. Allow at least 10 GB of free disk space as a practical buffer for downloads, extracted runtime and Python packages. Model/runtime downloads alone are about 3.4 GB in decimal units. Installation time depends on the connection.

### Two simple terms

PowerShell is a Windows command window where you paste the commands in this guide. The website is one running program. Qwen is a second running program that answers the website locally. For AI, both must stay running.

**Check:** No Chrome extension, Gmail connection, FastAPI server, Node.js, VS Code, Git or paid service is needed for this local web demo. Chrome/Gmail integration is future scope.

## 1. Install Python and open the basic website

### 1A. Install Python 3.13, 64-bit

Open the official download page: https://www.python.org/downloads/release/python-31316/ . Under Files, choose Windows installer (64-bit). Run it, tick Add python.exe to PATH and choose Install Now. Use the standard installer, not an embeddable, ARM64 or free-threaded build. Close old terminal windows after installation. The project has been tested on Python 3.13.7; the linked newer 3.13 maintenance installer has not been separately tested here.

### 1B. Extract the project and open PowerShell there

Save MailMind.zip in Downloads. Right-click it, choose Extract All, choose a folder such as Downloads\MailMindDemo, then Extract. Open the extracted MailMind folder. If there are two nested MailMind folders, open the inner one that contains demo.py and requirements.lock. Do not run files from inside the ZIP.

Inside that folder, click the File Explorer address bar, type powershell and press Enter. A command window opens in the correct folder. Do this whenever this guide says open PowerShell in the project folder. You do not need administrator mode.

### 1C. Check Python, then install project packages once

Paste each command below separately and press Enter. Wait for one to finish before the next. A normal prompt begins with PS. If you see >>>, you opened Python instead; type exit() and open PowerShell as above.

```powershell
py -3.13 --version
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock
```

**Check:** The first command should say Python 3.13.x. After the last command finishes without an error, the PS prompt returns. Keep the .venv folder; it contains this project's installed packages. No environment-activation command is needed.

### 1D. Start the website and check it

Copy the ENTIRE block below at once, including the small backticks at the ends of lines. Paste and press Enter. A >> prompt briefly means PowerShell is continuing the same command.

```powershell
.\.venv\Scripts\python.exe -m streamlit run demo.py `
  --server.address 127.0.0.1 --server.port 8502 `
  --server.headless true --browser.gatherUsageStats false
```

Leave this window open. In Chrome or Edge, enter http://127.0.0.1:8502/ in the address bar. Select Example thread, leave dev-multiple selected, choose Rules only (baseline), and click Analyse. Expect two task cards and one event for this supplied sample. Read the evidence too. Baseline uses programmed rules; no AI model has run.

**Check:** If you only need Route A, you can stop here. For Route B, press Ctrl+C in this website terminal before continuing. Closing only the browser does not stop the website.

## 2. Download Qwen and start the AI engine

Route B only: Windows x64 with an NVIDIA GPU. The model remains Qwen3.5-4B-Q4_K_M; this guide does not replace or train it.

### 2A. Check the NVIDIA driver

Open PowerShell in the project folder. Run:

```powershell
nvidia-smi
```

You should see an NVIDIA GPU name, driver information and memory values. If the command fails or there is no NVIDIA GPU, see page 7 before continuing. This project downloader includes the runtime DLLs; installing the full CUDA developer toolkit is not part of these steps.

### 2B. Download the model and runtime once

```powershell
.\.venv\Scripts\python.exe scripts/fetch_candidate_model.py `
  --directory ..\mailmind-model
```

Wait until it says Verified weights and GPU runtime are ready. Nothing has been trained. Progress appears in large increments, so a quiet interval is normal. The script checks file hashes before using the files. If the connection fails, run the same command again to resume an incomplete download. Do not close the window during a successful download.

A mailmind-model folder appears next to the MailMind project folder, not inside it. Keep both folders in place. The model folder must contain Qwen3.5-4B-Q4_K_M.gguf and runtime\llama-server.exe, with its DLL files beside the executable. Do not copy only the executable.

### 2C. Start Qwen in Terminal A

In the same project-folder PowerShell window, copy and run this ENTIRE block. It creates a list of startup options, then starts the model. Do not change the model name or port.

```powershell
$mailmindArgs = @(
  '-m','..\mailmind-model\Qwen3.5-4B-Q4_K_M.gguf',
  '--alias','Qwen3.5-4B-Q4_K_M',
  '--host','127.0.0.1','--port','8082',
  '-c','8192','-np','1','-ngl','24',
  '-b','256','-ub','128',
  '--reasoning','off','--log-disable'
)
& "..\mailmind-model\runtime\llama-server.exe" @mailmindArgs
```

**Check:** Keep Terminal A open. A busy window without a new PS prompt is expected. Logs are disabled, so silence is not an error. The health check on the next page confirms readiness. Do not start a second model on the same port.

## 3. Connect the website to Qwen and analyse

### 3A. Confirm that Qwen is ready

Leave Terminal A open. In the browser, open http://127.0.0.1:8082/health . When ready, it should show a small response such as {"status":"ok"}. Loading can take time. If it still says loading, wait and refresh. If it cannot connect or keeps failing, use page 7. Do not proceed to AI analysis until the health check is OK.

### 3B. Start the website in Terminal B

Open a SECOND PowerShell window from the project folder using File Explorer as on page 2. Paste the whole block below. These settings apply to this terminal only, so repeat them whenever you restart the website. You do not need to create or edit a .env file for this route.

```powershell
$env:MODEL_PROVIDER='llamacpp'
$env:LLAMACPP_URL='http://127.0.0.1:8082'
$env:LLAMACPP_MODEL='Qwen3.5-4B-Q4_K_M'
.\.venv\Scripts\python.exe -m streamlit run demo.py `
  --server.address 127.0.0.1 --server.port 8502 `
  --server.headless true --browser.gatherUsageStats false
```

**Check:** Keep both Terminal A and Terminal B open. Terminal A runs Qwen on port 8082. Terminal B runs MailMind on port 8502. These addresses work on this laptop; they are not public websites.

### 3C. Test the main AI system

Open http://127.0.0.1:8502/ . Choose Example thread and dev-multiple for a short first test. Choose Structured AI - Qwen extraction (new); the UI uses a middle dot between Structured AI and Qwen. Confirm the configured model is Qwen3.5-4B-Q4_K_M, then click Analyse.

While waiting, a floating loading card shows elapsed time, actual pipeline stages and laptop RAM/GPU readings. Usage appears only while analysing. GPU readings include other apps; zero activity can coexist with allocated GPU memory. The app cannot show an exact completion percentage or remaining time. After completion, check the actual model identifier and processing time above the results.

### 3D. Review and save the result

Open Summary, Action items, Events and Review notes. Expand supporting evidence and compare it with the input. A short email should be quicker than a long one, but no fixed time is promised. The supplied short example expects two tasks and one meeting; model errors remain possible. Export JSON downloads a local result file. Clear analysis removes the result display; clear pasted text separately if needed.

**Check:** Success means: model health is OK, the website loads, Structured AI finishes with a model identifier, and the result has reviewable evidence. A working Rules Only result alone does not prove Qwen is connected.

## 4. Next-day startup, shutdown and a short test

### You do not reinstall everything every day

Keep the extracted project, .venv and neighboring mailmind-model folder. After a laptop restart: (1) open PowerShell in the project folder and run the Terminal A block on page 3; (2) wait for the model health check on page 4; (3) open a second project-folder PowerShell and run the Terminal B block on page 4; (4) open http://127.0.0.1:8502/ and choose Structured AI. Repeat the download only if files are missing or incomplete.

If you only want Rules Only, run the website block on page 2. Qwen does not need to be running for that method. If a service is already running and healthy, use it instead of starting a second copy.

### Stop the project properly

Press Ctrl+C in Terminal B to stop the website, then Ctrl+C in Terminal A to stop Qwen. If a PS prompt returns, that program has stopped. Close the windows afterward. Closing the browser alone leaves both programs running and can leave GPU memory allocated.

### Short fictional email for a demonstration

Choose Paste email and copy the text below. Leave HTML input unchecked. Sender timestamp/timezone can stay blank because these dates contain an explicit year and UTC time.

```text
Subject: Review preparation

Hi Aisha and Rahul,

Aisha, please send the report by October 15, 2026.
Rahul, please prepare the slides by October 16, 2026.
Our review meeting is on October 17, 2026, at 10 AM UTC.

Thanks,
Meera
```

Expected answer: two logical tasks, Aisha and Rahul as separate owners, their respective deadlines, and one review meeting on October 17 at 10 AM UTC. The summary should cover both requests and the meeting. This is a test expectation, not a guarantee that the model is correct.

### What happens to the email?

Selected text is processed locally by the Python pipeline and local Qwen runtime. The demo has no raw-email database. Explicit JSON exports remain files on the laptop. Installation/model downloads need internet; once everything is installed, the local pipeline does not need a paid API. Use fictional emails or data you have permission to process. The model can retain prompt memory until stopped.

## 5. Fix common installation and website problems

### Python command is not recognized, or Microsoft Store opens

Use py -3.13 --version. If that also fails, rerun the official Python 3.13 64-bit installer and ensure the launcher/PATH options are installed. Close old PowerShell windows, then open a new one. Do not install an unrelated package named Python from an advertisement.

### The system cannot find demo.py, requirements.lock or .venv

You are probably in the wrong folder, inside the ZIP, or in its outer wrapper. Open File Explorer, find the extracted folder containing demo.py, mailmind and requirements.lock, and open PowerShell there. If .venv is missing, repeat step 1C. File Explorer may hide .py; the demo file can appear simply as demo.

### No module named streamlit / httpx / another package

Use the exact .\.venv\Scripts\python.exe commands in this guide. Run the installation command from step 1C again. Using a different python command may select a different environment.

### Package install fails / no matching distribution / timeout

Check internet, disk space and Python 3.13 64-bit first. Copy the first actual error message. The project uses requirements.lock, not requirements.txt. Do not guess newer package versions, disable certificate checks or delete the lockfile. Retry a connection timeout on a stable network. If a pinned package is unavailable, ask Sonu to review the error and dependency lock.

### The page cannot be reached

Ensure Terminal B is still running, then type http://127.0.0.1:8502/ in the browser address bar, not a search box. Do not use https. Your own laptop must run MailMind; Sonu's localhost address cannot be opened remotely. If the terminal returned to PS with an error, fix that error first.

### Port 8502 is already in use

First check whether MailMind is already running at the usual address. If yes, use it. Otherwise, stop your own previous website terminal with Ctrl+C. If you cannot identify it, change only --server.port 8502 to --server.port 8503 in the website command and open http://127.0.0.1:8503/ . Keep the Qwen model port at 8082.

### PowerShell says scripts are disabled

The commands here run python.exe and llama-server.exe directly. No Activate.ps1, .ps1 launcher or permanent execution-policy change is required. Return to the literal commands on pages 2-4. Copy code from the companion Markdown file if PDF copying has changed a quote or backtick.

**Check:** If a command fails, stop at that step. Repeatedly launching more windows will not fix missing files or packages.

## 6. Fix AI problems and know the limits

### nvidia-smi fails / GPU is not NVIDIA

If Task Manager > Performance shows only Intel or AMD graphics, use Route A. The GPU instructions here are for NVIDIA. If the laptop does have NVIDIA, install a compatible driver through the laptop vendor or https://www.nvidia.com/en-us/drivers/ and restart when the installer asks. A developer CUDA toolkit is not required by this guide. Other hardware needs a separately verified runtime setup.

### Model unavailable, timed out or invalid output

Open http://127.0.0.1:8082/health . If it is unreachable, Terminal A may be closed or the model failed to load. If health is OK, stop Terminal B and rerun its COMPLETE block so all three model settings are correct. Try the short sample on page 5. Structured AI uses a 90-second model-request timeout; slower hardware or long emails may exceed it. Invalid model output also produces an error and is not silently replaced by baseline output.

### Missing DLL, model file or checksum mismatch

Keep all extracted runtime DLLs beside llama-server.exe. Repeat the downloader if files are missing. A checksum mismatch means the file is not verified: do not skip the check or run that file. Ask Sonu to help inspect or re-download the affected file. Do not rename an unrelated model to the expected name.

### GPU out of memory / CUDA allocation failed

Close games and other GPU-heavy apps. Stop your failed Terminal A process before restarting. If memory is still insufficient, change only the value 24 after -ngl in the Terminal A block to 12, then retry health and a short email. Fewer GPU layers may reduce GPU memory needs and increase latency; 12 layers has not been benchmarked here. If it still fails, use Route A and ask Sonu to check the hardware. Do not claim the AI works until health AND analysis succeed.

### A task, owner, date or summary is wrong

That is an NLP error, not necessarily an installation error. Keep the original fictional input and exported JSON so it can be reviewed. Exact supporting text does not prove the model interpreted it correctly. No model guarantees 100 percent accuracy. Relative dates need trusted sender timestamp and timezone context; ambiguous dates/timezones may intentionally remain unresolved.

### If you need help, send these details

Send Windows version, installed RAM, GPU name/VRAM, the step number that failed, exact error message, whether model health is OK, and whether the website opens. Do not send .env files, tokens, passwords or private emails. A screenshot of the error is useful.

### Verification and official sources

This guide matches the shipped source, pinned downloader and model alias. The current original-laptop suite passed 192 tests. A separately extracted ZIP was checked using the existing Python environment, not a fresh package installation. Your friend's laptop and a new internet install have not been verified. Checkpoints above are how to verify them.

Official references checked 12 October 2026: Python installer and Windows instructions: https://www.python.org/downloads/release/python-31316/ and https://docs.python.org/3.13/using/windows.html . Pinned runtime: https://github.com/ggml-org/llama.cpp/releases/tag/b11443 . Model: https://huggingface.co/Qwen/Qwen3.5-4B . Exact quantized file/revision/checksums are in scripts/fetch_candidate_model.py.
