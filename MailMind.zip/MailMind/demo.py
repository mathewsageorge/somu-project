"""Run from project root: streamlit run demo.py"""
import json
import hashlib
import os
import time
from queue import Queue, Empty
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import streamlit as st
from dotenv import load_dotenv
from mailmind.schema import AnalysisRequest, Message
from mailmind.pipeline import analyse
from mailmind.improved import ModelUnavailable
from mailmind.text import canonical_text
from mailmind.resources import sample_resources
from mailmind.loading import loading_card

load_dotenv()
st.set_page_config(page_title="MailMind · Email intelligence", page_icon="✉", layout="wide")
st.html("""<style>
.block-container {max-width:1500px; padding:1.4rem 2rem 3rem;}
.stApp {background:#f5f6f8;}
h1,h2,h3 {letter-spacing:-.025em;}
h3 {font-size:1.25rem !important;}
[data-testid="stHeader"] {background:transparent;}
[data-testid="stAppDeployButton"] {display:none !important;}
[data-testid="stMainBlockContainer"] > div {gap:1rem;}
[data-testid="stMetric"] {background:#f7f8fb;border:1px solid #e5e7ef;border-radius:12px;padding:12px;}
[data-testid="stMetricValue"] {font-size:1.65rem;color:#4f46e5;}
[data-testid="stVerticalBlockBorderWrapper"] {border-radius:16px;}
.st-key-source-panel [data-testid="stVerticalBlock"] {gap:.6rem;}
[data-testid="stCaptionContainer"] {color:#586579;}
.st-key-source-panel,.st-key-result-panel {background:white;border:1px solid #e4e7ee;border-radius:18px;padding:24px;}
.mm-nav {display:flex;align-items:center;justify-content:space-between;margin:12px 0 26px;gap:16px;}
.mm-brand {display:flex;align-items:center;gap:12px;}
.mm-logo {background:#4f46e5;color:white;border-radius:12px;padding:10px 14px;font-size:22px;font-weight:800;}
.mm-name {font-size:25px;font-weight:750;color:#172034;letter-spacing:-1px;}
.mm-tag {font-size:12px;color:#667085;}
.mm-pill {font-size:12px;color:#405269;background:white;border:1px solid #e1e5ec;border-radius:24px;padding:8px 14px;}
.mm-empty {padding:65px 24px;text-align:center;}
.mm-empty-icon {display:inline-block;background:#eeedff;color:#5950cd;border-radius:20px;padding:18px 24px;font-size:32px;}
.mm-empty h2 {font-size:24px;color:#29344a;margin:22px 0 10px;}
.mm-empty p {color:#667085;max-width:360px;margin:0 auto;line-height:1.7;}
.mm-guide {display:flex;gap:8px;justify-content:center;margin-top:30px;flex-wrap:wrap;}
.mm-guide span {border:1px solid #e3e7ee;padding:8px 12px;border-radius:8px;color:#606d80;font-size:12px;}
.mm-loading {position:fixed;top:4rem;right:1.5rem;z-index:999;width:440px;max-width:calc(100vw - 32px);max-height:calc(100dvh - 5rem);overflow:auto;box-sizing:border-box;background:#fff;border:1px solid #c9c5fc;border-radius:20px;box-shadow:0 16px 60px #25234d30;padding:22px;color:#172034;font-size:14px;line-height:1.5;}
.mm-loading-head {display:flex;align-items:center;gap:14px;}.mm-loading-head strong {font-size:19px;}.mm-loading-head div div {font-size:12px;color:#667085;}
.mm-orbit {width:28px;height:28px;flex-shrink:0;border:3px solid #e6e3ff;border-top-color:#4f46e5;border-radius:50%;animation:mm-spin .9s linear infinite;}
@keyframes mm-spin {to {transform:rotate(360deg);}}
.mm-runtime {font-size:12px;color:#4f46e5;overflow-wrap:anywhere;}.mm-steps {display:flex;gap:7px;}.mm-step {flex:1;padding:7px 5px;border-radius:7px;background:#f3f4f7;color:#667085;font-size:12px;text-align:center;}.mm-step.active {background:#eeedff;color:#4f46e5;font-weight:700;}.mm-step.done {background:#eaf7f1;color:#18734e;}
.mm-hardware-label {display:block;margin:16px 0 9px;}.mm-live-grid {display:grid;grid-template-columns:repeat(3,1fr);gap:8px;}.mm-live-grid div {background:#f7f8fb;border-radius:10px;padding:10px 8px;}.mm-live-grid small {display:block;font-size:11px;color:#667085;}.mm-live-grid b {display:block;font-size:18px;color:#4f46e5;}.mm-explanation {font-size:12px;color:#405269;}.mm-loading > small {display:block;font-size:11px;color:#667085;}
@media(prefers-reduced-motion:reduce) {.mm-orbit {animation:none;}}
@media(max-width:750px) {.block-container {padding:1rem;} .mm-nav {margin-bottom:16px;} .mm-pill {display:none;} .st-key-source-panel,.st-key-result-panel {padding:16px;}}
</style>
<div class="mm-nav"><div class="mm-brand"><div class="mm-logo">M</div><div><div class="mm-name">MailMind</div><div class="mm-tag">Email intelligence workspace</div></div></div><div class="mm-pill">MTech research demo · Local processing</div></div>""")

# Hardware readings appear only in the active loading card. No idle polling.
loading_slot = st.empty()


def analyse_with_live_usage(request, model):
    started = time.monotonic()
    updates = Queue()
    phase = 'preparing'
    reading = sample_resources()
    last_sample, last_draw = started, 0
    try:
        with ThreadPoolExecutor(max_workers=1, thread_name_prefix='mailmind-analysis') as pool:
            future = pool.submit(analyse, request, progress=updates.put)
            while True:
                now = time.monotonic()
                changed = False
                try:
                    phase = updates.get(timeout=.1)
                    changed = True
                except Empty:
                    pass
                if now - last_sample >= 2:
                    reading = sample_resources()
                    last_sample = now
                if changed or now - last_draw >= 1:
                    loading_slot.html(loading_card(phase, now-started, reading, model, request.approach))
                    last_draw = now
                if future.done():
                    return future.result()
    finally:
        # Also clear on invalid model output/timeouts. No stale success state.
        loading_slot.empty()


left, right = st.columns([0.95, 1.3], gap='large')
with left, st.container(key='source-panel'):
    st.subheader('Your email')
    st.caption('Choose a sample or paste an email to get started.')
    cases = json.loads((Path(__file__).parent / "data/dev.json").read_text(encoding="utf-8"))
    cases += json.loads((Path(__file__).parent / "data/evaluation_v2/development.json").read_text(encoding="utf-8"))
    manual22 = json.loads((Path(__file__).parent / 'data/manual_case_22.json').read_text(encoding='utf-8'))
    cases.append({'id': manual22['id'], 'messages': manual22['messages']})
    case_labels = {c['id']: c['id'] + (' — ' + ', '.join(c['tags']) if c['id'].startswith('v2-') else '') for c in cases}
    case_labels['manual-22-uat-readiness'] = 'Test Case 22 · UAT approval and rescheduled meeting'
    mode = st.radio("Input format", ["Example thread", "Paste email"], horizontal=True, label_visibility="collapsed")
    choice = st.selectbox("Fictional example", [c["id"] for c in cases], format_func=case_labels.get,
                          disabled=mode != 'Example thread')
    case = next(c for c in cases if c["id"] == choice)
    method_names = {"baseline": "Rules only (baseline)", "improved": "Previous AI · sentence selection", "structured": "Structured AI · Qwen extraction (new)"}
    if mode == "Example thread":
        messages = case["messages"]
        st.markdown('**Selected email**' if len(messages) == 1 else '**Selected conversation**')
        for index, message in enumerate(messages, 1):
            with st.container(border=True):
                st.caption(f"Message {index} · {message['id']}")
                st.text(canonical_text(Message.model_validate(message)))
                context = []
                if message.get('sent_at'):
                    context.append('Sent: ' + message['sent_at'])
                if message.get('timezone'):
                    context.append('Timezone: ' + message['timezone'])
                if context:
                    st.caption(' · '.join(context))
        with st.expander('Technical input details (JSON)'):
            st.json(messages, expanded=False)
        if 'reference_summary' in case:
            with st.expander('Expected answer (fictional development data)'):
                st.write(case['reference_summary'])
                st.json(case['gold'], expanded=False)
                if case['annotation_notes']:
                    st.caption(case['annotation_notes'])
                st.caption('Draft labels written before inference. Not independently reviewed. Reserved evaluation cases are not loaded in this demo.')
    else:
        body = st.text_area("Email", height=220)
        with st.expander("Email context · optional"):
            html = st.checkbox("HTML input")
            sent = st.text_input("Sender timestamp (optional, ISO with UTC offset)")
            zone = st.text_input("Sender timezone (optional, e.g. Asia/Kolkata)")
        messages = [{"id": "pasted-1", "body": body, "content_type": "text/html" if html else "text/plain", "sent_at": sent or None, "timezone": zone or None}]
    st.divider()
    approach = st.selectbox("Analysis method", ["baseline", "improved", "structured"], format_func=method_names.get,
                           help="Baseline means the simpler method used for comparison. Structured AI extracts facts and relationships directly. Previous AI selects sentences. Both use the same pretrained model.")
    configured_model = (os.getenv('OLLAMA_MODEL', 'qwen2.5:3b') if os.getenv('MODEL_PROVIDER', 'ollama') == 'ollama'
                        else os.getenv('LLAMACPP_MODEL', 'Qwen2.5-0.5B-Instruct-Q4_K_M'))
    with st.container(border=True):
        if approach != 'baseline':
            st.markdown('**AI MODEL + RULE VALIDATION · MAIN SYSTEM**')
            st.write('Configured model: ' + configured_model)
            st.caption('Configured choice · Actual model use is shown after analysis.')
    
        else:
            st.markdown('**RULES ONLY · RESEARCH BASELINE**')
            st.caption('Programmed patterns only. No model runs in this mode.')
    input_signature = hashlib.sha256(json.dumps({'messages': messages, 'approach': approach}, sort_keys=True).encode()).hexdigest()
    if st.session_state.get('result_input_signature') != input_signature:
        st.session_state.pop('result', None)
    if st.button("Analyse", type="primary", use_container_width=True):
        st.session_state.pop("result", None)
        try:
            result = analyse_with_live_usage(AnalysisRequest(messages=messages, approach=approach), configured_model)
            st.session_state.result = result.model_dump(mode="json")
            st.session_state.result_input_signature = input_signature
        except ModelUnavailable:
            st.error("The local model is unavailable, timed out, or returned invalid output. No fallback result was substituted. Check the runtime or retry with a shorter email.")
        except ValueError:
            st.error("Invalid input. Check timestamp, timezone, and input size.")
    if st.button("Clear analysis", use_container_width=True):
        st.session_state.pop("result", None)
        st.rerun()
    with st.expander('How the AI works'):
        st.markdown('**Structured AI:** Qwen extracts grouped tasks, people, meeting details and a rewritten summary as JSON. Validation checks exact evidence, removes unsupported fields and normalizes supported dates.\n\n**Previous AI:** Qwen selects sentences; rules build the task fields.\n\n**Rules only:** The original comparison baseline; no model runs.')
        st.caption('Pretrained inference, not training. Rewritten summaries and contextual links require review. No calibrated confidence scores.')
    st.caption('Private by default: selected text is processed locally. This demo does not save emails. Use fictional or consented data.')
    st.caption('Current project scope: this local web demo. Chrome extension and Gmail connection are future work.')
with right, st.container(key='result-panel'):
    st.subheader('Analysis workspace')
    if "result" in st.session_state:
        result = st.session_state.result
        st.caption('Analysis complete · Review the source before acting.')
        with st.container(border=True):
            if result['approach'] != 'baseline':
                st.markdown('**AI INFERENCE COMPLETED · MODEL + RULE VALIDATION**')
                st.subheader(result['model'] or 'Model identifier not reported')
                st.caption('Structured AI: the model extracts tasks, owners, event links and summary; validation checks source evidence. Previous AI: the model selects sentences and rules extract fields. Method: ' + result['approach'])
            else:
                st.markdown('**BASELINE COMPLETED · NO AI MODEL USED**')
                st.caption('This result was produced by programmed rules. Switch the method above to run the model on the same email.')
            timing, tasks_count, events_count = st.columns(3)
            timing.metric('Processing time', f"{result['latency_ms']/1000:.2f} s" if result['latency_ms'] >= 1000 else f"{result['latency_ms']:.1f} ms")
            tasks_count.metric('Action items', len(result['tasks']))
            events_count.metric('Events', len(result['events']))
            st.caption('Processing time covers the NLP pipeline, including local model inference when selected; it is not a model-only speed benchmark.')
            if result['approach'] != 'baseline':
                st.caption(f"Input tokens: {result.get('input_tokens') if result.get('input_tokens') is not None else 'Not reported'} · Output tokens: {result.get('output_tokens') if result.get('output_tokens') is not None else 'Not reported'} · Local inference · No calibrated confidence score")
        if result.get('model_http_ms') is not None:
            with st.expander('Runtime measurements'):
                st.write(f"Model request wall time: {result['model_http_ms']/1000:.2f} s (includes runtime/transport)")
                st.write(f"Server prompt processing: {result.get('model_prompt_ms')} ms · generation: {result.get('model_generation_ms')} ms")
                st.caption('Server timings when available; total processing also includes validation. Finish reason: ' + str(result.get('model_finish_reason')))
        incomplete = [note for note in result['ambiguities'] if note.startswith('AI extraction is incomplete:')]
        for note in incomplete:
            st.error(note)
        sections = st.tabs(['Summary', 'Action items', 'Events', 'Review notes'])
        with sections[0]:
            st.subheader("Summary")
            st.caption('AI-written summary with source evidence; verify interpretation.' if result['approach'] == 'structured' else 'Selected source sentences, not a rewritten summary.')
            if result['approach'] == 'structured' and not result.get('summary_claims'):
                st.info('No supported summary returned. Review the original email.')
            for claim in result.get('summary_claims', []):
                st.text(claim['text'])
                with st.expander('Summary evidence'):
                    for e in claim['evidence']:
                        st.text(e['message_id'] + ': ' + e['quote'])
            for e in result["summary"]:
                st.write(e["quote"])
                st.caption(e["message_id"])
        for title, key in [("Action items", "tasks"), ("Events", "events")]:
            with sections[1 if key == 'tasks' else 2]:
                st.subheader(title)
                if not result[key]:
                    st.caption("None detected. Review the source for missed information.")
                for i, item in enumerate(result[key]):
                    with st.container(border=True):
                        st.write(item.get("action") or item.get("title") or item.get("description"))
                        if key == 'tasks':
                            st.caption(f"Owner: {', '.join(item.get('owners', [])) or item['owner'] or 'Not resolved — review email'} · Status: {item['status']}")
                            if item.get('owner_group'):
                                st.caption('Group wording: ' + item['owner_group'] + ' — named owners may not list every member')
                            if item.get('arrival_local'):
                                st.write('Suggested arrival (source-local time): ' + item['arrival_local'])
                                st.caption('Calculated from the model-linked meeting; review the relationship and timezone.')
                            if item['deadline_text']:
                                st.write(f"Deadline wording: {item['deadline_text']}")
                                st.caption(f"Calendar date: {item['deadline'] or 'Needs review'} (no time conversion)")
                        else:
                            st.write(f"Status: {item['status'].replace('_', ' ').capitalize()}")
                            if item.get("participants"):
                                st.caption("Named participants: " + ", ".join(item["participants"]))
                            for detail in item.get("details", []):
                                st.text(detail["quote"])
                            zone_label = item['timezone'] or ((item.get('timezone_raw') + ' — region needs confirmation') if item.get('timezone_raw') else 'Needs review')
                            st.caption(f"Current schedule: {item['date'] or item['date_text'] or 'Not specified'} · {item['time_text'] or 'Not specified'} · {zone_label}")
                            if item.get('original_schedule'):
                                old = item['original_schedule']
                                st.caption(f"Previous schedule (no longer current): {old['date'] or old['date_text'] or 'Not specified'} · {old['time_text'] or 'Not specified'} · {old.get('timezone_raw') or old['timezone'] or 'Needs review'}")
                        with st.expander("Supporting evidence"):
                            for e in item["evidence"]:
                                st.text(f'{e["message_id"]}: {e["quote"]}')
                        for requirement in item.get('requirements', []):
                            st.write('Include in this task:')
                            st.text(requirement['quote'])
                        with st.expander('Technical details (JSON)'):
                            st.json({k: v for k, v in item.items() if k != 'evidence'}, expanded=False)
        with sections[3]:
            st.caption('Notes explain missing context or uncertain interpretation. A note is not automatically proof of an error.')
            for note in result['ambiguities']:
                if note not in incomplete:
                    st.warning(note)
        st.download_button("Export JSON", json.dumps(result, indent=2), "mailmind.json", "application/json")
    else:
        st.html('<div class="mm-empty"><div class="mm-empty-icon">✉</div><h2>A clearer inbox starts here.</h2><p>Select an email and click Analyse. Your summary, action items and meeting details will appear here.</p><div class="mm-guide"><span>01 · Read</span><span>02 · Analyse</span><span>03 · Verify</span></div></div>')
        st.info('Demonstrating the AI? Choose Structured AI on the left. After it runs, this panel shows the model used and measured processing time.')
