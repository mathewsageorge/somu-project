# Delivery status

**12 October 2026 - Loading activity update:** A floating animated activity card stays visible during Analyse, with elapsed time and live RAM/GPU samples. Code callbacks report preparation, local runtime waiting and returned-output validation. No invented percentage or ETA. Latest suite: **192 passing tests**. A live Case 22 check returned unchanged extraction content (3 tasks, 1 event) in 62.38 s. This is not a controlled latency comparison. See [verification notes](results/LOADING-ACTIVITY.md). Chrome/Gmail remain future scope.

## Latest scope and live monitor — 12 October 2026

| Feature | Current status |
|---|---|
| Submitted product | Local Streamlit web application and Python NLP pipeline |
| Chrome extension integration / Gmail connection | Future scope; exploratory source retained |
| Deploy button | Hidden in local demo; browser verified |
| Live resources | RAM used/total, GPU-0 activity and VRAM used/total; about 2 s updates, including active inference; laptop-wide readings |
| Software verification | 187 tests passed, one existing deprecation warning |
| Live model verification | Case 22 still 3 tasks / 1 event; 51.25 s; export schema/evidence checked; observed GPU 0% → 33% → 0% |
| Report / slides | Scope and monitoring updated; historical NLP scores/benchmarks unchanged |

See [scope/monitor notes](results/LIVE-RESOURCES-AND-SCOPE.md). Older entries below describe previous submission scope.

## Submission release: 12 October 2026

| Area | Final verified status |
|---|---|
| Local model | Qwen3.5-4B-Q4_K_M unchanged; no fine-tuning |
| Software checks | 177 Python tests passed; extension TypeScript/build passed |
| Live Streamlit | Case 22 preview, 3 tasks, correct collective owners, 14:45 arrival, 1 rescheduled event/history/logistics, JSON export verified; 53.81 s |
| Latest development evaluation | 8 fictional inputs, 11 labelled tasks; precision 0.846, recall 1.000, F1 0.917; two false positives remain |
| Matched fields | Owner sets 11/11; explicit normalized deadlines 4/4; not overall accuracy |
| Timing comparison | Case 22 medians: Previous AI 7.12 s, early structured 20.41 s, final structured 49.99 s; two repeats; uncontrolled cache/power/thermal conditions |
| Submission files | 20-page PDF + editable Markdown; 19-slide PowerPoint with notes; all pages/slides rendered and inspected |
| Google/extension integration | Build checked; account OAuth/Gmail flow and latest Chrome rendering remain unverified |
| Optional future work | Tasks/Calendar creation, fine-tuning, independent real-email study |

See [submission update](results/SUBMISSION-UPDATE.md) and [demo/viva guide](submission/DEMONSTRATION-AND-VIVA.md). Earlier entries retain version-specific history and superseded numbers.

## Latest: Case 22 structured update, 12 October 2026

| Area | Verified status |
|---|---|
| Model | Same Qwen3.5-4B-Q4_K_M; no fine-tuning or replacement |
| Case 22 extraction | Three tasks, correct collective owners, 14:45 source-local arrival, named rescheduled event with history/logistics |
| Software checks | 173 Python tests passed; extension TypeScript/build passed |
| Live demo | Restarted on 8502; sample preview, structured analysis, task/event display and JSON export verified |
| Development evaluation | Eight inputs; remaining summary, attribution and conditional-task errors documented |
| Latency | Updated structured median 59.45 s, earlier structured 26.18 s, sentence selection 9.23 s; two repeats each |
| Compatibility | Baseline and previous AI preserved; older structured snapshot available to evaluation harness |
| Extension and Google | Updated rendering build-checked; not newly browser-verified; Gmail credentials/integration still unverified |
| Research limitation | Inspected fictional development data, not new held-out or real-email evidence |

See [Case 22 report](results/CASE22-REPORT.md), [raw comparison](results/case22-comparison.json) and [browser verification](results/case22-browser-verification.md). This is a partial improvement, not a complete semantic validation system. Historical status entries follow.

## Latest: model-led structured extraction, 11 October 2026

Added a third method using the unchanged Qwen3.5-4B-Q4_K_M. It extracts grouped tasks, multiple contextual owners, event associations and natural summary claims directly; shared rules only validate evidence/fields and normalize supported dates. Both earlier methods remain available. All 161 Python tests and the extension build pass; nine development inputs ran through all three methods. Live Streamlit model execution, three owners, 10:20 arrival, meeting and JSON export were verified. New extension rendering was build-checked, not browser-tested. Gmail remains unverified.

Measured improvements and limitations are in [the comparison report](results/STRUCTURED-EXTRACTION-REPORT.md). Do not interpret historical exact-span F1 as a complete semantic accuracy measure, or development results as unseen performance.

## Latest: manual case 21 grouping, 11 October 2026

Aisha's linked testing/observations task now retains its shared October 12 deadline; Rahul's report retains the exact inclusion requirement. Live AI returns three task groups and one event; baseline returns two tasks and one event because it still misses attendance. Qwen is unchanged. Shared-rule attribution is explicit. 142 Python tests and extension build passed. Attendance ownership/time and summary coverage remain unresolved. See [before/after details](results/MANUAL-21-GROUPING.md).

## Latest: light workspace redesign, 11 October 2026

Replaced the Streamlit banner/sidebar layout with side-by-side email and analysis panels, compact branding, and result tabs. Model identity and timing remain prominent. Verified desktop/narrow layouts, live AI results and expandable evidence; 23 relevant tests passed. See [redesign notes](results/WORKSPACE-REDESIGN.md). NLP behavior is unchanged.

## Latest: presentation UI and shared deadlines, 8 October 2026

Teacher-facing Streamlit UI now highlights completed AI runs, the configured model identifier used, measured pipeline time and token counts, and plainly distinguishes the rules-only baseline. Live browser AI demonstration verified. Cases 16/18 now produce one linked task each with preserved shared deadlines in both methods; case 16 retains its missing-year uncertainty. All 128 Python tests passed. See [report](results/PRESENTATION-AND-GROUPING.md). Summary completeness, general dependencies and arrival interpretation remain open; no new unseen accuracy claim.

## Latest: provisional case 19 rescheduling fix, 8 October 2026

Both methods now return one rescheduled event for the supplied case-19 reconstruction, retaining current and previous schedules and unresolved raw IST. Streamlit and extension display the status/history. All 114 Python tests passed; extension build and real MV3/FastAPI/local-model browser checks passed for both methods and JSON export. The demo on port 8502 was restarted. See [change report](results/EVENT-STATE-UPDATE.md). This is a narrow same-message rule, not general event coreference. Cases 16/18 task grouping and remaining summary/arrival issues are still open. Historical reserved results below describe the previous frozen code, not this changed version.

## Latest: first reserved evaluation completed, 8 October 2026

Verified and froze the current NLP source, local model health/identifier and model weight hash before executing both approaches on the 12 previously unrun reserved fictional cases. No NLP changes were made after examining their output. AI + rules: 12/13 task records, no extras, F1 0.960; rules: 9/13, no extras, F1 0.818. Correct task status among matched records: AI 9/12, rules 7/9. Both detected all four events. Paraphrased cancellation and deadline-update failures remain. See [final reserved report](results/FINAL-RESERVED-EVALUATION.md).

These are same-author fictional execution fixtures, not a blind independent benchmark. Human summary ratings and independent label review remain pending. The reserved split is now consumed and must not be described as unseen for a later version. Earlier “reserved unrun” statements below describe historical states. The demo still excludes reserved cases. The prior 99-test software result remains valid for unchanged code; this turn verified artifact integrity rather than rerunning software tests. Gmail OAuth remains unverified without user configuration.

## Latest: cancellation/completion tracking, 8 October 2026

Added conservative lifecycle rules that update earlier matching tasks from later explicit cancellation/completion sentences, even if the model labels the update informational. No new task is invented by the status pass. Ambiguous targets require review; exact update evidence is retained and summaries prioritise status updates. Model prompt examples now distinguish explicit withdrawals from no-action notices. No fine-tuning was performed.

All 99 Python tests passed. On the same 24 inspected development cases, final AI task detection is 22/22 with no extras and 22/22 correct matched-task statuses; rules remain 20/22 detected, now 20/20 correct matched-task statuses. This is **tuned development performance**, not unseen accuracy. The 12 reserved cases remain unrun. See [before/after report](results/TASK-STATE-UPDATE.md) and `results/evaluation-v2-task-state-final/results.json`. Earlier sections describe historical versions.

The running demo on port 8502 was restarted and browser-verified with both the cancellation and completion examples using the AI method, including final status, summary and completion evidence. Records: `results/task-state-browser.json` and `results/task-state-browser.png`.

## Latest UI correction: readable example preview, 8 October 2026

Selecting a fictional example now displays its decoded email text immediately above the method and Analyse controls, with separate cards for thread messages. Raw JSON is moved into a technical-details expander, and expected answers remain separate. The example selector is disabled in Paste email mode. No NLP or evaluation labels changed. All five existing demo tests passed (`results/python-tests-email-preview.xml`), and the selected email was verified in the live browser (`results/selected-email-preview.png`).

## Latest: broader labelled evaluation, 8 October 2026

Added 24 fictional development cases (22 labelled task records, four events) and 12 reserved cases, with annotations frozen before inference. Both current methods completed development evaluation without tuning the NLP implementation during the run. Rules: task precision 1.000, recall 0.909, F1 0.952; AI plus rules: precision 1.000, recall 0.955, F1 0.977. Both detected four/four events. The AI missed a cancellation and both methods failed to mark a completed historical request as completed. Exact-span scores do not prove real-world accuracy or correct task status.

Reserved cases remain unrun and excluded from the demo. Their labels are same-author, visible execution fixtures, not a blind external benchmark. Human factuality/coverage worksheets are prepared but unfilled; independent annotation and agreement are pending. See [testing guide](docs/EVALUATION-V2-GUIDE.md), [draft development answer key](data/evaluation_v2/DEVELOPMENT-ANSWER-KEY.md), and [actual report](results/evaluation-v2-development/REPORT.md). Frozen source, predictions and hashes are beside the report.

The demo exposes the 24 development examples and their expected answers. Changing input or approach clears stale results. All 79 Python tests passed, including frozen-label integrity, reserved-run protection, event-field errors, contextual example loading and stale-result clearing. One existing Starlette test-client deprecation warning remains. Evidence: `results/python-tests-evaluation-v2.xml`. No Google credentials or training were needed for this step.

The live demo was browser-checked with `v2-dev-01`: the expected-answer expander, two named task cards, their separate dates and empty event list were verified. Evidence: `results/evaluation-v2-development/browser-check.json` and `demo-check.png`. This is an agent-driven interface check, not a human usability study.

## Latest: rescheduling and contextual tasks, 8 October 2026

Fixed the supplied rescheduled-review development case: three grouped tasks and one meeting with the current 18 October date. Early arrival is calculated as 10:15 local time, with explicit review notes and exact contextual evidence; missing task years and unconfirmed IST remain unresolved. The updated prompt and deterministic context rules are documented in [the regression report](results/RESCHEDULED-REVIEW.md). No training was performed.

All 71 Python tests passed. Live local 4B inference and both methods on the 24 previously inspected fictional regression cases were rerun. Known cancellation/status and deadline-text errors remain; this is not an independent accuracy estimate. Historical comparisons below predate the new prompt/rules and should not be presented as results of this version.

Live browser verification on port 8502 confirmed three task cards, one current meeting, exact owners for the named requests and reviewable contextual attendance. Evidence: `results/rescheduled-review-browser-check.json` and `results/rescheduled-review-browser.png`. The demo and local model were restarted after the interrupted session; no Google integration was exercised during this check.

## Latest: Qwen3.5-4B comparison, 8 October 2026

Downloaded the pinned Unsloth Q4_K_M conversion of Qwen3.5-4B and official llama.cpp b11443 CUDA runtime; all three SHA256 checks passed. Live inference runs on the RTX 3050 Laptop GPU (4096 MiB), with 24 GPU layers and 8192-token context; total observed GPU memory use after inference was 2408 MiB. No training was performed.

On the same 24 previously inspected fictional cases, the old model detected 15/18 labelled tasks with four false tasks; the 4B model detected 16/18 with none. Both detected all five events. These small reused sets are regression evidence, not an independent test or real-world performance claim. On the longer user email, the 4B model produced three task records and one meeting but still omitted attendance, reply, cancellation and report-content instructions. Cross-sentence owners remain unresolved. See [comparison report](results/MODEL-SIZE-COMPARISON.md).

The local experimental AI configuration now points to the 4B model on port 8082; Rules only remains the application default. Added explicit review warnings for unclassified source sentences and no-action labels that conflict with request/cancellation patterns. These reporting-only changes followed the frozen comparison and do not change model inputs or extracted task/event records. The comparison source snapshot is `results/model-comparison-source.zip`. All 58 Python tests passed (`results/python-tests-qwen35.xml`); one existing test-client deprecation warning remains. The live demo on port 8502 was browser-verified: the displayed 4B model, three task records, one event, incomplete-analysis banner and four disagreements were checked (`results/qwen35-browser-check.json`, screenshot `results/qwen35-demo-review.jpg`). Older sections below describe prior versions.

## Latest: longer-email failure, 7 October 2026

The user's project-review email reproduced a serious AI classification failure. Parser, calendar-date/deadline handling and conservative event-label checks were repaired; the demo now prominently flags rejected AI labels and shows task status/deadlines. **The AI still misses valid tasks on this email and is not ready for reliable use.** Owners requiring cross-sentence reasoning remain unresolved. No model training was performed. All 51 Python tests passed, and the live demo's incomplete-result warning was verified. See [failure report](results/PROJECT-REVIEW-FAILURE.md) for before/after predictions, regression metrics and limitations. Earlier results below are historical and do not demonstrate accuracy of the current version.

## Latest: model instructions revision, 7 October 2026

The experimental model now has prompt examples and an internal `none` class for non-actionable sentences. The live demo correctly separates the tutorial's two tasks and one event. On 12 newly authored diagnostic cases it found 6/6 tasks with 2 false tasks and 4/4 events with no false events. These are small synthetic same-author cases, not independent validation. Development task recall and thread status handling still have regressions; the rule baseline remains default. See `results/MODEL-UPDATE.md`, the full `event-challenge-v3.json`, and `python-tests-model-v3.xml` (39 tests passed). No model weights were trained or changed. Older results below describe earlier versions.

## 7 October 2026 parsing correction

Fixed pasted sentences joined without spaces after punctuation (for example `2026-10-15.Ravi`). The exact user-reported email now produces two tasks with separate owners/deadlines and one event. Source text is not rewritten; evidence remains an exact substring. Added regression coverage for joined/spaced/newline inputs and for email addresses, URLs, filenames, titles and numeric versions. This remains a heuristic segmenter, not a complete multilingual sentence parser.

All 38 Python tests passed, including the Streamlit pasted-input regression (`results/python-tests-oct7.xml`). The corrected result was also checked in the running demo. Original research artifacts below remain dated 6 October and are historical; they are not model measurements of the revised parser. A separate baseline regression artifact records the post-fix held-out check. Google and model integration verification boundaries remain unchanged.

Verified on 6 October 2026. No Google credentials were supplied or fabricated.

| Feature | State | Evidence / remaining work |
|---|---|---|
| Strict schema and evidence validation | Working, automated tests passed | Pydantic validation, exact quotes/IDs, required nullable output fields, calendar-date validation |
| Baseline task/event extraction | Working, evaluated | Actual 16-case test results; known indirect-request and paraphrased-cancellation errors |
| Improved candidate using local Qwen/llama.cpp | Working, live inference evaluated and browser-tested | Pinned model/runtime hashes, real development/test predictions and extension-to-backend-to-model check; weaker overall F1 than baseline |
| Ollama adapter | Implemented, contract tested | No live Ollama process/model used in verification |
| FastAPI local service | Working, tested | Authentication, origin, size, safe errors and real browser integration |
| Streamlit demo | Working, automated AppTest passed | Fictional analyse/clear flow; manual interaction not separately verified |
| TypeScript MV3 extension source/build | Working, typechecked and loaded | `extension/dist`; real isolated headless Chromium extension service worker/page |
| Analyse/evidence/edit/dismiss/copy/export/clear | Working, browser-tested | Actual backend; edited-original retention and dismissed export filtering checked |
| Responsive layout | Checked | Browser 360px overflow assertion; captured screenshot visually inspected |
| Chrome toolbar docked side-panel interaction | Implemented, partially verified | Extension loaded; panel page tested directly. Manual toolbar opening/docking still to check in user's Chrome |
| Gmail OAuth and selected message/thread fetch | Implemented; live check blocked | Needs Cloud OAuth client bound to extension ID, consent/test user and dedicated test account |
| Gmail expiry/denial/MIME handling | Mock-tested | 401 retry, 403, denied authorization, UTF-8 MIME body selection and attachment exclusion; not live account evidence |
| Automatic currently-open Gmail detection | Deliberately unavailable | Supported explicit API search/selection instead; no DOM scraping |
| Research data and evaluation | Delivered, executed | 12 dev / 16 test fixtures, labels, split hashes, per-case predictions, field/evidence/summary proxies |
| Human summary factuality and real-email study | Not conducted | Consent/annotation/blinded-evaluation plan in docs/RESEARCH.md |
| Google Tasks / Calendar creation | Optional, not implemented | No write scopes or creation endpoints; local JSON export is working |
| Storage/deletion | No persisted analyses by default | Clear panel/session result; user removes own downloads/clipboard. Evaluation persists only supplied fictional fixtures |
| Public distribution / Google verification | Blocked pending review | Restricted Gmail scope; no approval or distribution claim |

Automated Python evidence: `results/python-tests.xml`. Browser evidence: `results/browser-tests.json`. Experimental evidence: `results/test_results.json` and `results/EXPERIMENTS.md`. The screenshot is `results/panel-demo.png`.

29 Python tests passed. One comprehensive Playwright test covers the listed extension interactions. A FastAPI/Starlette TestClient deprecation warning remains; it did not fail tests and indicates a future test-transport migration, not a verified production defect. npm audit at installation reported zero known vulnerabilities for the resolved extension dependencies; this is not a full security audit.
