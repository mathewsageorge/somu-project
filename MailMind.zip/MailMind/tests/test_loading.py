"""Observable phases and UI lifecycle; mock inference is not an NLP evaluation."""
import time
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from mailmind.loading import loading_card
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message
from mailmind.improved import ModelUnavailable

READING = {'sampled_at':'2026-10-12T14:00:00+00:00','ram':None,'gpu':None}


def test_progress_does_not_change_baseline_output():
    request = AnalysisRequest(messages=[Message(id='m',body='Ravi, please review the report by 2026-10-15.')])
    phases = []
    first, second = analyse(request), analyse(request, progress=phases.append)
    assert first.model_dump(exclude={'latency_ms'}) == second.model_dump(exclude={'latency_ms'})
    assert phases == ['preparing','rules','validating','complete']


def test_model_failure_never_announces_validation_or_completion(monkeypatch):
    def post(*args, **kwargs):
        import httpx
        raise httpx.ConnectError('controlled')
    monkeypatch.setenv('MODEL_PROVIDER','llamacpp')
    monkeypatch.setenv('LLAMACPP_URL','http://127.0.0.1:8082')
    monkeypatch.setattr('mailmind.structured.httpx.Client.post',post)
    phases=[]
    with pytest.raises(ModelUnavailable):
        analyse(AnalysisRequest(messages=[Message(id='m',body='Please send the file.')],approach='structured'),progress=phases.append)
    assert phases == ['preparing','model']


def test_loading_explains_zero_and_missing_gpu_and_escapes_model():
    missing=loading_card('model',12,READING,'<script>bad</script>','structured')
    assert 'GPU activity is unavailable' in missing and '<script>' not in missing
    zero={**READING,'gpu':{'utilization_percent':0,'used_mib':2048,'total_mib':4096,'name':'NVIDIA'}}
    shown=loading_card('model',12,zero,'Qwen','structured')
    assert 'No GPU compute was sampled' in shown and '2.00 GiB' in shown
    assert 'not an ETA' in shown and 'token progress is not reported' in shown


@pytest.mark.parametrize('failed',[False,True])
def test_inflight_card_refreshes_and_cleans_up(monkeypatch,failed):
    from mailmind.loading import loading_card as render
    frames=[]
    readings=[]
    result=analyse(AnalysisRequest(messages=[Message(id='m',body='Please send the file.')]))
    result.approach='structured'
    result.model='test-model'
    def sample():
        readings.append(1)
        return READING
    def capture(*args):
        frames.append(args)
        return render(*args)
    def inference(request,progress=None):
        progress('preparing')
        progress('model')
        time.sleep(2.2)
        if failed:
            raise ModelUnavailable('controlled')
        progress('validating')
        time.sleep(.2)
        progress('complete')
        return result
    monkeypatch.setattr('mailmind.resources.sample_resources',sample)
    monkeypatch.setattr('mailmind.loading.loading_card',capture)
    monkeypatch.setattr('mailmind.pipeline.analyse',inference)
    app=AppTest.from_file(str(Path(__file__).parents[1]/'demo.py')).run(timeout=15)
    app.selectbox[1].set_value('structured').run()
    app.button[0].click().run(timeout=15)
    assert not app.exception
    assert 'model' in [f[0] for f in frames]
    assert max(f[1] for f in frames) >= 2
    assert len(readings) >= 2
    # HTML loading card is removed on both success and failure, not left spinning.
    assert not any('<aside class="mm-loading"' in str(e.value) for e in app.get('html') if hasattr(e,'value'))
    if failed:
        assert len(app.error)==1 and 'result' not in app.session_state
    else:
        assert 'validating' in [f[0] for f in frames]
        assert app.session_state.result['model']=='test-model'
