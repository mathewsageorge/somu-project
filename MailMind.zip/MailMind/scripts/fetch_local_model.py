"""Optional ~420 MB download; outputs runtime/weights to an explicitly supplied directory."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import httpx

RELEASE = "b11443"
REVISION = "9217f5db79a29953eb74d5343926648285ec7e67"
FILES = {
    "llama.zip": f"https://github.com/ggml-org/llama.cpp/releases/download/{RELEASE}/llama-{RELEASE}-bin-win-cpu-x64.zip",
    "model.gguf": f"https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/{REVISION}/qwen2.5-0.5b-instruct-q4_k_m.gguf",
}
if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--directory",required=True)
    args=parser.parse_args()
    target=Path(args.directory).resolve()
    target.mkdir(parents=True,exist_ok=True)
    metadata={"runtime_release":RELEASE,"model_revision":REVISION,"files":{}}
    for name,url in FILES.items():
        path=target/name
        if not path.exists():
            print(f"Downloading {name}…",flush=True)
            with httpx.stream("GET",url,follow_redirects=True,timeout=60) as response:
                response.raise_for_status()
                with path.with_suffix('.part').open('wb') as handle:
                    for chunk in response.iter_bytes(1024*1024):handle.write(chunk)
            path.with_suffix('.part').replace(path)
        metadata["files"][name]={"url":url,"bytes":path.stat().st_size,"sha256":hashlib.file_digest(path.open('rb'),'sha256').hexdigest()}
    with zipfile.ZipFile(target/'llama.zip') as archive:
        for entry in archive.infolist():
            resolved=(target/'runtime'/entry.filename).resolve()
            if not resolved.is_relative_to(target/'runtime'):raise ValueError('Unsafe archive path')
        archive.extractall(target/'runtime')
    (target/'download-manifest.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print('Downloaded and recorded SHA256 checksums. Runtime and model are external dependencies.',flush=True)
