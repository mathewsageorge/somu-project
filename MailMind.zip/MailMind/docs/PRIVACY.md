# Privacy and threat model

Default processing is local. Gmail body retrieval happens only after selecting a message or thread and clicking Analyse. Explicit search retrieves up to ten headers to enable selection. Gmail.readonly is broader than this application behavior, so the scope is not a technical guarantee that a compromised extension cannot read other mail.

Google access tokens remain in Chrome Identity and are used directly with Google. No client secret exists in the extension. OAuth client IDs and extension public keys are public identifiers, not secrets. Local backend pairing tokens are generated into ignored `.env` and entered into panel memory. No model API key is required; external hosted model providers are intentionally not enabled.

The application does not persist raw emails or analyses. Backend request/response bodies and tokens are not logged. Start Uvicorn with `--no-access-log`, Streamlit without usage statistics, and llama.cpp with `--log-disable`. Third-party runtimes may maintain in-memory caches; stop them to release those buffers. Do not enable debug tracing for private data. This prototype cannot guarantee secure memory erasure, control OS swap/crash dumps or remove Chrome's own Gmail caches.

Clear removes the panel result and evidence DOM; closing the panel releases its memory. Sign out clears Chrome's cached authorization and the panel result/search headers. Revoke additionally calls Google's revocation endpoint; failures are reported and account-settings removal is recommended. Pasted text remains in its input until cleared, switched away and closed, or manually removed. Exported downloads and clipboard content are user-managed copies; delete files and clear the clipboard yourself. Evaluation artifacts intentionally persist fictional source spans. Do not apply the evaluator to real mail without consent to that persistence.

| Threat | Controls | Remaining risk |
|---|---|---|
| Prompt injection in email | No tools/secrets in model context; email is labelled untrusted; only existing IDs accepted; common attack sentences excluded | Detection patterns are incomplete; a model may misclassify valid source text. |
| Hallucinated extraction | Exact evidence and field-span checks; deterministic dates; null unknown fields | Supported quotes do not establish correct intent, responsibility or latest state. |
| HTML/script injection | HTML-to-text preprocessing; panel uses textContent; no raw email HTML insertion | Parser bugs and unusual encodings; unsupported bodies fail. |
| Cross-origin local API abuse | Exact origin allowlist, Host validation, random pairing token, JSON only, loopback binding | Local malware or a leaked token can call the service; CORS alone is not authentication. |
| Resource exhaustion | Request/message limits, candidate/prompt limits and network timeouts | Not hardened for hostile multi-user traffic; bind only to loopback. |
| Unauthorized Google writes | No write scopes or Google write endpoints; copy/download are explicit clicks | User can act on an incorrect exported item; evidence review remains essential. |
| Credential leak | No Google token passed to backend, no logging, ignored local config | Compromised browser/dependencies or intentionally enabled debug logging. |

Before real deployment: authenticated TLS transport if leaving loopback, endpoint rate/concurrency controls, dependency and extension security review, formal data retention policy, Google Limited Use compliance review, consent documentation and applicable restricted-scope verification/security assessment. Do not publish this prototype as a verified Google application.
