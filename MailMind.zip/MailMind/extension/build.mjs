import ts from 'typescript';
import {mkdir, readFile, writeFile, copyFile} from 'node:fs/promises';
await mkdir('dist', {recursive:true});
let config = {};
try { config = JSON.parse(await readFile('config.local.json','utf8')); } catch (e) { if(e.code !== 'ENOENT') throw e; }
const manifest = {
  manifest_version:3, name:'MailMind', version:'1.0.0', minimum_chrome_version:'116',
  description:'Local email summaries, action items and exact supporting evidence.',
  permissions:['sidePanel','identity'],
  host_permissions:['http://127.0.0.1/*','https://gmail.googleapis.com/*','https://oauth2.googleapis.com/*'],
  background:{service_worker:'background.js',type:'module'},
  action:{default_title:'Open MailMind'}, side_panel:{default_path:'panel.html'},
  content_security_policy:{extension_pages:"script-src 'self'; object-src 'none'; connect-src http://127.0.0.1:8000 https://gmail.googleapis.com https://oauth2.googleapis.com"}
};
if(config.googleClientId) {
  if(!/^[\w-]+\.apps\.googleusercontent\.com$/.test(config.googleClientId)) throw Error('Invalid OAuth client ID');
  manifest.oauth2 = {client_id:config.googleClientId,scopes:['https://www.googleapis.com/auth/gmail.readonly']};
}
if(config.extensionPublicKey) manifest.key = config.extensionPublicKey;
await writeFile('dist/manifest.json',JSON.stringify(manifest,null,2));
for(const name of ['panel','background','gmail']) {
  const source=await readFile('src/'+name+'.ts','utf8');
  const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}});
  await writeFile('dist/'+name+'.js',compiled.outputText);
}
for(const f of ['panel.html','style.css']) await copyFile(f,'dist/'+f);
const dev = JSON.parse(await readFile('../data/dev.json','utf8'));
await writeFile('dist/demo.json',JSON.stringify(dev[0].messages));
console.log('Loadable extension built in extension/dist (Google OAuth '+(config.googleClientId?'configured':'not configured')+').');
