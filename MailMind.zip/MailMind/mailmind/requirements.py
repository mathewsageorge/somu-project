"""Source-backed adjacent report requirements, disclosed deterministic linking."""
import re
from .schema import Evidence
from .text import sentences, suspicious
from .dates import deadline_text


def link_requirements(tasks, sources, ambiguities):
    for mid, source in sources.items():
        rows = sentences(source)
        for previous, sentence in zip(rows, rows[1:]):
            # Same paragraph, unique occurrences: avoid crossing replies or
            # attaching an identical repeated sentence to the wrong request.
            if source.count(previous) != 1 or source.count(sentence) != 1:
                continue
            gap = source[source.index(previous)+len(previous):source.index(sentence)]
            if '\n' in gap or suspicious(sentence) or deadline_text(sentence):
                continue
            if not re.fullmatch(r'Please include (?:any |all |the )?(?:issues|findings|results|observations|references)(?: [^.!?]+)?\.', sentence, re.I):
                continue
            if re.search(r'\b(?:and|or|if|unless|instead|not|meeting|workshop|send|submit|prepare|review)\b', sentence, re.I):
                continue
            parents = [t for t in tasks if t.evidence[0].message_id == mid and t.evidence[0].quote == previous
                       and t.status == 'pending' and re.search(r'\b(?:report|document|summary|slides)\b', t.action, re.I)]
            if len(parents) != 1:
                continue
            parent = parents[0]
            requirement = Evidence(message_id=mid, quote=sentence)
            parent.requirements.append(requirement)
            parent.evidence.append(requirement)
            tasks[:] = [t for t in tasks if not (t.evidence[0].message_id == mid and t.evidence[0].quote == sentence)]
            ambiguities.append(f'{mid}: Requirement linked by a shared rule to the preceding deliverable: {sentence} Review this contextual link; the model may not have selected the requirement.')
