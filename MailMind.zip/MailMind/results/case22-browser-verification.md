# Live Streamlit verification — 12 October 2026

Restarted the demo on 127.0.0.1:8502 after implementation, then used the existing in-app browser tab. Selected the new Case 22 fictional example and verified the complete original email appeared before analysis. Selected Structured AI and ran the unchanged local Qwen.

Observed: 3 tasks and 1 event; Priya/Kiran deadlines and attached requirements; collective owners Priya/Kiran/Meera; source-local arrival 2026-10-22T14:45. Events tab shows deployment readiness meeting, Rescheduled, participants, unchanged link/agenda, current October 22 at 3 PM IST and previous October 20 at 11 AM IST. Region remains unconfirmed.

Displayed latency: 62.47 s, 1952 input tokens, 1059 output tokens. This separate browser run is not part of the two-repeat timing median. Exported JSON through the download button and validated the downloaded file using Analysis and validate_evidence against the exact fixture. Saved copy: `case22-browser-export.json`.

Screenshot: [event view](case22-browser.png). Browser interaction verifies functionality, not semantic correctness. Summary omissions match the research report. Extension rendering and Gmail were not browser-tested during this update.
