"""Package source, loadable extension and research artifacts; never include local secrets."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parents[1]
target=root.parent/'MailMind.zip'
excluded={'node_modules','__pycache__','.pytest_cache','.venv','work','.git','.cache','test-results','playwright-report'}
files=[]
for path in sorted(root.rglob('*')):
    rel=path.relative_to(root)
    if not path.is_file() or excluded.intersection(rel.parts):continue
    if path.name in {'.env','config.local.json'} or path.suffix in {'.log','.key','.pem','.pyc'}:continue
    files.append(path)
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.name!='release-manifest.json'}
(root/'release-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
files=[p for p in files if p.name!='release-manifest.json']+[root/'release-manifest.json']
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for path in files:archive.write(path,'MailMind/'+path.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert not any(n.endswith('/.env') or 'node_modules/' in n or n.endswith('/config.local.json') for n in archive.namelist())
print(f'Packaged {len(files)} files, {target.stat().st_size:,} bytes, verified ZIP integrity and exclusions.')
