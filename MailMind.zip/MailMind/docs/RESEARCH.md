# MTech report and experimental protocol

First reserved evaluation is now complete: `results/FINAL-RESERVED-EVALUATION.md` reports the frozen version on 12 previously unrun fictional cases, with source/model verification and untouched labels. AI task F1 is 0.960 versus rules 0.818, but matched-task status accuracy is 9/12 versus 7/9 and paraphrased updates remain unresolved. This reserved execution is not independent human-annotated or blind external validation. The split is now consumed; use fresh data for a later tuned version. No human factuality scores are available. Earlier “unrun” statements describe the preceding development phase.

Latest development iteration: `results/TASK-STATE-UPDATE.md` documents explicit lifecycle rules, revised model cancellation instructions, exact update evidence and summary prioritisation. The same v2 development data used to diagnose errors were reused after fixes (AI 22/22 task records, correct matched statuses; rules 20/22, correct matched statuses). This is development tuning. Reserved data remain unrun; historical results below are preserved rather than overwritten.

## 8 October 2026 evaluation expansion

The current additional diagnostic study is documented in [EVALUATION-V2-GUIDE.md](EVALUATION-V2-GUIDE.md) and `results/evaluation-v2-development/REPORT.md`: 24 fictional development cases, 12 reserved cases kept unrun, labels and source frozen before inference. Qwen3.5-4B Q4_K_M is the current local candidate. Both methods share unchanged field/context rules during this comparison. The broader development set also scores event date/time/timezone/status on matched events; earlier seed metrics did not. Compound and contextual annotation conventions are versioned separately in `data/evaluation_v2/ANNOTATION.md`. Do not pool the datasets as though their annotation policies were identical.

The new live run detects 20/22 task records with rules and 21/22 with the model, with no extras; task-state errors remain. Both return 100% exact evidence validity and 27/27 summary key-span inclusion, but these values cannot establish semantic factuality: obsolete source requests can still be quoted and completion/cancellation can be mishandled. Human summary ratings are blank, independent annotation is pending, and no real-email generalization claim follows. The remainder of this document describes the original protocol and historical experiments.

## Title
MailMind: Email Summarization and Action Item Extraction with Evidence-Constrained Local NLP

## 1. Problem and research questions

Users need a concise account of a selected email/thread, what must be done, by whom, when, and which original words support that interpretation. Distinguish an actionable request from an announcement, preserve uncertainty, and avoid autonomous inbox actions.

RQ1: Does pretrained sentence selection improve action detection precision/recall over explicit request/verb patterns on identical inputs? RQ2: How accurately are named owners, deadline wording and normalized deadlines extracted independently? RQ3: Does exact-source evidence constrain fabricated text while retaining important summary content? RQ4: How do thread revisions, indirect requests and missing date context affect errors and latency?

Hypotheses are empirical, not claims of novelty. The project combines established extraction and validation techniques in a privacy-oriented prototype.

## 2. Prior work reviewed

- [Scerri et al., Classifying Action Items for Semantic Email (2010)](https://aclanthology.org/L10-1018/) studies action classification through speech-act distinctions, relevant to separating task assignments and meeting proposals.
- [Loza et al., Building a Dataset for Summarization and Keyword Extraction from Emails (2014)](https://aclanthology.org/L14-1028/) provides annotated single emails/threads and annotation methodology. It motivates explicit dataset and agreement reporting.
- [Smart To-Do: Automatic Generation of To-Do Items from Emails (2020)](https://aclanthology.org/2020.acl-main.767/) uses task-focused selection and generation for email to-do items. MailMind does not reproduce its training/evaluation setup.
- [EmailSum: Abstractive Email Thread Summarization (2021)](https://aclanthology.org/2021.acl-long.537/) establishes prior work on thread summarization. Its task and data differ from these fictional fixtures.
- [Zhang et al., Focus on the Action (2022)](https://aclanthology.org/2022.findings-acl.323/) studies highlighting and summarization for email actions and faithfulness, directly relevant to evidence-led extraction.
- [MAILEx: Email Event and Argument Extraction (2023)](https://aclanthology.org/2023.emnlp-main.801/) studies events and arguments in email threads, motivating separate event and owner/date handling.

This is a focused review of the cited papers' public descriptions, not an exhaustive novelty search or reproduced comparison against their systems. Do not claim state of the art from the included experiments.

## 3. Methods

Approach A: canonical visible text → quote/signature filtering → sentence segmentation → explicit request/verb rules → named-addressee/subject patterns → conservative date normalization → exact-core thread reconciliation → frequency-ranked extractive summary.

Approach B: same preprocessing → pretrained local instruction model selects candidate sentence IDs and task/event labels plus summary IDs → shared field extraction, reconciliation and evidence validation. This is a constrained selection experiment, not unconstrained abstractive generation. The model can improve recall for indirect requests; it can also add false positives. Shared owner/date extraction means differences in those metrics largely follow selection differences.

No task-specific model training, fine-tuning or fabricated confidence scores. Fixed prompt in `mailmind/improved.py`, temperature 0, seed 42, context 8192. The reproducible CPU configuration uses Qwen2.5-0.5B-Instruct Q4_K_M and llama.cpp; Ollama is another configurable adapter. Record exact weights, runtime and prompt hashes with each run. Model limitations and license come from its [official model card](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF); local runtime behavior is documented by [llama.cpp](https://github.com/ggml-org/llama.cpp/tree/master/tools/server).

## 4. Data and experimental design

12 fictional development cases and 16 separate held-out execution fixtures cover multiple owners/tasks, no-action emails, HTML, signatures, quotations, relative/ambiguous dates, threads, changes, meeting announcements and prompt injection. Inputs are identical across methods. Annotation policy and provenance limits appear in `data/ANNOTATION.md`. Test cases are not used for prompt changes after results inspection. The author had access to both splits; there is no independent blind holdout. The tiny, template-related corpus is a smoke benchmark and supports no real-world generalization claim.

## 5. Metrics

Task detection uses **one-to-one exact action-span and source-ID matching**. Precision=TP/(TP+FP), recall=TP/(TP+FN), F1=2PR/(P+R). Missing entities count as false negatives; extra entities count as false positives. A longer task sentence does not get credit for several gold actions. This strict measure penalizes semantically valid boundary variants; report a separately adjudicated relaxed-span metric in future experiments.

Owner, original deadline wording and normalized deadline are evaluated separately with exact accuracy on matched tasks (denominator reported), and non-null field precision/recall/F1 including unmatched tasks. Null-null agreement must not be mistaken for successful extraction. Final status accuracy on aligned tasks exposes cancellations/supersession errors that detection F1 alone hides. Event **detection** is evaluated; the seed gold does not support event argument/timezone accuracy estimates.

Evidence validity is the fraction of displayed quotes matching canonical source text and ID exactly. It tests provenance, not whether the interpretation is correct. Automatic summary coverage is the proportion of annotated key spans included verbatim in the summary, on cases that have summary labels. These short emails often fit entirely into three sentences, making coverage artificially easy. High overlap does not establish factuality or usefulness, particularly after cancellations.

Human summary factuality is **not measured** in this run (`null`). Proposed assessment: two blind raters score each summary claim as supported, contradicted or unsupported, and mark whether the current thread state and key obligations are covered. Report unsupported-claim rate, coverage, compression ratio and agreement. Randomize method order; do not let evaluators see method names. ROUGE may be an additional lexical metric but is not a factuality metric.

Wall-clock inference latency is measured per case with a monotonic timer, including local HTTP overhead for B. These are single-run CPU measurements, not a controlled throughput benchmark; first-request loading and cache effects must be disclosed. API billing is absent for local inference; hardware/electricity cost is unmeasured, so cost is null rather than invented. Provider-reported token usage is retained when returned.

## 6. Results and error analysis

See `results/test_results.json` for actual predictions/metrics, `results/dev_results.json` for development runs, and `results/EXPERIMENTS.md` for the final comparison. Do not substitute contract-test mocks for live model results. Unavailable configurations have no fabricated metrics. State whether each experiment completed, failed or was blocked.

Known baseline failures include indirect requests and unseen verbs. Thread reconciliation cannot reliably connect “we no longer need that document” to a prior request; extractive summary coverage can remain high despite stale-task status. HTML quote removal can omit subsequent inline replies. Owner coreference, vague deadlines, non-English mail, nested MIME/attachments and multilingual sentence boundaries are outside the validated scope. Evidence matching does not solve these semantic errors.

## 7. Consent-based real-email evaluation

Obtain institutional/ethics approval as applicable and informed opt-in consent describing local processing, annotators, retention and withdrawal. Recruit volunteers separately from their academic assessment or employment supervision. Collect only messages participants actively choose and have authority to share, including consent/appropriate handling for other correspondents. Exclude highly sensitive categories from an initial pilot.

Redact names, addresses, organizations, credentials and attachments locally using a participant-reviewed mapping. Preserve consistent pseudonyms and date offsets within threads so ownership and temporal labels remain meaningful. Anonymization is imperfect; store encrypted with access restricted to approved annotators. Separate consent records from examples. Set a deletion date and withdrawal process. Never place real messages in this repository, browser test fixtures, logs or public reports.

Split by participant/thread before annotation to reduce template leakage. Use independent annotators, measure agreement, freeze the model/prompt, and evaluate once on hidden test data. Report domain/language mix and compare performance to the fictional benchmark with uncertainty intervals bootstrapped by thread. Manually review all unsupported claims and wrong-owner/deadline errors. Publish only aggregate metrics and explicitly consented synthetic reconstructions.

## 8. Suggested thesis chapters and appendices

1. Introduction: motivation, scope, research questions and contributions without novelty claims.
2. Literature review: email summarization, action/event extraction, factuality and prompt-injection boundaries.
3. Requirements and system design: component/data-flow diagram, OAuth and privacy rationale.
4. Methods: formal schema, preprocessing, baseline, constrained model selector and normalization policy.
5. Dataset and annotation: fictional provenance, guidelines, split integrity and future consent plan.
6. Experiments: frozen configurations, exact metrics, latency and reproducibility.
7. Results and discussion: measured comparison, per-case errors, threats to validity and limitations.
8. Conclusion and future work: independent annotation, larger models, temporal/coreference improvements and optional confirmed exports.

Appendices: API schema, installation instructions, test evidence, full fictional fixtures, source/model hashes and demonstration script.
