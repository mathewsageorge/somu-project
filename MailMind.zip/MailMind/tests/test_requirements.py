import json
from pathlib import Path
import pytest
from mailmind.pipeline import analyse, materialize
from mailmind.schema import AnalysisRequest, Message, validate_evidence


def run(body):
    return analyse(AnalysisRequest(messages=[Message(id='m',body=body)]))


@pytest.mark.parametrize('activity,outcome',[('UAT testing','observations'),('inspection','findings'),('analysis','results')])
def test_activity_and_outcome_shared_deadline(activity,outcome):
    body=f'Mina, please complete the {activity} and share your {outcome} by 2027-01-12.'
    result=run(body)
    assert len(result.tasks)==1 and result.tasks[0].deadline=='2027-01-12'
    assert result.tasks[0].action==body


@pytest.mark.parametrize('body',[
    'Mina, please complete the testing by 2027-01-10 and share your observations by 2027-01-12.',
    'Mina, please complete the testing and Omar, please share your observations by 2027-01-12.',
    'Mina, please complete the testing and prepare the budget by 2027-01-12.',
])
def test_separate_scope_not_merged(body):
    assert len(run(body).tasks)==2


PARENT='Omar, please prepare the report by 2027-01-12.'
REQ='Please include any issues identified during testing.'


def test_requirement_link_even_when_model_omits_sentence():
    body=PARENT+' '+REQ
    result=materialize([Message(id='m',body=body)],[('m',PARENT,'task')],'improved','fixture')
    assert len(result.tasks)==1
    assert result.tasks[0].requirements[0].quote==REQ
    assert result.tasks[0].deadline=='2027-01-12'
    validate_evidence(result,{'m':body})


@pytest.mark.parametrize('suffix',[
    '\n\n'+REQ,
    ' Please include the results by 2027-01-15.',
    ' Priya, please include the results.',
    ' Please include the results and send the budget.',
])
def test_unsafe_requirements_not_attached(suffix):
    assert not run(PARENT+suffix).tasks[0].requirements


def test_manual21_baseline_contains_two_deliverables_and_requirement():
    data=json.loads((Path(__file__).parents[1]/'data/manual_case_21.json').read_text())
    result=run(data['cases'][0]['body'])
    assert [(t.owner,t.deadline) for t in result.tasks]==[('Aisha','2026-10-12'),('Rahul','2026-10-13')]
    assert result.tasks[1].requirements[0].quote==REQ
    assert len(result.events)==1


def test_requirement_evidence_tampering_rejected():
    body=PARENT+' '+REQ
    result=run(body)
    result.tasks[0].requirements[0].quote='Invented requirement'
    with pytest.raises(ValueError): validate_evidence(result,{'m':body})
