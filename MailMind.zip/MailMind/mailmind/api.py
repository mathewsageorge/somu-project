import hmac
import os
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .pipeline import analyse
from .schema import Analysis, AnalysisRequest
from .improved import ModelUnavailable

load_dotenv()
MAX_BYTES = 700_000


def create_app():
    app = FastAPI(title="MailMind", version="1.0.0", docs_url=None, redoc_url=None)
    origins = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "http://127.0.0.1:5173").split(",") if o.strip()]
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["POST", "GET"],
                       allow_headers=["Content-Type", "X-MailMind-Token"], allow_credentials=False)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "testserver"])

    @app.middleware("http")
    async def guard(request: Request, call_next):
        origin = request.headers.get("origin")
        if origin and origin not in origins:
            return JSONResponse({"detail": "Origin not allowed"}, status_code=403)
        if request.method == "POST":
            expected = os.getenv("MAILMIND_TOKEN", "")
            if len(expected) < 24:
                return JSONResponse({"detail": "Backend pairing is not configured"}, status_code=503)
            supplied = request.headers.get("x-mailmind-token", "")
            if not hmac.compare_digest(supplied.encode(), expected.encode()):
                return JSONResponse({"detail": "Invalid pairing token"}, status_code=401)
            if not request.headers.get("content-type", "").startswith("application/json"):
                return JSONResponse({"detail": "JSON required"}, status_code=415)
            # Bound actual streamed bytes, not only the untrusted Content-Length.
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > MAX_BYTES:
                    return JSONResponse({"detail": "Request too large"}, status_code=413)
            request._body = bytes(body)
        return await call_next(request)

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        # Default validation details can echo private email content.
        return JSONResponse({"detail": "Invalid request. Check fields, timestamps, IDs and size limits."}, status_code=422)

    @app.get("/health")
    def health():
        return {"status": "ok", "storage": "none", "processing": "local"}

    @app.post("/analyse", response_model=Analysis)
    async def analyse_email(request: AnalysisRequest):
        try:
            return await run_in_threadpool(analyse, request)
        except ModelUnavailable:
            raise HTTPException(503, "Local model unavailable or output invalid. See model setup.") from None
        except Exception:
            raise HTTPException(500, "Analysis failed safely. Try a smaller input.") from None
    return app


app = create_app()
