# Loading activity verification - 12 October 2026

## Implemented
- Floating activity card fixed near the top of the viewport, so Analyse below a long email does not hide it.
- Animated indicator with reduced-motion support, elapsed seconds, configured model and actual code phases.
- Optional callback in the existing pipeline and model methods sends fixed phase IDs through a thread-safe queue. Worker code never calls Streamlit.
- Preparing selected input, waiting for local Qwen, then validating returned JSON/evidence/dates. Rules Only reports programmed processing and does not claim model use.
- The model request is non-streaming. Runtime waiting includes queue/transport, prompt processing and generation. The app cannot report token-level progress, percentage complete or ETA.
- Hardware refresh about every two seconds, elapsed display about every second. Following the user's display preference, only the active card shows usage; the initial/idle monitor and idle polling were removed. GPU utilization and VRAM include other applications, not just Qwen. Zero activity differs from unavailable and can coexist with allocated model memory.
- Card clears on success and failure. No new dependencies, model/prompt changes or fine-tuning. No email content or telemetry is logged/persisted by this feature.

## Automated checks
192 tests passed with one existing Starlette/httpx deprecation warning. Evidence: `python-tests-loading-only.xml` after removing the idle monitor. The previous loader checks are retained in `python-tests-loading-ui.xml`.
Five new test cases cover unchanged baseline output with callbacks, stage ordering/failure, escaped model labels and unknown/zero GPU, and active refresh/cleanup after success and failure. Model/UI tests use controlled responses and do not measure NLP accuracy.

## Real browser check
Selected fictional `manual-22-uat-readiness` and Structured AI on the existing localhost:8502 demo. While scrolled to Analyse, the loader appeared at top 64 px and stayed fully within the 575 px viewport. CSS animation `mm-spin` was active. Samples showed 13.2 GiB RAM, 2.34 GiB GPU memory and GPU activity changing around 34-40 percent, with advancing timestamps and elapsed seconds. The screenshot `loading-live-qwen.png` records the active state. GPU returned to zero after completion and `.mm-loading` count was zero. `loading-complete.png` records completion.

Actual Qwen3.5-4B-Q4_K_M returned 3 tasks and 1 event in 62.38 s pipeline time (62.17 s model-request wall time), 2220 input / 1099 output tokens. Exported `loading-browser-export.json` passed the public schema and exact source-evidence validation. Tasks, events, summary claims and review notes match `live-monitor-browser-export.json` exactly. No extraction accuracy improvement is claimed for this UI change.

This is one functional UI run, not a controlled speed or monitoring-overhead comparison. Prior development accuracy figures and repeated latency experiments remain unchanged. CPU load, power/temperature, model cache and other apps were not controlled. Very fast phases may finish before they can be visually read. Missing NVIDIA telemetry remains unavailable. The model does not report live per-token progress. Chrome/Gmail integration remain future scope.

## How to test
1. Refresh localhost:8502, select a fictional email and Structured AI.
2. Click Analyse. Look for the activity card near the top-right (it fits narrow windows too).
3. Watch elapsed time and hardware readings. Explain Qwen request waiting, then returned-output validation; the latter may be brief.
4. Confirm the card disappears and review the result/evidence. Baseline mode should never claim AI inference.

Implementation follows Streamlit's fragment/placeholder guidance: https://docs.streamlit.io/develop/tutorials/execution-flow/create-a-multiple-container-fragment
