# Case 22: design and diagnosis

Date: 12 October 2026. Keep Qwen3.5-4B-Q4_K_M and the loaded runtime unchanged. Keep the baseline and previous sentence-selection AI unchanged. The preceding structured implementation is preserved as `mailmind/structured_legacy.py` for replay, including its observed defects; it is not offered as a recommended UI mode.

## Evidence from the pre-change reproduction

`results/case22-before/results.json` records raw fictional model response, validated output, stop reason, usage, server timing and resource samples. The original user observation was two tasks/one event and 33.54 s. Our new pre-change run returned three tasks/one event, so the exact missing-card symptom was not reproduced. The original JSON and runtime conditions are unavailable. We do not claim byte-for-byte parity.

The reproduced raw response named Priya/Kiran/Meera for the collective task but cited only meeting and instruction rows. The greeting was absent from its evidence. The validator removed unsupported names correctly. The generated summary cited a broad block but omitted the early-arrival evidence; its unsupported number check then rejected the entire single-block summary. These are model citation/output organization failures interacting with intentionally strict validation, not proof that the input was missing or truncation occurred. Finish reason was `stop`, 456 generated tokens against a 3000-token limit.

The schema had no short event title, named participants or model-supplied original schedule. `description_id` deliberately selected the current date-bearing sentence, and the UI used that sentence as a heading. Prompt changes alone could not fix this representation problem reliably.

A separate post-processing defect stripped any trailing uppercase abbreviation from a clock, including PM. Thus '3:00 PM' became '3:00' and the 24-hour fallback produced 02:45. The new clock helper strips only an explicitly supplied timezone token, never AM/PM. Noon, midnight and date rollover tests cover the correction. This change is arithmetic validation, not a new task-detection rule.

## Changes

1. A model-generated summary-fact list supports an uncited-fact review check. An experimental task-planning list was removed after it encouraged over-extraction on counterexamples. Validators do not manufacture replacement tasks. The remaining summary list can be wrong and is not a completeness guarantee.
2. Explicit owner/participant evidence IDs allow the model to cite greeting/group context independently of the instruction or event row. Unknown team membership stays unknown. Whole-name checks reject substring-only matches.
3. Source-backed event title, participants, details and original schedule are available as separate fields. Both interfaces use the title and show schedule history. No duplicate historical active event is required to display the old date.
4. Summary entries are short, individually cited and bounded to 320 characters each; the prompt requests concise coverage of completion, requests, logistics, dependencies and unknown dates. No inline row-number citations are allowed in prose because references belong in the evidence field. Unsupported claims are removed individually, not silently presented as verified.
5. Prompt handling covers collective instructions with omitted meeting nouns, explicit preparation, ambiguous meeting links and insufficient team membership. This is model-driven extraction, not email-specific pattern repair.
6. Runtime metadata separates total pipeline time, HTTP model-request wall time and server prompt/generation timings where available. Normal UI processing does not persist raw model text; the fictional evaluation harness records it explicitly for diagnosis.

## Performance protocol

The harness uses identical messages and model parameters, sequential requests, source hashes and recorded runtime timings. Repeated comparisons rotate method order. The runtime is already loaded; there is no controlled cold-cache reset, exclusive machine reservation or power/thermal control. Token/cache counts and generation rate must be considered alongside latency. GPU/RAM samples are system-wide, not attributable solely to MailMind. No claim that all latency differences are caused by JSON/schema constraints is justified.

See the final results report for actual timings, remaining extraction errors and human-review limitations. No model replacement, fine-tuning or dependency installation is part of this change.
