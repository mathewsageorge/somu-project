"""Compare both methods on the same fictional tutorial email."""
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest

BODY = ('Asha, please send the project report by 2026-10-15.'
        'Ravi, please review the presentation by 2026-10-16.'
        'The team meeting is on 2026-10-17 at 10 am UTC.')

if __name__ == '__main__':
    os.environ['MODEL_PROVIDER'] = 'llamacpp'
    report = {'timestamp_utc': datetime.now(timezone.utc).isoformat(),
              'fictional_email': BODY,
              'expected': {'tasks': 2, 'events': 1}, 'results': {}}
    for method in ['baseline', 'improved']:
        result = analyse(AnalysisRequest(messages=[{'id':'pasted-1', 'body': BODY}], approach=method))
        report['results'][method] = result.model_dump(mode='json')
        print(json.dumps({'method': method, 'tasks': [{'action':t.action,'owner':t.owner,'deadline':t.deadline} for t in result.tasks], 'events':[e.description for e in result.events], 'latency_ms':result.latency_ms}, indent=2), flush=True)
    (ROOT/'results/tutorial-comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
