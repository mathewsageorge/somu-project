from pathlib import Path
import secrets

root = Path(__file__).resolve().parents[1]
target = root / ".env"
if target.exists():
    raise SystemExit(".env already exists; not overwriting")
text = (root / ".env.example").read_text(encoding="utf-8")
target.write_text(text.replace("MAILMIND_TOKEN=", "MAILMIND_TOKEN=" + secrets.token_urlsafe(32)), encoding="utf-8")
print("Created .env. Copy its MAILMIND_TOKEN into the panel pairing field. Never commit .env.")
