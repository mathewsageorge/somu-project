import json
from pathlib import Path
import pytest
from mailmind.pipeline import analyse, materialize
from mailmind.schema import AnalysisRequest, Message, validate_evidence
from mailmind.text import sentences
from mailmind.dates import normalize_date

CASES = json.loads((Path(__file__).parents[1]/'data/manual_review_provisional.json').read_text())['cases']


def run(body):
    return analyse(AnalysisRequest(messages=[Message(id='m',body=body)]))


@pytest.mark.parametrize('case_id,wording,normalized',[
    ('manual-16','Thursday, October 15',None),
    ('manual-18','October 14, 2026','2026-10-14'),
])
def test_provisional_compound_task_both_materialization_paths(case_id,wording,normalized):
    body=next(c['body'] for c in CASES if c['id']==case_id)
    request_sentence=next(s for s in sentences(body) if 'review' in s and 'by ' in s)
    for result in [run(body),materialize([Message(id='m',body=body)],[('m',request_sentence,'task')],'improved','fixture-only')]:
        assert len(result.tasks)==1
        task=result.tasks[0]
        assert task.action==request_sentence
        assert task.deadline_text==wording and task.deadline==normalized
        validate_evidence(result,{'m':body})
    if case_id=='manual-16':
        assert run(body).events[0].date_text=='Monday, October 19'


@pytest.mark.parametrize('body',[
    'Priya, please review the pending issues by 2026-10-12 and update the tracking sheet by 2026-10-15.',
    'Please review the functionality by 2026-10-12 and share your feedback by 2026-10-15.',
])
def test_distinct_deadlines_remain_separate(body):
    result=run(body)
    assert [t.deadline for t in result.tasks]==['2026-10-12','2026-10-15']


def test_named_owners_in_one_sentence_are_not_merged():
    result=run('Priya, please review the issues by 2026-10-12 and Ravi, please update the tracking sheet by 2026-10-15.')
    assert [(t.owner,t.deadline) for t in result.tasks]==[('Priya','2026-10-12'),('Ravi','2026-10-15')]


def test_independent_deliverables_not_merged():
    result=run('Priya, please review the budget and prepare the slides by 2026-10-15.')
    assert len(result.tasks)==2
    assert result.tasks[0].deadline is None


@pytest.mark.parametrize('wording,expected',[
    ('Thursday, October 15',None),
    ('Thursday, October 15, 2026','2026-10-15'),
    ('Friday, October 15, 2026',None),
    ('Thursday, October 15, 2026 at 5:00 PM IST','2026-10-15'),
])
def test_weekday_calendar_consistency_without_year_guessing(wording,expected):
    assert normalize_date(wording,Message(id='m',body='fixture'))[0]==expected


def test_missing_year_remains_unresolved_even_with_other_year():
    result=run('Priya, please review the issues and update the tracking sheet by Thursday, October 15.\nThe meeting is on October 19, 2026 at 10 AM UTC.')
    assert result.tasks[0].deadline is None
