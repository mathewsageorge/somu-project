from datetime import datetime, date
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Message(Strict):
    id: str = Field(min_length=1, max_length=200)
    body: str = Field(min_length=1, max_length=100_000)
    content_type: Literal["text/plain", "text/html"] = "text/plain"
    sender: str | None = Field(default=None, max_length=300)
    sent_at: datetime | None = None
    timezone: str | None = None

    @field_validator("sent_at")
    @classmethod
    def aware(cls, value):
        if value and value.utcoffset() is None:
            raise ValueError("sent_at must include an offset")
        return value

    @field_validator("timezone")
    @classmethod
    def zone(cls, value):
        if value:
            try:
                ZoneInfo(value)
            except ZoneInfoNotFoundError:
                raise ValueError("Use an IANA timezone") from None
        return value


class AnalysisRequest(Strict):
    messages: list[Message] = Field(min_length=1, max_length=30)
    approach: Literal["baseline", "improved", "structured"] = "baseline"

    @model_validator(mode="after")
    def limits(self):
        if len({m.id for m in self.messages}) != len(self.messages):
            raise ValueError("Message IDs must be unique")
        if sum(len(m.body) for m in self.messages) > 150_000:
            raise ValueError("Combined message text too large")
        return self


class Evidence(Strict):
    message_id: str = Field(min_length=1)
    quote: str = Field(min_length=1)


class Task(Strict):
    owner_group: str | None = None
    owners: list[str] = Field(default_factory=list, max_length=30)
    related_event: int | None = None
    arrival_local: str | None = None
    requirements: list[Evidence] = Field(default_factory=list, max_length=30)
    action: str = Field(min_length=1)
    owner: str | None
    deadline_text: str | None
    deadline: str | None  # ISO date, deliberately never an invented time
    status: Literal["pending", "cancelled", "superseded", "completed", "needs_review"]
    evidence: list[Evidence] = Field(min_length=1)

    @field_validator("deadline")
    @classmethod
    def iso_deadline(cls, value):
        if value is not None and date.fromisoformat(value).isoformat() != value:
            raise ValueError("deadline must be an ISO calendar date")
        return value


class EventSchedule(Strict):
    date_text: str | None
    date: str | None
    time_text: str | None
    timezone: str | None
    timezone_raw: str | None = None

    @field_validator("date")
    @classmethod
    def iso_date(cls, value):
        if value is not None and date.fromisoformat(value).isoformat() != value:
            raise ValueError("event date must be an ISO calendar date")
        return value


class Event(EventSchedule):
    title: str | None = None
    participants: list[str] = Field(default_factory=list, max_length=30)
    details: list[Evidence] = Field(default_factory=list, max_length=20)
    description: str = Field(min_length=1)
    status: Literal["announced", "rescheduled", "cancelled", "needs_review"]
    original_schedule: EventSchedule | None = None
    evidence: list[Evidence] = Field(min_length=1)


class SummaryClaim(Strict):
    text: str = Field(min_length=1, max_length=1500)
    evidence: list[Evidence] = Field(min_length=1, max_length=20)


class Analysis(Strict):
    model_http_ms: float | None = None
    model_prompt_ms: float | None = None
    model_generation_ms: float | None = None
    model_finish_reason: str | None = None
    summary_claims: list[SummaryClaim] = Field(default_factory=list, max_length=10)
    summary: list[Evidence] = Field(max_length=3)
    tasks: list[Task] = Field(max_length=100)
    events: list[Event] = Field(max_length=100)
    ambiguities: list[str]
    approach: Literal["baseline", "improved", "structured"]
    model: str | None
    latency_ms: float = Field(ge=0)
    inference_cost_usd: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None


def validate_evidence(result: Analysis, sources: dict[str, str]) -> Analysis:
    """Exact contiguous spans of canonical source, including summary evidence."""
    evidence = result.summary + [e for i in [*result.tasks, *result.events] for e in i.evidence] + [e for t in result.tasks for e in t.requirements] + [e for c in result.summary_claims for e in c.evidence] + [e for event in result.events for e in event.details]
    for e in evidence:
        if e.message_id not in sources or e.quote not in sources[e.message_id]:
            raise ValueError("Output evidence does not match source")
    for item in [*result.tasks, *result.events]:
        quotes = [e.quote for e in item.evidence]
        text = item.action if isinstance(item, Task) else item.description
        if not any(text in q for q in quotes):
            raise ValueError("Action/event must be a source span")
        fields = [item.owner, item.owner_group, item.deadline_text, *item.owners] if isinstance(item, Task) else [item.title, *item.participants, item.date_text, item.time_text, item.timezone_raw]
        if isinstance(item, Event) and item.original_schedule:
            fields += [item.original_schedule.date_text, item.original_schedule.time_text, item.original_schedule.timezone_raw]
        for value in fields:
            if value is not None and not any(value in q for q in quotes):
                raise ValueError("Extracted field must occur in its evidence")
    return result
