import {test,expect,chromium} from '@playwright/test';
import {spawn} from 'node:child_process';
import path from 'node:path';
import {mkdtemp,readFile} from 'node:fs/promises';

test('rescheduled meeting: real extension/backend, both methods and JSON export',async()=>{
  const extension=path.resolve('dist'),work=path.resolve('../../../work');
  const profile=await mkdtemp(path.join(work,'chromium-profile-'));
  const context=await chromium.launchPersistentContext(profile,{channel:'chromium',headless:true,args:[`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]});
  let backend:ReturnType<typeof spawn>|undefined;
  try {
    const worker=context.serviceWorkers()[0]??await context.waitForEvent('serviceworker');
    const id=new URL(worker.url()).host,token='event-state-test-token-only';
    backend=spawn(path.join(work,'.venv','Scripts','python.exe'),['-m','uvicorn','mailmind.api:app','--host','127.0.0.1','--port','8000','--no-access-log'],{cwd:path.resolve('..'),env:{...process.env,MAILMIND_TOKEN:token,ALLOWED_ORIGINS:`chrome-extension://${id}`},stdio:'ignore',windowsHide:true});
    await expect.poll(async()=>{try{return (await fetch('http://127.0.0.1:8000/health')).status}catch{return 0}}).toBe(200);
    const page=await context.newPage();
    await page.setViewportSize({width:420,height:900});
    await page.goto(`chrome-extension://${id}/panel.html`);
    await page.getByText('Local connection & privacy',{exact:true}).click();
    await page.locator('#token').fill(token);
    await page.locator('#mode').selectOption('paste');
    const cases=JSON.parse(await readFile('../data/manual_review_provisional.json','utf8')).cases;
    await page.locator('#body').fill(cases.find((c:any)=>c.id==='manual-19').body);
    for(const method of (process.env.TEST_LIVE_MODEL==='1'?['baseline','improved']:['baseline'])) {
      await page.locator('#approach').selectOption(method);
      await page.getByRole('button',{name:'Analyse email'}).click();
      await expect(page.locator('#events .card')).toHaveCount(1,{timeout:30000});
      await expect(page.locator('#events')).toContainText('Status: rescheduled');
      await expect(page.locator('#events')).toContainText('Current schedule: 2026-10-16');
      await expect(page.locator('#events')).toContainText('Previous schedule (no longer current): 2026-10-15');
      await expect(page.locator('#events')).toContainText('IST — region needs confirmation');
      await page.locator('#events').getByText('Supporting evidence').click();
      await expect(page.locator('#events blockquote')).toHaveCount(3);
      const downloading=page.waitForEvent('download');
      await page.getByRole('button',{name:'Export JSON'}).click();
      const stream=await (await downloading).createReadStream();let raw='';
      for await(const chunk of stream!)raw+=chunk.toString();
      const result=JSON.parse(raw);
      expect(result.approach).toBe(method);
      expect(result.events).toHaveLength(1);
      expect(result.events[0].original_schedule.time_text).toBe('11:00 AM');
      expect(result.events[0].time_text).toBe('3:30 PM');
      expect(result.events[0].timezone).toBeNull();
      await page.screenshot({path:`../results/event-state-${method}-panel.png`,fullPage:true});
    }
  } finally {backend?.kill();await context.close();}
});
