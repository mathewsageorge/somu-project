"""Known development regression and counterexamples, not held-out NLP metrics."""
import json
from pathlib import Path
import pytest
from mailmind.pipeline import analyse
from mailmind.schema import AnalysisRequest, Message, validate_evidence

BODY = (Path(__file__).parents[1]/'data/regression_rescheduled_review.txt').read_text(encoding='utf-8')


def run(body=BODY, **kwargs):
    return analyse(AnalysisRequest(messages=[Message(id='m', body=body, **kwargs)]))


def test_rescheduled_review_fields_and_context():
    result = run()
    assert len(result.tasks) == 3 and len(result.events) == 1
    assert [t.owner for t in result.tasks] == ['Rahul', 'Sneha', 'Rahul and Sneha']
    assert [t.deadline_text for t in result.tasks] == ['16 October at 5:00 PM IST', '17 October at 2:00 PM IST', '15 minutes early']
    assert [t.deadline for t in result.tasks] == [None, None, '2026-10-18']
    event = result.events[0]
    assert (event.date_text, event.date, event.time_text, event.timezone) == ('18 October 2026', '2026-10-18', '10:30 AM', None)
    assert result.tasks[2].status == 'needs_review'
    assert any('2026-10-18 10:15' in note and 'Derived' in note for note in result.ambiguities)
    assert any('earlier deadline is superseded' in note for note in result.ambiguities)
    assert not any('configuration' in task.action for task in result.tasks)
    assert len(result.tasks[0].evidence) == 2
    assert len(result.tasks[2].evidence) == 3
    validate_evidence(result, {'m': BODY})


def test_explicit_year_and_timezone():
    result = run(BODY.replace('16 October at', '16 October 2026 at').replace('17 October at', '17 October 2026 at'), timezone='Asia/Kolkata')
    assert [t.deadline for t in result.tasks] == ['2026-10-16', '2026-10-17', '2026-10-18']
    assert result.events[0].timezone == 'Asia/Kolkata'
    assert any('2026-10-18 10:15, Asia/Kolkata' in note for note in result.ambiguities)


@pytest.mark.parametrize('word', ['rescheduled', 'moved', 'postponed'])
def test_destination_clock_not_old_clock(word):
    result = run(f'The meeting was {word} from 2026-10-15 at 2 PM UTC to **2026-10-18 at 10:30 AM UTC**.')
    event = result.events[0]
    assert (event.date, event.time_text, event.timezone) == ('2026-10-18', '10:30 AM', 'UTC')


def test_unresolved_reschedule_never_reuses_old_date():
    event = run('The meeting was rescheduled from 15 October 2026 to a date to be decided.').events[0]
    assert event.date is None and event.date_text is None
    assert event.status == 'needs_review'


@pytest.mark.parametrize('extra', [
    'The other meeting is on 2026-10-20 at 3 PM UTC.\n',
    'The other meeting on 2026-10-20 is cancelled.\n',
])
def test_multiple_meetings_do_not_get_guessed(extra):
    result = run(BODY.replace('Both of you', extra + 'Both of you'))
    attendance = result.tasks[-1]
    assert attendance.deadline is None
    assert not any('Derived arrival time' in note for note in result.ambiguities)


def test_cancelled_meeting_does_not_produce_arrival():
    result = run('Hi Isha and Sam,\nThe meeting on 2026-10-18 at 10 AM UTC is cancelled.\nBoth of you should attend the meeting 15 minutes early.')
    assert result.tasks[-1].deadline is None
    assert not any('Derived arrival time' in note for note in result.ambiguities)


def test_arrival_crosses_midnight():
    result = run('Hi Isha and Sam,\nThe meeting is on 2026-10-18 at 12:05 AM UTC.\nBoth of you should attend the meeting 15 minutes early.')
    assert result.tasks[0].deadline == '2026-10-17'
    assert any('2026-10-17 23:50' in note for note in result.ambiguities)


def test_quoted_greeting_cannot_supply_owner():
    result = run('The meeting is on 2026-10-18 at 10 AM UTC.\nBoth of you should attend the meeting 15 minutes early.\n> Hi Wrong and Names,')
    assert result.tasks[0].owner is None


def test_separate_deadlines_are_not_grouped():
    result = run('Isha, please prepare the slides by 2026-10-16 and upload them by 2026-10-17.')
    assert [t.deadline for t in result.tasks] == ['2026-10-16', '2026-10-17']


def test_model_attendance_event_is_rejected_not_silently_replaced(monkeypatch):
    import mailmind.improved as module
    monkeypatch.setenv('MODEL_PROVIDER', 'llamacpp')
    monkeypatch.setenv('LLAMACPP_URL', 'http://127.0.0.1:8082')
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return {'choices': [{'message': {'content': json.dumps({'items': [{'sentence_id': 0, 'kind': 'event'}], 'summary_ids': [0]})}}]}
    monkeypatch.setattr(module.httpx.Client, 'post', lambda *a, **k: Response())
    result = analyse(AnalysisRequest(messages=[Message(id='m', body='Both of you should attend the meeting 15 minutes early.')], approach='improved'))
    assert not result.events and not result.tasks
    assert any('Rejected unsupported event' in note for note in result.ambiguities)
