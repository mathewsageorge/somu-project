# First reserved fictional evaluation

Reserved execution; same-author fictional data, not a blind external benchmark.

| Method | Task TP / FP / FN | Precision | Recall | F1 | Events TP / FP / FN | Mean latency (ms) |
|---|---|---|---|---|---|---|
| baseline | 9 / 0 / 4 | 1.000 | 0.692 | 0.818 | 4 / 0 / 0 | 1.5 |
| improved | 12 / 0 / 1 | 1.000 | 0.923 | 0.960 | 4 / 0 / 0 | 1967.6 |

The baseline is rules only; improved is the experimental pretrained model plus shared rules. These names are not performance claims.

## Field and summary checks

Owner and deadline non-null precision/recall/F1 (including unmatched tasks), matched-task status accuracy, event argument accuracy, token usage and per-case predictions are in `results.json`. Event argument denominators include only correctly matched event spans and can overstate end-to-end quality. Null agreement is not successful entity extraction.

Evidence validity measures exact source copying, not correct interpretation. Summary key-span coverage is only an automatic inclusion check: stale, unimportant or misleading quoted text may still pass. Human factuality and coverage ratings are blank in `human-review.csv`; no human evaluation result is claimed.

## Recorded errors

### baseline

- v2-reserved-03: tasks — missed_or_boundary_mismatch. Span: Would you be able to translate the welcome notice into Spanish by 2027-06-07?
- v2-reserved-09: tasks — wrong_field (status: expected 'cancelled', got 'pending'). Span: Gita, please draft the travel memo by 2027-06-16.
- v2-reserved-09: tasks — missed_or_boundary_mismatch. Span: We no longer need that memo.
- v2-reserved-10: tasks — wrong_field (status: expected 'superseded', got 'pending'). Span: Hari, please send the invoice by 2027-06-17.
- v2-reserved-10: tasks — missed_or_boundary_mismatch. Span: Please make that 2027-06-20 for the invoice instead.
- v2-reserved-11: tasks — missed_or_boundary_mismatch. Span: Please arrange accessible transport for the site visit.
### improved

- v2-reserved-09: tasks — wrong_field (status: expected 'cancelled', got 'pending'). Span: Gita, please draft the travel memo by 2027-06-16.
- v2-reserved-09: tasks — missed_or_boundary_mismatch. Span: We no longer need that memo.
- v2-reserved-10: tasks — wrong_field (status: expected 'superseded', got 'pending'). Span: Hari, please send the invoice by 2027-06-17.
- v2-reserved-10: tasks — wrong_field (owner: expected 'Hari', got None). Span: Please make that 2027-06-20 for the invoice instead.
- v2-reserved-10: tasks — wrong_field (deadline_text: expected '2027-06-20', got None). Span: Please make that 2027-06-20 for the invoice instead.
- v2-reserved-10: tasks — wrong_field (deadline: expected '2027-06-20', got None). Span: Please make that 2027-06-20 for the invoice instead.
- v2-reserved-10: tasks — wrong_field (status: expected 'needs_review', got 'pending'). Span: Please make that 2027-06-20 for the invoice instead.

## Interpretation and next experiment

Labels were authored before either prediction run. Production model, prompt and extraction rules were not tuned to these results during this evaluation. Exact-span scoring penalizes otherwise valid segmentation; adjudicate boundary disagreements separately and preserve this original result.

This reserved split has now been evaluated and inspected. Preserve this run and do not describe future reruns as unseen evaluation. Human label review and summary ratings remain pending. A later system tuned to these errors needs a fresh independent final-evaluation set. See `../FINAL-RESERVED-EVALUATION.md` for interpretation and the development comparison.

Inference is local. Per-case token counts are recorded when the runtime returns them; API billing and hardware/electricity costs are unmeasured (null). Latency includes startup/cache/HTTP effects and is not a controlled throughput estimate.
