"""Summarize recorded Case 22 experiments; never invokes the model or changes labels."""
import json, statistics
from pathlib import Path
base=Path('results')
release=json.loads((base/'case22-release-validation/results.json').read_text())
previous=json.loads((base/'case22-development-final/results.json').read_text())
timing=json.loads((base/'case22-timing-repeats/results.json').read_text())
case_rows=[]
for run in release['runs']:
 name=run['case_id'];out=run.get('output',{})
 row={'id':name,'after':{'tasks':len(out.get('tasks',[])),'events':len(out.get('events',[])),'owners':[t['owners'] for t in out.get('tasks',[])],'arrival':[t['arrival_local'] for t in out.get('tasks',[])],'summary':[s['text'] for s in out.get('summary_claims',[])],'error':run.get('error_type')}}
 for method in ['baseline','improved','structured_legacy']:
  r=next(x for x in previous['runs'] if x['case_id']==name and x['method']==method)
  o=r.get('output',{});row[method]={'tasks':len(o.get('tasks',[])),'events':len(o.get('events',[])),'owners':[t.get('owners') or ([t['owner']] if t.get('owner') else []) for t in o.get('tasks',[])],'arrival':[t.get('arrival_local') for t in o.get('tasks',[])]}
 case_rows.append(row)
perf={}
for method in ['improved','structured_legacy','structured']:
 runs=[r for r in timing['runs'] if r['method']==method and 'output' in r]
 def metric(values):return {'median':statistics.median(values),'min':min(values),'max':max(values)} if values else None
 perf[method]={'n':len(runs),'end_to_end_seconds':metric([r['end_to_end_ms']/1000 for r in runs]),'http_wall_seconds':metric([sum(c['http_wall_ms'] for c in r['model_calls'])/1000 for r in runs]),'prompt_seconds':metric([c['server_timings']['prompt_ms']/1000 for r in runs for c in r['model_calls'] if c.get('server_timings')]),'generation_seconds':metric([c['server_timings']['predicted_ms']/1000 for r in runs for c in r['model_calls'] if c.get('server_timings')]),'input_tokens':[r['output']['input_tokens'] for r in runs],'output_tokens':[r['output']['output_tokens'] for r in runs],'finish_reasons':[c['finish_reason'] for r in runs for c in r['model_calls']],'gpu_peak_mib':max((r['resources']['peaks'].get('gpu_memory_used_mib',0) for r in runs),default=None),'system_ram_peak_mib':max((r['resources']['peaks'].get('system_ram_used_mib',0) for r in runs),default=None)}
result={'cases':case_rows,'performance':perf,'limitations':'Same-author inspected development cases, not held-out. Timing n=2 per method, rotated order, loaded runtime without exclusive hardware/cache/power control. Count agreement alone is not correctness.'}
(base/'case22-comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
