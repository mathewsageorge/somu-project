# Beginner guide verification - 12 October 2026

Created docs/MailMind_Beginner_Setup_Guide.pdf (7 pages) and docs/BEGINNER-SETUP.md for a nontechnical Windows/NVIDIA user. README and START-HERE direct a friend to these instructions before the developer handover.

Checks performed:
- Inspected current requirements.lock, environment settings, pinned downloader/runtime and model startup configuration.
- Confirmed official Python 3.13.16 Windows x64 installer and pinned llama.cpp b11443 release pages. Original project environment remains Python 3.13.7; the new installer has not been separately tested.
- Parsed all six PowerShell command blocks with PowerShell's parser without executing installation/download commands: no syntax errors.
- Extracted the packaged release into a separate workspace folder. Verified every release-manifest hash and absence of .env. AppTest ran the extracted demo using the existing Python environment. dev-multiple / baseline returned two tasks and one event.
- With the extracted source and the documented MODEL_PROVIDER, LLAMACPP_URL and LLAMACPP_MODEL environment settings, checked the existing local model health and performed real Structured AI inference on dev-multiple: two tasks and one event, Qwen3.5-4B-Q4_K_M, pipeline time 12.88 seconds. This is a functional check, not a benchmark or new research comparison.
- Rendered and visually inspected all seven final PDF pages. No application/NLP code, model, prompt or accuracy measurements were changed.

Limits: did not install Python or dependencies from scratch, re-download the multi-gigabyte model, start a duplicate server, or verify the friend's laptop. Existing model/runtime downloads were previously checksum-verified. Hardware may need adjustment. GPU settings target the verified 16 GB RAM / RTX 3050 4 GB deployment; other configurations are not guaranteed. The guide includes explicit readiness checks, missing-dependency/hardware failure handling and a model-free baseline route.

New users need the updated MailMind.zip plus the guide. Python environments, model/runtime files and secrets are excluded from the ZIP. No Chrome/Gmail integration or account setup is required for the submitted local website.
