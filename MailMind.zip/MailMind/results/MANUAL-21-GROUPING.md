# Manual Test Case 21: linked work and report requirements

11 October 2026. This is the full user-authored manual case, not v2-dev-21. It is development evidence, not an unseen accuracy benchmark. Input, provenance, source hashes and actual outputs are in `manual-21-grouping-after`; the earlier run is in `manual-21-before`.

| Method | Before | After |
|---|---|---|
| Rules only | Four tasks: split Aisha work, Rahul report, separate inclusion instruction | Two tasks: grouped Aisha work due October 12; Rahul report due October 13 with inclusion requirement |
| Qwen plus rules | Four tasks: split Aisha work, Rahul report, attendance; inclusion omitted | Three tasks: grouped Aisha work, Rahul report with inclusion requirement, attendance |

Both runs retain one event. All evidence validated against the source. The model remains Qwen3.5-4B-Q4_K_M; no training or prompt change was performed for this step. Measured pipeline latency was 16.75 ms for rules and 6627.98 ms for AI in this single run. These are not controlled speed benchmarks.

## Implementation and attribution

A shared deterministic rule keeps an activity such as testing together with sharing its observations/findings/results when the second clause supplies the shared deadline. Counterexamples cover independent deliverables, different owners and separate deadlines.

A conservative shared rule attaches an immediately adjacent, same-line "Please include ..." sentence to one unambiguous pending report/document/summary/slides task. It requires exact source evidence and rejects its own deadline, another owner or specified conflicting/conditional wording. It can recover this requirement even when the model labels it informational; the review note explicitly discloses rule-based linking. This is not credited as a new model capability. It is not general dependency resolution.

Tasks now expose a `requirements` list of source evidence, defaulting to empty for compatibility with old inputs. The Streamlit and extension task cards display these instructions; exported JSON retains them. Consumers with a closed external schema should allow the new field. The documented output schema is regenerated.

## Verification and limits

142 Python tests passed, including a Streamlit AppTest paste/analyse/display flow and evidence-tampering rejection. TypeScript checking and extension build passed. Both live local-model and baseline reproductions completed. No new real-Chrome manual check was performed for the requirement display; extension rendering was build-checked. The Streamlit server was restarted on port 8502.

The rules-only baseline still misses attendance. AI attendance still has unspecified owner and deadline; the three-person reference and 10:20 contextual arrival time are not yet resolved. Summary completeness, conditional blocker reporting and general dependencies remain open. Returning three task groups alone does not establish full correctness. IST remains unresolved without sufficient timezone context. No reserved evaluation was rerun or claimed as unseen performance.
