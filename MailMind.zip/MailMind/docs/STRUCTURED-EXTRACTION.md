# Structured AI extraction

Latest submission pass: [measured results and limitations](../results/SUBMISSION-UPDATE.md). Proposed summary claims now allow up to 600 characters and are checked for unfinished ending punctuation. The validator drops deadline wording found only in contextual evidence rather than the action/linked requirement, and suppresses original-schedule history on non-rescheduled events. General prompt checks reinforce collective preparation, recipient attribution and dependency handling; they do not guarantee correctness. Earlier comparisons below retain their original version boundaries.

The new `structured` API approach runs the existing local Qwen model. `baseline` and `improved` retain the previous rules-only and sentence-selection implementations. The Streamlit method picker and Chrome panel expose all three. No pretrained weights, model runtime configuration, dependency installation or fine-tuning changed.

## Data flow

Selected messages → canonical text and quote/signature exclusion → numbered source sentences plus recipient greeting context → one schema-constrained local Qwen call → Pydantic validation → source evidence/field checks and conservative date arithmetic → reviewable output.

Qwen decides task grouping, people, deadlines, task lifecycle status, report requirements, event associations and summary wording. The structured path does **not** invoke the old rule task detector, grouping, contextual owner inference or lifecycle reconciler. Action/event wording is retrieved from model-selected source IDs; the summary is generated prose. This design keeps tasks traceable without requiring verbatim model transcription.

The validation layer checks IDs, exact evidence, copied owner/date/time wording and supported numeric/urgency details in summaries. Unsupported fields are removed with review notes; invalid JSON, invalid IDs, truncation and runtime errors fail without silently substituting baseline results. These checks are necessary, not sufficient for factuality. A plausible wrong owner, unrelated cited date, wrong event label or unsupported semantic paraphrase can still pass. All generated interpretations require source review.

## Output additions

- `summary_claims`: natural-language text with exact source evidence for each claim; legacy `summary` remains for previous methods.
- `tasks[].owners`: individual source-backed names. `owner` remains a single name when there is exactly one owner, otherwise null.
- `tasks[].related_event`: zero-based output event index, chosen through the model's source-ID link.
- `tasks[].arrival_local`: calculated source-local date/time for an explicitly stated early-arrival offset. It is not a UTC instant. Missing/ambiguous event context leaves it null.
- `tasks[].owner_group`: original collective wording when team membership is not fully known.
- `events[].title`, `participants`, `details`, `original_schedule`: separately grounded meeting identity, people, logistics and history.
- `model_http_ms`, `model_prompt_ms`, `model_generation_ms`, `model_finish_reason`: request wall time and optional runtime measurements.
- Existing `requirements`, task status, date wording and evidence are retained. The model selects requirements in this path.

See `analysis.schema.json`, `request.schema.json` and `structured-model.schema.json`. Consumers of exported JSON should handle the additional fields. Summary consumers must read `summary_claims` for the structured approach.

Original date wording is retained. Normalization uses existing conservative date validation: missing years stay unresolved; relative dates require the message timestamp and timezone; IST is not guessed. The structured path now populates `original_schedule` from model-cited historical evidence and displays it separately from the current schedule. A linked arrival is explicitly labelled for review.

## Local operation

Existing `.env` runtime settings are reused (loopback llama.cpp or Ollama only). Input limit: 120 candidate rows and 10,000 characters. One call, temperature 0, seed 42, maximum 3,000 output tokens and a 90-second HTTP timeout; no retries that silently multiply cost. Same Qwen3.5-4B-Q4_K_M in measured runs. No new model download or dependency is necessary. Output is kept only in application memory until explicit export. Evaluation scripts deliberately save fictional inputs/results, not normal user emails.

## Try it

1. Open the local Streamlit demo on port 8502 and refresh.
2. Select the fictional example **Test Case 22 · UAT approval and rescheduled meeting**, or paste your email.
3. Choose **Structured AI · Qwen extraction (new)** and click Analyse.
4. Inspect Summary, Action items, Events and Review notes. Expand evidence. Compare the same input using **Previous AI · sentence selection** and **Rules only (baseline)**.
5. Export JSON to retain the result. Model output is experimental; do not interpret three task cards as proof that all fields are correct.

For a reproducible nine-case development comparison, from the project directory run:

For the newer eight-case Case 22 suite, run `python scripts/evaluate_case22.py --input data/case22_development.json --output results/my-case22-run --methods baseline improved structured_legacy structured`. For repeated identical Case 22 timings, omit `--input` and add `--repetitions 2`. Use your activated project environment. These runs save fictional model responses and may take several minutes. Output directories must be new. The [Case 22 report](../results/CASE22-REPORT.md) contains actual results and remaining failures; expect roughly a minute for the longer structured example on the measured laptop.

The earlier nine-case script remains available:

```powershell
../../work/.venv/Scripts/python.exe scripts/compare_structured.py --output results/my-new-comparison
```

The destination must not already exist. The script uses identical inputs for all three methods, validates evidence and records outputs, source hashes, latency, token counts and system-wide sampled memory/GPU statistics. It does not touch the reserved test set. Labels are same-author draft development labels and include a historical two-record cancellation policy; see the report for why exact-span scores alone are insufficient.
