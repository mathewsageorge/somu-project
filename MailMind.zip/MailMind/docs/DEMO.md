# Five-minute demonstration

1. **0:00–0:45 — Scope and privacy.** Start the backend and open the extension. Point out the FICTIONAL DEMO badge, local processing and absence of background inbox access.
2. **0:45–1:45 — End-to-end extraction.** Enter the backend pairing token, Analyse the demo and show Asha/Ravi's separate tasks. Expand evidence. Show “tomorrow” beside its resolved date and the meeting as a separate event.
3. **1:45–2:30 — User control.** Edit an owner, show the user-edit marker, dismiss a task, export JSON and verify only visible items appear. Explain that the original machine extraction remains attached to an edited item. Clear the analysis.
4. **2:30–3:15 — Difficult input.** In Streamlit choose dev-ambiguous, dev-cancel and dev-injection. Show null dates/review reasons, cancelled status and exclusion of an embedded system instruction. Explain that heuristic attack detection is not a complete semantic guarantee; the model has no tools or secrets.
5. **3:15–4:15 — Research comparison.** Show the actual results table, exact evaluation definition and a missed/incorrect case. Explain why exact evidence and lexical summary coverage do not prove factuality. Model B is a candidate method, not automatically superior.
6. **4:15–5:00 — Gmail boundary and next steps.** With configured credentials and a test account, connect and explicitly search/select one fictional test email before Analyse. Otherwise show the setup-required state and say the live integration is unverified. Explain read-only scope and why the open Gmail tab is not automatically detected. Google Tasks/Calendar creation is optional and not implemented.
# Teacher presentation walkthrough (updated 8 October 2026)

1. Open the Streamlit demo at http://127.0.0.1:8502/ and show the selected fictional email first.
2. Under **Choose how to analyse**, select **AI model + rule checks**. Explain: “The pretrained model identifies task/event sentences and selects summary sentences. Rules extract fields and validate source evidence.” This is inference, not training.
3. Click **Analyse**. Point to the completed-run model name, measured processing time and token counts. Before the run, a configured model name alone does not prove execution. Time includes the full NLP pipeline.
4. Review actions/events and expand supporting evidence. Explain that exact quotation matching does not prove correct semantic interpretation. Open review notes for unresolved fields.
5. Select **Rules only** and analyse the same email. Its result explicitly says no model was used. Compare correctness rather than assuming the AI method is always better.
6. For the linked-request example, paste “Could you please review the updated functionality and share your feedback by October 14, 2026?” Both methods should retain one task with that shared deadline; owner remains unspecified.

The summary is currently selected source sentences. Do not present it as free-form generative summarization, claim a calibrated confidence score, or attribute previous reserved-test scores to a changed version without fresh evaluation.

