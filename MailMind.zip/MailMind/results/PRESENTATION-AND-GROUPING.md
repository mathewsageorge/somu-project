# Teacher-facing demo and shared deadlines — 8 October 2026

## Presentation changes

Streamlit now has a coordinated dark theme, a project introduction, numbered input/method/result stages, and an explanatory sidebar. The selected method is labelled either AI model + rule validation (main system) or rules only (baseline). Before execution, the model name is explicitly configuration, not a health or success claim. After a successful AI run, the result's model identifier is prominent alongside measured pipeline latency, action/event counts, review notes and reported token usage. Baseline results explicitly say no AI model was used; failed inference produces an error without a success banner. No artificial confidence or training claims are shown. Model identifiers are configured runtime aliases, not independently attested weight hashes.

Plain-language cards and expandable evidence remain visible; technical JSON and ordinary review notes are folded away. Incomplete-model-output errors remain visible. The sidebar explains that this pretrained model classifies/selects sentences and the rules extract/validate fields; summaries remain extractive. The extension interface was not redesigned in this step.

Files: `demo.py`, `.streamlit/config.toml`, `tests/test_presentation_ui.py`.

## Shared deadline changes

`context.task_chunks` now preserves review-and-feedback and issue-review-and-tracking instructions with one final deadline as a single linked task. Existing delivery-pronoun grouping remains. This is a documented, narrow deterministic rule used by both approaches, not model training. Separate explicit deadlines and independent deliverables remain separate. Explicit named addressees after a conjunction can now start a separate task, whose owner is extracted from that clause in `pipeline.materialize`.

`dates.py` now preserves weekday plus adjacent named calendar date in raw wording. Explicit years are normalized only when consistent with the weekday; conflicts require review. Missing years stay unresolved, even when another sentence has a year. No timezone inference was added.

## Actual before / after

| Input | Before (both methods) | Final (both methods) |
|---|---|---|
| Provisional case 16 | Two Priya tasks; first no deadline, second raw Thursday | One linked Priya task, raw Thursday, October 15, normalized date null |
| Provisional case 18 | Two tasks; deadline only on feedback | One linked review/feedback task, raw October 14, 2026, normalized 2026-10-14, owner null |
| Provisional case 19 | Previous fix: one event | Still one rescheduled event |

Original fixtures and missing-content notes are unchanged. Final ten actual outputs are in `manual-review-grouping-final/results.json`; the previous event-state run is in `manual-review-event-state-final/results.json`. These are repeated development cases, not an unseen benchmark or new accuracy claim. Source hashes and per-run token/latency values are recorded. Case 16 still cannot test the absent Rahul/objective sentences.

## Verification

- Full Python suite: **128 passed**, one existing Starlette/httpx deprecation warning; `python-tests-presentation-grouping.xml`.
- Added 11 grouping/date test cases: both materialization paths, separate deadlines, separate named owners, independent deliverables, absent years, weekday consistency and no borrowed year.
- Added three UI truthfulness tests with explicitly mocked inference: baseline has no model-success claim, completed display uses result identifier/latency/tokens, failed inference has no completed banner. Mock tests are not model evidence.
- Live local model: five provisional cases × two methods completed; evidence validation passed. AI latency for cases 16/18 was 2346.13/2616.22 ms in this run; no claim of stable benchmark latency.
- In-app browser: checked styling, selected AI method, ran the original fictional demo. UI showed Qwen3.5-4B-Q4_K_M, 2.67 s, 2 actions, 1 event, 952 input / 41 output tokens. Screenshot `presentation-model-run.jpg` records the model/timing view. Narrow-window view stacks metrics; desktop layout uses columns. Local Streamlit restarted on port 8502 with the new theme and imported NLP code.

## Limits

This does not solve general compound-task semantics, conditional deployment, model summary omissions, or case-20 arrival interpretation. Summary changes here are presentation only. The research comparison still needs separate semantic human scoring; old frozen reserved results must not be attributed to this changed version. No live Gmail or Calendar integration was tested or changed. No external model provider was used.
