# Broader fictional development evaluation

Single-author draft labels, frozen before inference. No independent annotation, real-email validation, or model training. Reserved cases were not run.

| Method | Task TP / FP / FN | Precision | Recall | F1 | Events TP / FP / FN | Mean latency (ms) |
|---|---|---|---|---|---|---|
| baseline | 20 / 0 / 2 | 1.000 | 0.909 | 0.952 | 4 / 0 / 0 | 1.3 |
| improved | 22 / 0 / 0 | 1.000 | 1.000 | 1.000 | 4 / 0 / 0 | 1881.1 |

The baseline is rules only; improved is the experimental pretrained model plus shared rules. These names are not performance claims.

## Field and summary checks

Owner and deadline non-null precision/recall/F1 (including unmatched tasks), matched-task status accuracy, event argument accuracy, token usage and per-case predictions are in `results.json`. Event argument denominators include only correctly matched event spans and can overstate end-to-end quality. Null agreement is not successful entity extraction.

Evidence validity measures exact source copying, not correct interpretation. Summary key-span coverage is only an automatic inclusion check: stale, unimportant or misleading quoted text may still pass. Human factuality and coverage ratings are blank in `human-review.csv`; no human evaluation result is claimed.

## Recorded errors

### baseline

- v2-dev-03: tasks — missed_or_boundary_mismatch. Span: Could you reconcile the two inventory lists before 2027-01-14?
- v2-dev-04: tasks — missed_or_boundary_mismatch. Span: The pilot cannot proceed without your approval of the release checklist.
### improved

No recorded span/field errors, or method blocked; check execution status above.

## Interpretation and next experiment

Labels were authored before either prediction run. Production model, prompt and extraction rules were not tuned to these results during this evaluation. Exact-span scoring penalizes otherwise valid segmentation; adjudicate boundary disagreements separately and preserve this original result.

Ask a human reviewer to inspect the development answer key, then revise development labels only in a new dataset version with a change log. Fix recurring development failures, freeze a new system version, and obtain explicit authorization before releasing the reserved cases. Once inspected or used for tuning, a case is no longer unseen.

Inference is local. Per-case token counts are recorded when the runtime returns them; API billing and hardware/electricity costs are unmeasured (null). Latency includes startup/cache/HTTP effects and is not a controlled throughput estimate.
