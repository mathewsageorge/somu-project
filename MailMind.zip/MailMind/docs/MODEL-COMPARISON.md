# Comparing model sizes before fine-tuning

Verified on 8 October 2026: downloads passed checksums, the server loaded successfully, and both models completed the 24-case comparison plus the longer regression. See [actual results](../results/MODEL-SIZE-COMPARISON.md). The 4B model is now the configured experimental AI option, with known omissions. Rules only stays the default. 58 Python tests passed.

The updated local demo runs at **http://127.0.0.1:8502/**. The earlier process on port 8501 was left running because this session's automatic approval policy rejected its stop/restart operation. A separate demo process was started safely on port 8502 with explicit candidate-model environment settings. Use 8502 for this comparison, not the older bookmarked page.

To reproduce this separate demo after starting the candidate server, use the project directory:

```powershell
$env:MODEL_PROVIDER='llamacpp'
$env:LLAMACPP_URL='http://127.0.0.1:8082'
$env:LLAMACPP_MODEL='Qwen3.5-4B-Q4_K_M'
python -m streamlit run demo.py --server.address 127.0.0.1 --server.port 8502 --server.headless true --browser.gatherUsageStats false
```

The current experiment keeps the instructions, rules and datasets fixed and changes the pretrained model. This measures a model replacement, not training or research novelty. The 12 development and 12 diagnostic cases have already been inspected; resulting scores are regression comparisons, not new held-out performance estimates. The user's longer email is an explicit development regression.

## Downloads

`scripts/fetch_candidate_model.py --directory PATH` downloads approximately 3.4 GB into a directory of your choice: Qwen3.5-4B Q4_K_M weights converted by Unsloth, official llama.cpp b11443 Windows CUDA 12.4 binaries and their runtime DLLs. Model revision, remote SHA256 checksums and runtime release are pinned in that script. Every file is checked before extraction/loading. The old CPU model remains available separately. Files are external dependencies and are not bundled in the project ZIP.

Sources: [Qwen model card](https://huggingface.co/Qwen/Qwen3.5-4B), [Unsloth quantized file](https://huggingface.co/unsloth/Qwen3.5-4B-GGUF/blob/e87f176479d0855a907a41277aca2f8ee7a09523/Qwen3.5-4B-Q4_K_M.gguf), [official runtime](https://github.com/ggml-org/llama.cpp/releases/tag/b11443). Review Apache-2.0 model terms and runtime/distributed-library terms before redistribution. No model is trained by this download.

## Local execution

From the extracted runtime folder, run the following command with the actual model path:

```powershell
.\llama-server.exe -m "PATH\Qwen3.5-4B-Q4_K_M.gguf" --alias Qwen3.5-4B-Q4_K_M --host 127.0.0.1 --port 8082 -c 8192 -np 1 -ngl 24 -b 256 -ub 128 --reasoning off --log-disable
```

This starts with 24 layers on the GPU, leaving space on the verified RTX 3050 Laptop GPU (4096 MiB). Actual fit and speed must be measured; reduce `-ngl` if allocation fails. Do not expose this server outside loopback. Thinking is disabled for this short structured classification experiment. No vision projector is needed for text-only emails. The existing old-model server stays on port 8081.

Alternatively, from the project directory, `./scripts/start_candidate_model.ps1 -ModelDirectory PATH` verifies the model checksum, starts a hidden local server with these settings, and saves its PID/settings in the model directory. Do not start another server on an occupied port. In this run, total GPU usage after inference was 2408 MiB; the first longer-email request took 7587 ms. Short fixtures had lower latency; this is not a speed guarantee.

To select a candidate for a new Streamlit/FastAPI process:

```dotenv
MODEL_PROVIDER=llamacpp
LLAMACPP_URL=http://127.0.0.1:8082
LLAMACPP_MODEL=Qwen3.5-4B-Q4_K_M
```

Only the explicitly documented loopback endpoints are allowed. The model name is the server alias, not an accuracy guarantee. Restart app processes after changing environment settings. With both servers running, execute:

```powershell
python scripts/compare_model_sizes.py --output results/model-size-comparison.json
```

The script preserves existing outputs, records hashes, endpoint-advertised model IDs, predictions, latency and task/event/field/evidence metrics. Missing services or invalid model outputs are recorded as blocked/partial, not replaced with baseline answers. Hardware differs between the old CPU and candidate GPU run, so latency is a deployment comparison and cannot isolate the effect of model size.

## Fine-tuning comes later

After the frozen comparison, the application gained an additional warning listing source sentences omitted by the model. This changes review messages only; prompts, selected items and field extraction remain unchanged. A source snapshot and model/runtime manifests accompany the recorded comparison. No prompt changes were made to improve these scores.

Direct label inspection showed the 4B model explicitly assigns `none` to the four missed instructions in the longer email; they are not absent from its response. A second review check now flags `none` labels that conflict with the baseline's request/cancellation patterns. This is a disclosed disagreement, not an automatic replacement task or a claim that rules are always correct. `project-review-qwen35-labels.json` records these labels and the final warning. Extracted tasks, events and summary were compared with the frozen benchmark and remained identical. The production prompt and model weights were not changed.

The final demo was verified through the browser on port 8502: Qwen3.5-4B was displayed, three task records and one event were shown, and the incomplete-analysis banner listed four rule/model disagreements. The observed request took 5222.76 ms. `results/qwen35-browser-check.json` and `results/qwen35-demo-review.jpg` preserve the verification record. Refreshing the browser alone does not reload every imported Python module; after code changes, restart your own Streamlit terminal process before testing.

First establish a reproducible pretrained-model result. Then gather independently checked email/answer pairs, keep related threads in the same split, freeze a genuinely new test set, and assess whether adapter training improves it. An inference setup fitting 4 GB VRAM does not establish that training fits. This experiment does not resolve cross-sentence owners or generate abstractive summaries: the existing extractor still selects source sentences and uses rules for fields.
