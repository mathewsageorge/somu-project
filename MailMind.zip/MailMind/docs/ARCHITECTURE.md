# Architecture and data flow

## Current submission architecture

The submitted product is the local Streamlit web application. **Chrome extension integration and Gmail connection are future scope**; exploratory source remains available but is not presented as a verified connected workflow.

User-selected fictional/pasted email → canonical text / candidate rows → Rules Only, Previous AI or Structured AI → local Qwen where selected → schema, source evidence and date validation → web summary/tasks/events/review notes → explicit JSON export.

`mailmind/resources.py` reads laptop-wide physical RAM (Windows memory API; Linux MemAvailable fallback) and NVIDIA GPU 0 activity/VRAM through a read-only `nvidia-smi` query, with a 1.5 s timeout and no shell. Missing readings remain null. There is no initial/idle usage panel or periodic telemetry polling. During analysis a single Python worker runs the existing pipeline while the UI thread refreshes the floating activity card during analysis only. An optional `progress` callback emits only fixed phase identifiers (`preparing`, `model` or `rules`, `validating`, `complete`) into a thread-safe queue. The callback receives no email content. Model-request waiting includes transport/runtime queue, prompt processing and generation, which cannot be separated live by the non-streaming response. The UI updates elapsed time about every second and hardware about every two seconds, clears the card in `finally`, and respects reduced-motion animation preferences. No fabricated percentages, token streaming or ETA are shown. The baseline and API callers can omit the callback; extraction decisions and prompts are unchanged. No Streamlit calls occur in the worker. Telemetry has no email access or persistence and is not exported in analysis JSON. Sampling can add overhead; no isolated model-memory or zero-overhead claim is made.

The Deploy control is hidden by a targeted CSS selector for the pinned Streamlit version; other run/menu controls remain available. This removes a presentation control, not a deployment backend. The fragment behavior follows [Streamlit's official documentation](https://docs.streamlit.io/develop/concepts/architecture/fragments).

## Historical exploratory extension design (future integration)

The diagram and older notes below describe retained exploratory source and earlier architecture. The submitted web flow uses the `structured` method as well as the two comparison methods; structured summaries are generated cited claims, unlike the older three-sentence extractive summary.

```mermaid
flowchart TD
    U[User selects demo, paste or Gmail item] --> P[Chrome MV3 side panel]
    P -->|Interactive Connect only| I[Chrome Identity token cache]
    I -->|Token stays in browser| G[Gmail API]
    G -->|Selected body or thread| P
    P -->|Loopback JSON + pairing token| A[FastAPI boundary]
    A --> C[Canonical text and candidate sentences]
    C --> B[Rules baseline]
    C --> L[Local pretrained sentence selector]
    B --> V[Structured output and exact evidence validation]
    L --> V
    V --> P
    P --> R[User reviews, edits or dismisses]
    R --> X[Clipboard or JSON download]
    S[Streamlit demo] --> C
```

`schema.py` defines strict Pydantic request/result types and evidence validation. Unknown request keys, duplicate message IDs, naive timestamps and invalid IANA zones are rejected. Machine summaries are up to three evidence-backed sentences. Tasks/events are source spans, not free generation. Nullable fields are required in output. Rule normalization returns an ISO date only when the implemented conservative policy resolves it.

`text.py` converts HTML to canonical plain text, removes executable/non-visible nodes, excludes quoted replies and signatures from candidate extraction. Canonical visible text is the source for evidence matching. It does not render incoming HTML in either interface. Inline quoted HTML marks the start of a quoted region; content after that region is conservatively omitted. This can miss inline replies.

`pipeline.py` implements frequency-ranked extractive summarization, request/verb patterns, named-owner spans, date extraction and exact-core thread reconciliation. Messages sort by timestamp only if all timestamps are known. Otherwise caller order is retained. Cross-message paraphrases and broad cancellation scope require review. Meeting time stays as original text; no unsupported timezone conversion is performed.

`improved.py` submits candidate sentences to a local pretrained instruction model and validates integer sentence IDs and task/event/none labels. The none category is removed before building task/event cards. Both approaches share preprocessing, field extraction, reconciliation and evidence checks. The October 7 revision adds prompt examples and the none label; the original experiment used task/event labels only. Temperature=0 and seed=42 reduce variability but do not guarantee cross-runtime bitwise reproducibility. No fine-tuning or custom training occurs. The model has no application tools, credentials or write access. It can still select the wrong sentence/category.

`api.py` validates body size before schema parsing, requires a local pairing token, restricts Host and Origin, suppresses sensitive validation details and applies model HTTP timeouts. Bind to loopback. This is a single-user local architecture, not a production multi-tenant server.

`extension/src/gmail.ts` uses supported Gmail REST endpoints. Search lists IDs and gets metadata headers; the selected ID is subsequently fetched with `format=full`. Gmail OAuth tokens are never included in analysis requests. `background.ts` only configures toolbar opening of the side panel. No content scripts, inbox scraping, background message reading, database, sending or Google write endpoints exist.

Limits: 30 messages, 100,000 characters per body, 150,000 combined characters, 700,000 JSON request bytes; model path additionally limits candidate sentences and prompt characters. Unsupported oversized content fails rather than truncating silently. Attachments are not fetched. Google transport and model requests have explicit timeouts.
# Longer-email regression update (7 October 2026)

Candidate preparation now excludes pasted subject headers and standalone salutations, protecting spaced honorifics during splitting. The model still selects sentence IDs using the original v3 prompt; an additional deterministic event guard rejects labels without supported event vocabulary or conflicting with explicit requests. Rejections are disclosed as incomplete analysis and never silently reclassified. This does not solve missing actions or cross-sentence owners. Date processing now supports full English calendar dates and keeps deadlines on the clauses that contain them. See `results/PROJECT-REVIEW-FAILURE.md` for measured failures and current validation boundaries.

