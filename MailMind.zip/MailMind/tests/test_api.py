import pytest
from fastapi.testclient import TestClient
from mailmind.api import create_app
from mailmind.improved import ModelUnavailable

TOKEN="test-only-pairing-token-with-enough-length"
BODY={"messages":[{"id":"m","body":"Please send the agenda."}]}


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("MAILMIND_TOKEN",TOKEN)
    monkeypatch.setenv("ALLOWED_ORIGINS","http://127.0.0.1:5173")
    return TestClient(create_app())


def test_auth_and_success(client):
    assert client.get('/health').json()['storage']=='none'
    assert client.post('/analyse',json=BODY).status_code==401
    r=client.post('/analyse',json=BODY,headers={'X-MailMind-Token':TOKEN})
    assert r.status_code==200 and len(r.json()['tasks'])==1


def test_origin_and_preflight(client):
    assert client.post('/analyse',json=BODY,headers={'Origin':'https://evil.example','X-MailMind-Token':TOKEN}).status_code==403
    r=client.options('/analyse',headers={'Origin':'http://127.0.0.1:5173','Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'X-MailMind-Token,Content-Type'})
    assert r.status_code==200
    assert r.headers['access-control-allow-origin']=='http://127.0.0.1:5173'


def test_size_and_safe_validation(client):
    r=client.post('/analyse',content='x'*700001,headers={'X-MailMind-Token':TOKEN,'Content-Type':'application/json'})
    assert r.status_code==413
    r=client.post('/analyse',json={'messages':[{'body':'PRIVATE BODY'}]},headers={'X-MailMind-Token':TOKEN})
    assert r.status_code==422 and 'PRIVATE BODY' not in r.text


def test_backend_failure(client,monkeypatch):
    import mailmind.api as module
    def fail(*a): raise RuntimeError('SECRET EMAIL')
    monkeypatch.setattr(module,'analyse',fail)
    r=client.post('/analyse',json=BODY,headers={'X-MailMind-Token':TOKEN})
    assert r.status_code==500 and 'SECRET EMAIL' not in r.text


def test_model_failure(client,monkeypatch):
    import mailmind.api as module
    def fail(*a): raise ModelUnavailable('private details')
    monkeypatch.setattr(module,'analyse',fail)
    r=client.post('/analyse',json=BODY,headers={'X-MailMind-Token':TOKEN})
    assert r.status_code==503 and 'private details' not in r.text


def test_structured_route_preserves_new_fields(client,monkeypatch):
    from mailmind.schema import Analysis, SummaryClaim, Evidence
    result=Analysis(summary=[],summary_claims=[SummaryClaim(text='Agenda requested.',evidence=[Evidence(message_id='m',quote='Please send the agenda.')])],tasks=[],events=[],ambiguities=['Review AI interpretation.'],approach='structured',model='mock-model',latency_ms=1)
    monkeypatch.setattr('mailmind.structured.structured',lambda messages:result)
    response=client.post('/analyse',json={**BODY,'approach':'structured'},headers={'X-MailMind-Token':TOKEN})
    assert response.status_code==200
    assert response.json()['summary_claims'][0]['text']=='Agenda requested.'
    assert response.json()['approach']=='structured'
