# Case 22 regression annotation policy

This suite contains the full user-authored fictional Case 22, the existing full Case 21, and six new fictional development counterexamples. It is not a blind test set. Expected labels were written before the first suite inference but by the implementer, without independent annotation. Do not conflate the unique identifier `manual-22-uat-readiness` with any existing v2 example.

- Count one logical task per deliverable with its delivery/requirements, and a separate task for an explicit group preparation instruction. Do not count ordinary meeting announcements as tasks.
- Both/all three/everyone can resolve to a clearly addressed recipient group. Entire team does not supply unspecified team members. For 'you and your team' addressed to Eva, Eva is known; the remainder of the team is unknown. Preserve the group wording and review note; do not invent names.
- Model-proposed participant names need the greeting/group definition as evidence, not only a meeting sentence. A name present elsewhere in the email is not sufficient evidence of its role.
- For a rescheduled meeting retain one event, current schedule, original schedule and source-backed name. Link an early-arrival task only when the relevant meeting is unambiguous. Two equally plausible meetings require an unresolved link, not an arbitrary choice.
- Arrival calculations are source-local clock arithmetic. Preserve AM/PM and date rollover. IST does not resolve a region; no UTC conversion is justified without confirmed timezone context.
- Case 22's expected summary facts are recorded in `manual_case_22.json`. Each group must be checked semantically, including negation, both deployment prerequisites and the unknown deployment date. Source citation coverage alone does not prove that prose covers those facts.
- Count field errors and missing task requirements separately from task-card counts. A baseline with three cards can still miss attendance and split another task.
- Compare factuality and completeness separately. A concise summary may combine related facts but must not infer readiness/approval or a deployment date that was never stated.
- Screenshots and a reported 33.54-second observation cannot reconstruct the exact runtime/cache/other-load conditions or recover the original generated JSON. New runs are reproductions of the supplied text under documented current settings.

Human review is still required. For the next independent evaluation, freeze labels and prompts first and use separate unseen inputs, rather than treating these tuned development examples as evidence of general accuracy.
